﻿CREATE TABLE [WFlow].[OT_TV_WBody_WFlow_Standard_Report_Details](
	[Id]						 BIGINT IDENTITY(1,1)   NOT NULL,
	[WBodyWFlowSequenceId]		 BIGINT                 NOT NULL,
	[StandardAttribute]          NVARCHAR(250)          NOT NULL,
	[StandardAttrributeValue]    NVARCHAR(250)			        NULL,
	[CreatedBy]					 UNIQUEIDENTIFIER       NOT NULL,
	[CreatedDate]                DATETIME               NOT NULL DEFAULT (getdate()),
	[ModifiedBy]                 UNIQUEIDENTIFIER       NULL,
	[ModifiedDate]               DATETIME               NULL,

    CONSTRAINT [PK_TV.OT_TV_WBody_WFlow_Standard_Report_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_Standard_Report_Details_OT_TV_WBody_WFlow_Sequence_Details] FOREIGN KEY ([WBodyWFlowSequenceId]) REFERENCES [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ([Id]),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_Standard_Report_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_Standard_Report_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	)