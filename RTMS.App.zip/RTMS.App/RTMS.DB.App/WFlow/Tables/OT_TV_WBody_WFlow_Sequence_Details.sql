﻿CREATE TABLE [WFlow].[OT_TV_WBody_WFlow_Sequence_Details]
(
	 [Id]						BIGINT           IDENTITY (1, 1) NOT NULL,
	 [WBodyActivityId]			BIGINT							 NOT NULL,
	 [TaskWorkFlowStepId]		INT								 NOT NULL,
	 [PreviousStatus]			INT								 NOT NULL,
	 [CurrentStatus]			INT								 NOT NULL,
	 [Active]					BIT								 NOT NULL	CONSTRAINT [DF_WFlow_Basic] DEFAULT ((1)),
	 [CreatedBy]				UNIQUEIDENTIFIER				 NOT NULL,
	 [CreatedDate]				DATETIME						 NOT NULL	CONSTRAINT [DF_WFlow_Basic_Date] DEFAULT (GetDate()),
	 [ModifiedBy]				UNIQUEIDENTIFIER				 NULL,
	 [ModfiedDate]				DATETIME						 NULL,
	 CONSTRAINT [PK_TV.OT_TV_Workflow_Sequence_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	 CONSTRAINT [FK_OT_TV_WBody_WFlow_Sequence_Details_OT_TV_Wide_Body_Activity_Center] FOREIGN KEY (WBodyActivityId) REFERENCES [Edc].[OT_TV_Wide_Body_Activity_Center] ([Id]),
	 CONSTRAINT [FK_OT_TV_WBody_WFlow_Sequence_Details_LT_ST_Program_Task_WorkFlow] FOREIGN KEY([TaskWorkFlowStepId]) REFERENCES [LinkDB].[LT_ST_Program_Task_WorkFlow] ([Id]),
	 CONSTRAINT [FK_OT_TV_WBody_WFlow_Sequence_Details_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	 CONSTRAINT [FK_OT_TV_WBody_WFlow_Sequence_Details_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	 CONSTRAINT [IX_OT_TV_Wide_Body_Data_Center] UNIQUE NONCLUSTERED ([WBodyActivityId],[TaskWorkFlowStepId]),	 
)



