﻿
CREATE TABLE [WFlow].[OT_TV_WBody_WFlow_Checklist_Details](
	[Id]                   BIGINT IDENTITY(1,1) NOT NULL,
	[WBodyActivityId]      BIGINT               NOT NULL,
	[GroupChecklistOwner]  NVARCHAR(50)	            NULL,
	[WBodyWFlowSequenceId] BIGINT                   NULL,
	[ChecklistGroupId]     INT                  NOT NULL,
	[ChecklistId]          INT                  NOT NULL,
	[ChecklistValue]       INT                  NOT NULL,
	[Comments]             NVARCHAR(MAX)            NULL,
	[Active]               BIT                  NOT NULL CONSTRAINT [DF_OT_TV_WBody_WFlow_Checklist_Details_Active]  DEFAULT ((1)),
	[CreatedBy]            UNIQUEIDENTIFIER     NOT NULL,
	[CreatedDate]          DATETIME             NOT NULL CONSTRAINT [DF__OT_TV_WBo__Creat__1980B20F]  DEFAULT (getdate()),
	[ModifiedBy]           UNIQUEIDENTIFIER         NULL,
	[ModifiedDate]         DATETIME                 NULL,
 CONSTRAINT [PK_TV.OT_TV_WBody_WFlow_Checklist_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
 CONSTRAINT [FK_OT_TV_WBody_WFlow_Checklist_Details_OT_TV_WBody_WFlow_Sequence_Details] FOREIGN KEY([WBodyWFlowSequenceId]) REFERENCES [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ([Id]),
 CONSTRAINT [FK_OT_TV_WBody_WFlow_Checklist_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
 CONSTRAINT [FK_OT_TV_WBody_WFlow_Checklist_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
 )
