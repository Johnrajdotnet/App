﻿CREATE TABLE [WFlow].[OT_TV_WBody_WFlow_SAR_Details]
(
	 [Id]						BIGINT		      IDENTITY (1, 1) NOT NULL,
	 [WBodyWFlowSeqId]		BIGINT							  NOT NULL,
	 [ReferenceName]			NVARCHAR(1000)					  NOT NULL,
	 [Title] 					NVARCHAR(1000)					  NOT NULL,
	 [Comments]					NVARCHAR(1000)					  NULL,
	 [Active]					BIT								  NOT NULL	CONSTRAINT [DF_WFlow_WBody_Sar] DEFAULT ((1)),
	 [CreatedBy]				UNIQUEIDENTIFIER				  NOT NULL,
	 [CreatedDate]				DATETIME						  NOT NULL,
	 [ModifiedBy]				UNIQUEIDENTIFIER				  NULL,
	 [ModfiedDate]				DATETIME						  NULL,
	CONSTRAINT [PK_TV.OT_TV_WBody_WFlow_SAR_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_SAR_Details_OT_TV_WBody_WFlow_Sequence_Details] FOREIGN KEY ([WBodyWFlowSeqId]) REFERENCES [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ([Id]),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_SAR_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_SAR_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
)
