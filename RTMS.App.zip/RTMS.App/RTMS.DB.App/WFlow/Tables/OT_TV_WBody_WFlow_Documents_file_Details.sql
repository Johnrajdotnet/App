﻿CREATE TABLE [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details](
	[Id]                    BIGINT  IDENTITY(1,1) NOT NULL,
	[WBodyWFlowSequenceId]  BIGINT                NOT NULL,
	[FileName]              NVARCHAR(250)         NULL,
	[ProjectNamePath]       NVARCHAR(1000)        NULL,
	[ContentPath]           NVARCHAR(250)         NULL,
	[ProcessFolder]         NVARCHAR(250)         NULL,
	[ProcessVersion]        NVARCHAR(20)          NULL,
	[SubFolder]             NVARCHAR(250)         NULL,
	[CreatedBy]             UNIQUEIDENTIFIER      NOT NULL,
	[CreatedDate]           DATETIME		      NOT NULL DEFAULT (getdate()),
	[ModifiedBy]            UNIQUEIDENTIFIER      NULL,
	[ModifiedDate]          DATETIME			  NULL,
	
	CONSTRAINT [PK_TV.OT_TV_WBody_WFlow_Documents_file_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_Documents_file_Details_OT_TV_WBody_WFlow_Sequence_Details] FOREIGN KEY ([WBodyWFlowSequenceId]) REFERENCES [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ([Id]),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_Documents_file_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_OT_TV_WBody_WFlow_Documents_file_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
)