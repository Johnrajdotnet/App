﻿
-- =============================================
--PROCEDURE: [WFlow].[GetAmsTvWBodyCountForSarAndRedTop]
--PURPOSE: get count of sar and redtop
--CREATED:Arathy Jayakumar 13/05/2019
-- ============================================= 
 --declare @outId bit
 --exec [WFlow].[GetAmsTvWBodyCountForSarAndRedTop] 79726,31706,4,5, @outId out
 --print @outId

CREATE PROCEDURE [WFlow].[GetAmsTvWBodyCountForSarAndRedTop]
	-- Add the parameters for the stored procedure here
        @tvActivityDetailId  BIGINT,
		@wFlowSeqId          BIGINT,
		@sarIdCount			 INT,
		@redtopIdCount		 INT,
		@outIsRefresh		 INT OUTPUT
AS
BEGIN
		SET NOCOUNT ON;
		declare @countOfSar int,@countOfRed int
		--DECLARE @i INT

	BEGIN TRY
			
		SELECT	@countOfRed= count(id) FROM   [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details] where WBodyWFlowSeqId=@wFlowSeqId AND Active=1
		
		SELECT	@countOfSar= count(id) FROM   [WFlow].OT_TV_WBody_WFlow_SAR_Details where WBodyWFlowSeqId=@wFlowSeqId AND Active=1

		IF((@countOfRed= @redtopIdCount) AND (@countOfSar=@sarIdCount))
		BEGIN

				SET @outIsRefresh=1

		END
		
		ELSE
		BEGIN

				SET @outIsRefresh=0

		END
		END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
END


