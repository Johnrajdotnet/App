﻿
-- =============================================
--PROCEDURE:  [WFlow].[SaveorUpdateAmsTvWBodyDamageDC]
--PURPOSE: SaveorUpdateAmsTvWBodyDamageDC
--CREATED: Neethu Rose Peter 24/09/2018
-- ============================================= 
-- EXEC[WFlow].[SaveorUpdateAmsTvWBodyDamageDC]

CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyDamageDC]
       -- Add the parameters for the stored procedure here 
			  @programId           INT ,
              @StepName            NVARCHAR(50),
              @userId              UNIQUEIDENTIFIER,
              @previousScreen      INT,
              @currentScreen       INT,
              @actionFlag          NVARCHAR(10),
              @workFlowSeqId       BIGINT,
              @TVActivityDetailId  BIGINT,
			  @noOfDamage          NVARCHAR(10),
			  @damageDimensions    NVARCHAR(10),
			  @taskId			   INT,
              @outWorkFlowSeqRetId BIGINT OUTPUT
              
AS
       -- SET NOCOUNT ON added to prevent extra result sets from
BEGIN      -- interfering with SELECT statements.
BEGIN TRY


			DECLARE @RetWorkFlowSeqRetId BIGINT	
			
			------------------------------ update tv workflow extend table--------------------------------------
			UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
			SET 
				
				[TotalNumberDamages]   =  @noOfDamage,
				[DamagesWithDimensions]=  @damageDimensions,
				ModifiedBy             =  @userId,
				ModfiedDate            =  GETDATE()
			WHERE WBodyActivityId=@TVActivityDetailId	   
			
           --------------------- make Active =false all list rows in Damage table----------------------
		   UPDATE  [WFlow].[OT_TV_WFlow_WBody_Damage_Details] SET Active =0 WHERE WBodyWFlowSeqId=@workFlowSeqId

		   IF(UPPER(@actionFlag)='ADD')
		   BEGIN				
                 -----------------------------------Insert the TV WorkFlowSequence----------------------------------------   
                 EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
                               @TVActivityDetailId,@programId,@StepName,@previousScreen
                              ,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                   
                 SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId	
           END


		   ELSE IF(UPPER(@actionFlag)='UPDATE')       
		   BEGIN

				 --------------------------------Insert the TV WorkFlowSequence------------------------------------ 
				 EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
									 @TVActivityDetailId,@programId,@StepName,@previousScreen
									,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                                   
				 SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId			 
       END


	  

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
END



GO


