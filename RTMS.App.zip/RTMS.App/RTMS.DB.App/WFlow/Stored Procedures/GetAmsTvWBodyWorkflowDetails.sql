﻿

-- =============================================
-- Author:		<Neethu Rose Peter>
-- Create date: <15/02/2018,,>
-- Description:	<Get Input Collection Details>
-- ============================================= [WFlow].[GetAmsTvWBodyWorkflowDetails] 300001,9,10839
CREATE PROCEDURE [WFlow].[GetAmsTvWBodyWorkflowDetails]
	-- Add the parameters for the stored procedure here
	@tvNumber                BIGINT,
    @currentActivityScreenId INT,
    @TVActivityDetailId      BIGINT,
	@userRoleId			     UNIQUEIDENTIFIER
	
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	 DECLARE @workSeqId BIGINT=0
	 DECLARE @userName nvarchar(50)
	 DECLARE @repeatativeTemplate Nvarchar(50)
	BEGIN TRY
		 SELECT @workSeqId=[WFlow].[GetWorkSeqDetailsForTV] (@currentActivityScreenId,@TVActivityDetailId,'TV',@tvNumber)
		 SELECT @userName = [dbo].[GetOwnerNameByUserRoleId] (@userRoleId)
		
		 IF(@workSeqId=0 or @workSeqId is null)
		 BEGIN
					
					SELECT 
						dc.TVNumber       AS [TVNumber],
						ac.Id             AS TvActivityDetailId,
                        0                 AS WorkFlowSeqId,
						dc.IssueNumber    AS IssueNumber,
						dc.TVType         AS TVType,
						dc.RRPromisedDate AS  RRPromisedDate,
						@userName		  AS UserName,
						isnull( ac.CAStatus,2)  AS CAStatus,
						ed.RepeatativeTemplate AS RepeatativeTemplate

					FROM       [Edc].[OT_TV_Wide_Body_Data_Center] dc
				    INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON dc.Id=ac.TVDataCenterId
					LEFT JOIN WFlow.OT_TV_WBody_WFlow_Engine_Extend_Details ed ON ac.Id=ed.WBodyActivityId
				    WHERE dc.TVNumber=@tvNumber

			END
			ELSE
			BEGIN
										
					SELECT 
						dc.TVNumber    AS [TVNumber],
						ac.Id          AS TvActivityDetailId,
                        ws.Id          AS WorkFlowSeqId,
						dc.IssueNumber AS IssueNumber,
						dc.TVType      AS TVType,
						dc.RRPromisedDate AS  RRPromisedDate,
					--	@userName		AS UserName,
						isnull( ac.CAStatus,2)  AS CAStatus,
						ed.RepeatativeTemplate AS RepeatativeTemplate

					FROM       [Edc].[OT_TV_Wide_Body_Data_Center] dc
				    INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac      ON dc.Id=ac.TVDataCenterId
					LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ed ON ac.Id=ed.WBodyActivityId
					LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ws ON ac.Id=ws.WBodyActivityId
				    WHERE dc.TVNumber=@tvNumber 
					AND   ws.CurrentStatus=@currentActivityScreenId
			END


		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END

