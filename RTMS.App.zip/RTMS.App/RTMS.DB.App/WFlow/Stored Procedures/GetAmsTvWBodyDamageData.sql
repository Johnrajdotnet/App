﻿
-- =============================================
--PROCEDURE: [WFlow].[GetAmsTvWBodyDamageData]
--PURPOSE: Get Damage Data Collection
--CREATED: Neethu Rose Peter 14/09/2018
-- ============================================= 
-- EXEC [WFlow].[GetAmsTvWBodyDamageData]

CREATE PROCEDURE [WFlow].[GetAmsTvWBodyDamageData]
	-- Add the parameters for the stored procedure here
	@WBodyWFlowSeqId BIGINT,
	@WBodyActivityId BIGINT
	
AS
BEGIN
	
	SET NOCOUNT ON;
	BEGIN TRY

		  SELECT ex.[TotalNumberDamages]    AS NoOfDamages,
				 ex.[DamagesWithDimensions] AS DamagesWithDimension 

		  FROM       [Edc].[OT_TV_Wide_Body_Activity_Center] ac 
		  INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ex ON ac.Id=ex.[WBodyActivityId]
		  WHERE ex.[WBodyActivityId]=@WBodyActivityId


		--Get Damage Data---
			SELECT
					  da.Id                AS [id],
					  da.[DamageTypeId]    AS [DamageTypeId],
					  da.Features          AS [Features],
					  da.Geometry          AS [Geometry],
					  da.ZoneArea          AS [ZoneArea],
					  da.Length            AS [Length1],
					  da.ManualLocation    AS [ManualLocation],
					  da.SolutionReference AS [SolutionReference],
					  da.DispositionLimit  AS [DispositionLmit1],
					  da.Width             AS [Width1],
					  da.Depth             AS [Depth1],
					  da.Thickness         AS [Thickness1],
					  da.Angle             AS [Angle1],
					  da.Radius            AS [Radius1],
					  da.DiaMillmeter      AS [Diamillmeter1],
					  da.SurfaceRoughness  AS [SurfaceRoughness1],					 
			          da.CreatedBy,
					  da.CreatedDate,
					  da.ModifiedBy,
					  da.ModfiedDate

			FROM       [WFlow].[OT_TV_WFlow_WBody_Damage_Details] da 
			INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON da.WBodyWFlowSeqId=bd.Id
			WHERE      bd.Id=@WBodyWFlowSeqId and da.Active=1

	
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END





GO


