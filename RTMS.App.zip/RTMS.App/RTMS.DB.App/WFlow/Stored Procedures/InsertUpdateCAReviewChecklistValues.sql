﻿-- =============================================
--PROCEDURE: [WFlow].[InsertUpdateCAReviewChecklistValues]
--PURPOSE: Insert/Update CA checklistvalues
--CREATED: Mira 03/05/2019
-- ============================================= 
-- EXEC  [WFlow].[InsertUpdateCAReviewChecklistValues]

CREATE PROCEDURE [WFlow].[InsertUpdateCAReviewChecklistValues]
                -- Add the parameters for the stored procedure here
             	@Id INT,
				@actionFlag      NVARCHAR(10),
				@userId UNIQUEIDENTIFIER,
                @WBodyActivityId BIGINT,
                @WBodyWFlowSequenceId      BIGINT,
                @ChecklistGroupId INT,
				@ChecklistId INT,
                @ChecklistValue INT,
				@Comments nvarchar(max)
AS
BEGIN
                -- SET NOCOUNT ON added to prevent extra result sets from
                -- interfering with SELECT statements.
                SET NOCOUNT ON;
                BEGIN TRY
                --if any previous records deactivate those
                                UPDATE  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details]
                                SET 
                                    Active=0,
                                    ModifiedBy=@userId,
                                    ModifiedDate=GETDATE() 
                                WHERE
                                    WBodyActivityId=@WBodyActivityId and
                                    ChecklistGroupId=@ChecklistGroupId 
									and GroupChecklistOwner='Self'
									--and
                                   -- WBodyWFlowSequenceId=@workflowSeqId 
                                    

                -- insert the checklist record
			           IF(UPPER(@actionFlag)='ADD')
						BEGIN

                                INSERT INTO  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details]
											(
											WBodyActivityId,
                                            WBodyWFlowSequenceId,
                                            ChecklistGroupId,
											GroupChecklistOwner,
                                            ChecklistId,
                                            ChecklistValue,
											Comments,
                                            CreatedBy
											)
									values(
									        @WBodyActivityId,
											IIF(@WBodyWFlowSequenceId=0 ,null,@WBodyWFlowSequenceId ),
											@ChecklistGroupId,
											'CA',
											@ChecklistId,
											@ChecklistValue,
											IIF(@ChecklistId=36 ,@Comments,null ),
											@userId
											)
													 
                         END
						ELSE IF(UPPER(@actionFlag)='UPDATE')       
						BEGIN

								UPDATE  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details] 
								SET ChecklistValue= @ChecklistValue
                                WHERE Id = @Id 
						END                       

                END TRY
                BEGIN CATCH
                    EXECUTE [dbo].[LogError]
                END CATCH
END

