﻿

-- =============================================
--PROCEDURE: [WFlow].[SaveAmsTvWBodyDocumentsToNewFolder]    
--PURPOSE: Save the Folder Documents To New Folder.
--CREATED: Blessy Babu 07/01/2019
-- ============================================= 
-- EXEC [WFlow].[SaveAmsTvWBodyDocumentsToNewFolder] 55417,'DR','W'

CREATE PROCEDURE [WFlow].[SaveAmsTvWBodyDocumentsToNewFolder]    
	-- Add the parameters for the stored procedure here	   
	@WBodyActivityId BIGINT,
	@ToProcessFolder VARCHAR(50),
	@FromProcessFolder VARCHAR(50)
AS
BEGIN	 
	SET NOCOUNT ON;
	DECLARE @Version NVARCHAR(20)
	BEGIN TRY
         SET @Version=(SELECT  TOP 1 [ProcessVersion] 
							   FROM	[WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] df
						 INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ws ON ws.Id=df.[WBodyWFlowSequenceId]
							  WHERE ws.WBodyActivityId=@WBodyActivityId 
						   ORDER BY [ProcessVersion] DESC)

		INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details]
				(
				WBodyWFlowSequenceId,
				FileName,
				ProjectNamePath,
				ContentPath,
				ProcessFolder,
				ProcessVersion,
				SubFolder,
				CreatedBy,
				CreatedDate,
				ModifiedBy,
				ModifiedDate
				)
        SELECT   								
				d.WBodyWFlowSequenceId,
				d.FileName,
				d.ProjectNamePath,
				d.ContentPath,
				@ToProcessFolder,
				IIF(@ToProcessFolder='W',(SELECT [WFlow].[GetNewFolderVersion](@WBodyActivityId)),d.ProcessVersion),
				d.SubFolder,
				d.CreatedBy,
				d.CreatedDate,
				NULL,
				NULL 
		FROM          [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] d
		INNER JOIN    [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] w ON w.Id=d.[WBodyWFlowSequenceId]
		WHERE  ProcessVersion=@Version
		AND    w.WBodyActivityId=@WBodyActivityId
		AND    d.ProcessFolder=@FromProcessFolder
		  

	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END


