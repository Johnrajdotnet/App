﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveUpdateDraftAMSTvWBodyTVInfornationSheet]
--PURPOSE: Insert/Update TV Infornation Sheet
--CREATED: Mira 15/02/2019
-- ============================================= 
CREATE PROCEDURE [WFlow].[SaveUpdateDraftAMSTvWBodyTVInfornationSheet]
                -- Add the parameters for the stored procedure here
				@Id INT,
				@actionFlag      NVARCHAR(10),
				@userId UNIQUEIDENTIFIER,
                @WBodyActivityId BIGINT,
                @WBodyWFlowSequenceId      BIGINT,
                @ChecklistGroupId INT,
				@ChecklistId INT,
                @ChecklistValue INT,
				@Comments NVARCHAR(max)
AS
BEGIN
                -- SET NOCOUNT ON added to prevent extra result sets from
                -- interfering with SELECT statements.
                SET NOCOUNT ON;
                BEGIN TRY
                
						IF(UPPER(@actionFlag)='ADD')
						BEGIN

								INSERT INTO  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details]
											 (
												WBodyActivityId,
												WBodyWFlowSequenceId,
												ChecklistGroupId,
												ChecklistId,
												ChecklistValue,
												Comments,
												CreatedBy
											 )
								VALUES       ( 
												@WBodyActivityId,
												@WBodyWFlowSequenceId,
												@ChecklistGroupId,
												@ChecklistId,
												@ChecklistValue,
												@Comments,
												@userId
											 )
							END
							ELSE IF(UPPER(@actionFlag)='UPDATE')       
							BEGIN
									UPDATE [WFlow].[OT_TV_WBody_WFlow_Checklist_Details]
									SET    ChecklistValue=@ChecklistValue,Comments=@Comments, ModifiedBy=@userId,ModifiedDate=GETDATE()
									WHERE  @Id=Id
							END
                                                
                END TRY
                BEGIN CATCH
                    EXECUTE [dbo].[LogError]
                END CATCH
END

