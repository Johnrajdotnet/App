﻿

-- =============================================
--PROCEDURE: [WFlow].[DeleteAmsTvWBodyDocumentsFileDetails] 
--PURPOSE: Delete UploadandSubmitFile Collection
--CREATED: Blessy Babu 26/09/2018
-- ============================================= 
-- EXEC [WFlow].[DeleteAmsTvWBodyDocumentsFileDetails]   1

CREATE PROCEDURE [WFlow].[DeleteAmsTvWBodyDocumentsFileDetails]    
	-- Add the parameters for the stored procedure here
	@Id BIGINT
AS
BEGIN
	
		SET NOCOUNT ON;
		BEGIN TRY
					DELETE [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details]
					WHERE  [Id]=@Id
	       
		END TRY

		BEGIN CATCH
					EXECUTE [dbo].[LogError]
		END CATCH
END
