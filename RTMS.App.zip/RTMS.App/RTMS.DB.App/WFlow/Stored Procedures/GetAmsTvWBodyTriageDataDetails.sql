﻿
-- =============================================
-- Author:		<Mira Kumari>
-- Create date: <05/10/2018>
-- Description:	<Get Triage Data Details>
-- ============================================= [WFlow].[GetAmsTvWBodyTriageDataDetails] 190066
CREATE PROCEDURE [WFlow].[GetAmsTvWBodyTriageDataDetails]
	-- Add the parameters for the stored procedure here
	@tvNumber bigint
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
			SELECT				      
				       ed.Id,
					   dc.PartDescription,
					   dc.Operator,
					   dc.EngineMark,
					   dc.TVType,
					   dc.IssueNumber,
					   dc.TVNumber,
				       ed.WBodyActivityId,
					   ed.Dscl, 
					   ed.JudgementStatus,
					   ed.ProposalStatus, 
					   ed.ProposalReason, 
					   ed.ProposalAction, 
					   ed.RequestVariance,
				       ed.PrimaryExistingReq, 
					   ed.ExistingReq,
					   ed.PartMating , 
					   ed.PartFunction, 
					   ed.WorkScopeCreep,
					   dc.ESN,
					   dc.HSN,
					   dc.CSN,
					   dc.PlannedReBuild AS RebuildLife

			FROM       [Edc].[OT_TV_Wide_Body_Data_Center] dc 			 
			INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac            ON ac.TVDataCenterId = dc.Id			 
			LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ed  ON ac.Id = ed.[WBodyActivityId]
			WHERE      dc.TVNumber=@tvNumber
		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END




