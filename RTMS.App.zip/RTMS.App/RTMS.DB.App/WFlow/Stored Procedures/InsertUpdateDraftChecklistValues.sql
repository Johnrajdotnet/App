﻿-- =============================================
--PROCEDURE:  [WFlow].[InsertUpdateDraftChecklistValues]
--PURPOSE: Insert/Update Draft checklistvalues
--CREATED: Mira 03/05/2019
-- ============================================= 
-- EXEC  [WFlow].[InsertUpdateDraftChecklistValues]
CREATE PROCEDURE [WFlow].[InsertUpdateDraftChecklistValues]
				@Id INT,
				@actionFlag      NVARCHAR(10),
				@userId UNIQUEIDENTIFIER,
                @WBodyActivityId BIGINT,
                @WBodyWFlowSequenceId      BIGINT,
                @ChecklistGroupId INT,
				@ChecklistId INT,
                @ChecklistValue INT
AS
BEGIN
                -- SET NOCOUNT ON added to prevent extra result sets from
                -- interfering with SELECT statements.
                SET NOCOUNT ON;
                BEGIN TRY
                
				  --if any previous records deactivate those
                        UPDATE  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details]
                        SET 
                            Active=0,
                            ModifiedBy=@userId,
                            ModifiedDate=GETDATE() 
                        WHERE
                            WBodyActivityId=@WBodyActivityId and
                            ChecklistGroupId=ChecklistGroupId
							and GroupChecklistOwner='CA'
									--and
                                   -- WBodyWFlowSequenceId=@workflowSeqId 
                -- insert the checklist record
				        IF(UPPER(@actionFlag)='ADD')
						BEGIN

                                INSERT INTO  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details]
											(
											WBodyActivityId,
											WBodyWFlowSequenceId,
											GroupChecklistOwner,
											ChecklistGroupId,
											ChecklistId,
											ChecklistValue,
											CreatedBy
											)
									values(@WBodyActivityId,
											IIF(@WBodyWFlowSequenceId=0 ,null,@WBodyWFlowSequenceId ),
											'Self',
											@ChecklistGroupId,
											@ChecklistId,
											@ChecklistValue,
											@userId
											)
													 
                         END
						ELSE IF(UPPER(@actionFlag)='UPDATE')       
						BEGIN

								UPDATE  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details] 
								SET ChecklistValue= @ChecklistValue
                                WHERE Id = @Id 
						END                       
                        END TRY
                        BEGIN CATCH
                            EXECUTE [dbo].[LogError]
                        END CATCH
END


