﻿

-- =============================================
-- Author:           <arathy>
-- Create date:      <17/10/2018>
-- Description:      <delete from wflow sar and redtop on delete button click>
-- exec [WFlow].[DeleteAmsTvWBodyRedAndSARTop]
CREATE PROCEDURE [WFlow].[DeleteAmsTvWBodyRedAndSARTop]
 @id BIGINT,
 @flag NVARCHAR(20)

AS
BEGIN TRY


IF(@flag='redTop')
BEGIN
				
			  UPDATE  [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details] SET Active =0 WHERE Id=@id

				
				 
END	
ELSE IF(@flag='sar')
	BEGIN 

	            UPDATE  [WFlow].[OT_TV_WBody_WFlow_SAR_Details] SET Active =0 WHERE Id=@id

	

	END
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH