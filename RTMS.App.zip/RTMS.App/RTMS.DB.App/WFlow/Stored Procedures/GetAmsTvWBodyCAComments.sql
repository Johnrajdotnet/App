﻿
-- =============================================
--PROCEDURE:  [WFlow].[GetAmsTvWBodyCAComments]
--PURPOSE: Get CA comments
--CREATED: Mira 01/04/2019
-- ============================================= 
-- EXEC [WFlow].[GetAmsTvWBodyCAComments]  199314

CREATE PROCEDURE [WFlow].[GetAmsTvWBodyCAComments] 
                -- Add the parameters for the stored procedure here
                @TVNumber BIGINT
             
AS
BEGIN
                -- SET NOCOUNT ON added to prevent extra result sets from
                -- interfering with SELECT statements.
                SET NOCOUNT ON;
                BEGIN TRY
                        SELECT     dc.TVNumber, cd.WBodyActivityId, cd.ChecklistGroupId, cd.ChecklistId, cd.ChecklistValue, cd.Comments, cd.Active,
						           cd.CreatedDate 
						FROM       [WFlow].[OT_TV_WBody_WFlow_Checklist_Details] cd
                        LEFT JOIN  [Edc].[OT_TV_Wide_Body_Activity_Center] ac on ac.Id=cd.WBodyActivityId
                        INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] dc on dc.Id=ac.TVDataCenterId
                        WHERE      cd.ChecklistGroupId=52  AND dc.TVNumber=@TVNumber
                                   AND cd.ChecklistId=36 ORDER BY cd.CreatedDate DESC
                                                
                 END TRY
                 BEGIN CATCH
                    EXECUTE [dbo].[LogError]
                 END CATCH
END



