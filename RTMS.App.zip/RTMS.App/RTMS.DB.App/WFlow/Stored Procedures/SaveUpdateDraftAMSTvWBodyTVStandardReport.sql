﻿-- =============================================
--PROCEDURE: [WFlow].[SaveUpdateDraftAMSTvWBodyTVStandardReport] '917614d4-e741-432d-bbf4-a3c6e4546129','ADD',10725,26,'Others3','o1'
--PURPOSE:   Save Update Technical variance
--CREATED:   Mira 31/01/2019
-- ============================================= 
CREATE PROCEDURE [WFlow].[SaveUpdateDraftAMSTvWBodyTVStandardReport]
        @userId          UNIQUEIDENTIFIER,
        @actionFlag      NVARCHAR(20),
        @workFlowSeqId   BIGINT,
		@StndReportId    BIGINT,
		@StandardAttribute   NVARCHAR(250),
		@StandardAttrributeValue NVARCHAR(250)
              
AS
BEGIN  
      -- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
	
		BEGIN TRY
				  IF(UPPER(@actionFlag)='ADD')
				  BEGIN
						
						 INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Standard_Report_Details]
									 (
										WBodyWFlowSequenceId,
										StandardAttribute, 
										StandardAttrributeValue, 
										CreatedBy, 
										CreatedDate
									 )
						  VALUES		
					                 ( 
										@workFlowSeqId, 
										@StandardAttribute, 
										@StandardAttrributeValue, 
										@userId, 
										GETDATE()
									  )


			       END
				   ELSE IF(UPPER(@actionFlag)='UPDATE')       
				   BEGIN

							 UPDATE  [WFlow].[OT_TV_WBody_WFlow_Standard_Report_Details]
							  SET     
										StandardAttribute=@StandardAttribute, 
										StandardAttrributeValue=@StandardAttrributeValue, 
										ModifiedBy      =  @userId, 
										ModifiedDate    =  GETDATE()
							  WHERE     Id              =  @StndReportId

				  END
		END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END

