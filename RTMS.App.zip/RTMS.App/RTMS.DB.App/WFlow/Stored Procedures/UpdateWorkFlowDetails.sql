﻿
-- =============================================
--PROCEDURE: [WFlow].[UpdateWorkFlowDetails]
--PURPOSE: Update workflow headsup status
--CREATED: Arathy 14/09/2018
-- ============================================= 
-- EXEC [WFlow].[UpdateWorkFlowDetails]

CREATE PROCEDURE [WFlow].[UpdateWorkFlowDetails]
	-- Add the parameters for the stored procedure here
	@userId             UNIQUEIDENTIFIER,
	@tvActivityDetailId BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
			UPDATE Edc.[OT_TV_Wide_Body_Activity_Center]
			SET 
			HeadupSubmittedBy   = @userId,
			HeadupSubmittedDate = getdate()
			WHERE Id=@tvActivityDetailId
			
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END




