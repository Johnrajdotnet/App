﻿

-- =============================================
-- Author:		<Arathy Jayakumar>
-- Create date: <15/02/2018,,>
-- Description:	< [wflow].[GetPublicationCertificationDetails]>
-- EXEC  [WFlow].[GetAMSTVWBodyPublicationCertificationDetails] 'PublicationDDL','535E4-37'
-- =============================================
CREATE PROCEDURE [WFlow].[GetAMSTVWBodyPublicationCertificationDetails]
	-- Add the parameters for the stored procedure here
@actionFlag NVARCHAR(50),
@engineMark NVARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY		

	IF(@actionFlag='PublicationDDL')
		BEGIN
			  SELECT        DISTINCT re.Id as DDLValue,re.[Publication] as DDLText
					
			  FROM			[Edc].[ST_TV_Wide_Body_Manual_Ref] re
			  INNER JOIN    [Edc].[ST_TV_Wide_Body_EngType_Certification] ce ON re.[EngineSeries] =ce.[EngineSeries]
			  WHERE         re.[Active]=1 
			  AND			ce.[EngineSeries]=[dbo].[GetEngineSeriesByMark](@engineMark)
		END	
		IF(@actionFlag='EngineMarkDDL')
		BEGIN
			  SELECT        [Id] as DDLValue, [Enginemark] as DDLText
			  FROM			[Edc].[ST_TV_Wide_Body_EngType_Certification]
			  WHERE         [Active]=1 
			  
		END	
		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END


