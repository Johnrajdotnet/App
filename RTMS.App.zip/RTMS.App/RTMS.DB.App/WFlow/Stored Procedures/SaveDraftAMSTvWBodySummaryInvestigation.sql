﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveDraftAMSTvWBodySummaryInvestigation]
--PURPOSE: Update Summary Investigation
--CREATED: ARATHY 19/09/2018
--[WFlow].[SaveDraftAMSTvWBodySummaryInvestigation]
-- ============================================= 
-- [WFlow].[SaveDraftAMSTvWBodySummaryInvestigation] 

CREATE PROCEDURE [WFlow].[SaveDraftAMSTvWBodySummaryInvestigation]
       -- Add the parameters for the stored procedure here     
            
			  @tvActivityDetailId     BIGINT,
			  @summaryOfInvestigation VARBINARY(MAX),
			  @engExtendId            INT,
			  @specialOccurance       VARBINARY(MAX),
			  @redTops                VARBINARY(MAX),
			  @prevoiusOccurance      VARBINARY(MAX),
			  @futureArising          VARBINARY(MAX)
              
AS
BEGIN      
BEGIN TRY
      
       BEGIN

			------------------------------ update tv workflow extend table--------------------------------------
			UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
			SET 
				InvestigationSummary = @summaryOfInvestigation,
				SpecialistOccurance  = @specialOccurance,
                RedTops              = @redTops,
                PreviousOccurance    = @prevoiusOccurance,
                FutureArising        = @futureArising,
				ModfiedDate          =  GETDATE()
			WHERE WBodyActivityId=  @tvActivityDetailId
            
			 
       END

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
   
END CATCH
END
