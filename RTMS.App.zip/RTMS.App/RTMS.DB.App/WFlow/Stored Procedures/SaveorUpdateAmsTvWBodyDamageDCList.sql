﻿
-- =============================================
--PROCEDURE:  [WFlow].[SaveorUpdateAmsTvWBodyDamageDCList]
--PURPOSE: Insert DAMAGE DC List Data 
--CREATED: Neethu Rose Peter 24/09/2018
-- ============================================= 
-- EXEC [WFlow].[SaveorUpdateAmsTvWBodyDamageDCList]

	CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyDamageDCList]
		-- Add the parameters for the stored procedure here
			@userId           UNIQUEIDENTIFIER,
			@actionFlag       NVARCHAR(10),
			@workFlowSeqId    BIGINT,
			@damageId         INT,
			@damageTypeId     INT,
			@feature          NVARCHAR(50),
			@geometry         NVARCHAR(50),
			@manualLoc        NVARCHAR(6),
			@solutionRef      NVARCHAR(10),
			@DispositionLimit NVARCHAR(10),
			@zoneArea         NVARCHAR(6),			
			@length           NUMERIC(18,6),
			@width            NUMERIC(18,6),
			@depth            NUMERIC(18,6),
			@thickness        NUMERIC(18,6),
			@angle            NUMERIC(18,6),
			@radius           NUMERIC(18,6),
			@dia              NUMERIC(18,6),
			@surfaceroughness NUMERIC(18,6)
       
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
	
		BEGIN TRY
			  
		     IF(UPPER(@actionFlag)='UPDATE')       
		     BEGIN

					 update [WFlow].[OT_TV_WFlow_WBody_Damage_Details]
					 SET    [DamageTypeId]     = @damageTypeId, 
							[Features]         = @feature, 
							[Geometry]         = @geometry,
						    [ZoneArea]         = @zoneArea,
							[Length]           = @length,
							[Width]            = @width,
							[Depth]            = @depth,
							[Thickness]        = @thickness,
							[Angle]            = @angle,
							[Radius]           = @radius,
							[DiaMillmeter]     = @dia,
							[SurfaceRoughness] = @surfaceroughness,
							[ManualLocation]   = @manualLoc,
							[SolutionReference]= @solutionRef,
							[DispositionLimit] = @DispositionLimit,		
							[Active]=1,						 
							 ModifiedBy=@userId, ModfiedDate=GETDATE()
					 where   Id=@damageId


			  END

			   IF(UPPER(@actionFlag)='ADD')
			   BEGIN
						
					 Insert into [WFlow].[OT_TV_WFlow_WBody_Damage_Details]
							    ( WBodyWFlowSeqId,
								[DamageTypeId] , 
								[Features],
								[Geometry],
								[ZoneArea], 
								[Length],
								[Width],
								[Depth],
								[Thickness],
								[Angle],
								[Radius],
								[DiaMillmeter],
								[SurfaceRoughness],
								[ManualLocation],
								[SolutionReference],
								[DispositionLimit],
								CreatedBy, 
								CreatedDate)
						  values ( @workFlowSeqId,
								   @damageTypeId,
								   @feature,
								   @geometry,
								   @zoneArea,@length,
								   @width,
								   @depth,
								   @thickness,
								   @angle,
								   @radius,
								   @dia,
								   @surfaceroughness,
								   @manualLoc,
								   @solutionRef,
								   @DispositionLimit,
								   @userId, 
								   GETDATE())


			   END

		END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH

	END




GO


