﻿-- =============================================
-- Author:		<Blessy Babu>
-- Create date: <8/10/2018,,>
-- Description:	<Save UploadandSubmitFile Collection>
-- ============================================= 
CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyTriagefileDetails]    
	-- Add the parameters for the stored procedure here
	@WBodyWFlowBasicId BIGINT,
	@FileName          VARCHAR(250),
	@userId            UNIQUEIDENTIFIER,  
    @ProjectNamePath   NVARCHAR(1000)
AS
BEGIN	 
	SET NOCOUNT ON;
	DECLARE @fileid int
	BEGIN TRY
 
	    SET @fileid = (SELECT Id FROM [WFlow].[OT_TV_WBody_WFlow_Triage_file_Details] 
	               WHERE [FileName]=@FileName AND [ProjectNamePath]= @ProjectNamePath AND WBodyWFlowSequenceId=@WBodyWFlowBasicId)
		
		IF(@fileid>0)
			 BEGIN
				  UPDATE [WFlow].[OT_TV_WBody_WFlow_Triage_file_Details]
				  SET
				  [WBodyWFlowSequenceId] = @WBodyWFlowBasicId,
				  [FileName]             = @FileName,
				  [ModifiedBy]           = @userId,
				  [ModifiedDate]         = GETDATE(), 
                  [ProjectNamePath]      = @ProjectNamePath

				  WHERE Id = @fileid
			 END
	   ELSE
		 
			 BEGIN
					INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Triage_file_Details](
					[WBodyWFlowSequenceId],
					[FileName],
					[CreatedBy] ,
					[CreatedDate],
                    [ProjectNamePath]
					)
					VALUES (
					@WBodyWFlowBasicId,
					@FileName,
					@userId,
					GETDATE(),
					@ProjectNamePath		
					)
			  END
		  

	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END

