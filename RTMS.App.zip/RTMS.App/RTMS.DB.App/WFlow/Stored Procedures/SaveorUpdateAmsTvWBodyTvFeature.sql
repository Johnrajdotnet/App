﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveorUpdateAmsTvWBodyTvFeature]
--PURPOSE: SaveorUpdateAmsTvWBodyTVFeatureList
--CREATED: Neethu Rose Peter 24/09/2018
-- ============================================= 
-- EXEC [WFlow].[WFlow].[SaveorUpdateAmsTvWBodyTvFeature]

CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyTvFeature]
       -- Add the parameters for the stored procedure here 
			  @programId           INT ,
              @StepName            NVARCHAR(50),
              @userId              UNIQUEIDENTIFIER,
              @previousScreen      INT,
              @currentScreen       INT,
              @actionFlag          NVARCHAR(10),
              @workFlowSeqId       BIGINT,
              @TVActivityDetailId  BIGINT,
			  @taskId			   INT,
              @outWorkFlowSeqRetId BIGINT OUTPUT
              
AS
       -- SET NOCOUNT ON added to prevent extra result sets from
BEGIN      -- interfering with SELECT statements.
BEGIN TRY


          DECLARE @RetWorkFlowSeqRetId BIGINT	
			
		
			
           --------------------- make Active =false all list rows in feature table----------------------
	   UPDATE  [WFlow].[OT_TV_WFlow_WBody_Features_Details] SET Active =0 WHERE WBodyWFlowSeqId=@workFlowSeqId

       IF(UPPER(@actionFlag)='ADD')
       BEGIN
				
                 -----------------------------------Insert the TV WorkFlowSequence----------------------------------------   
                 EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
                               @TVActivityDetailId,@programId,@StepName,@previousScreen
                              ,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                   
                 SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId	
				 
				  		
				
              END


   ELSE IF(UPPER(@actionFlag)='UPDATE')       
       BEGIN

			 --------------------------------Insert the TV WorkFlowSequence------------------------------------ 
             EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
                                 @TVActivityDetailId,@programId,@StepName,@previousScreen
                                ,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                                   
               SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId

			 
       END


	  

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
END




GO


