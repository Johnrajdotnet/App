﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveorUpdateAmsTvWBodyFeatureList]
--PURPOSE: Insert tv feature List Data 
--CREATED: Neethu Rose Peter 24/09/2018
-- ============================================= 
-- EXEC [WFlow].[SaveorUpdateAmsTvWBodyFeatureList]

	CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyFeatureList]
		-- Add the parameters for the stored procedure here
			@userId           UNIQUEIDENTIFIER,
			@actionFlag       NVARCHAR(10),
			@workFlowSeqId    BIGINT,
			@featureId        INT,
			@tvNumber         BIGINT,	
			@damageTypeId     INT,		
			@feature          NVARCHAR(50),
			@geometry         NVARCHAR(50),
			@manualLoc        NVARCHAR(6),
			@solutionRef      NVARCHAR(10),
			@DispositionLimit NVARCHAR(10),
			@zoneArea         NVARCHAR(6),
			@length           NUMERIC(18,6),
			@width            NUMERIC(18,6),
			@depth            NUMERIC(18,6),
			@thickness        NUMERIC(18,6),
			@angle            NUMERIC(18,6),
			@radius           NUMERIC(18,6),
			@dia              NUMERIC(18,6),
			@surfaceroughness NUMERIC(18,6)
       
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
	
		BEGIN TRY
			  
		     IF(UPPER(@actionFlag)='UPDATE')       
		     BEGIN

					 UPDATE [WFlow].[OT_TV_WFlow_WBody_Features_Details]
						SET   [TVNumber]          = @tvNumber, 
						      [DamageTypeId]      = @damageTypeId, 
							  [Features]          = @feature, 
							  [Geometry]          = @geometry,
							  [ZoneArea]          = @zoneArea,
							  [Length]            = @length,
							  [Width]             = @width,
							  [Depth]             = @depth,
							  [Thickness]         = @thickness,
							  [Angle]             = @angle,
							  [Radius]            = @radius,
							  [Diamillmeter]      = @dia,
							  [SurfaceRoughness]  = @surfaceroughness,
							  [ManualLocation]    = @manualLoc,
							  [SolutionReference] = @solutionRef,
							  [DispositionLimit]  = @DispositionLimit,	
							  [Active]            = 1,						 
							  ModifiedBy          = @userId, 
							  ModfiedDate         = GETDATE()
					 WHERE   Id=@featureId


			  END

			   IF(UPPER(@actionFlag)='ADD')
			   BEGIN
						
					 INSERT INTO [WFlow].[OT_TV_WFlow_WBody_Features_Details]
							    ( WBodyWFlowSeqId,
								  [TVNumber] ,
								  [DamageTypeId] , 
								  [Features],
								  [Geometry],
								  [ZoneArea], 
								  [Length],
								  [Width],
								  [Depth],
								  [Thickness],
								  [Angle],
								  [Radius],
								  [DiaMillmeter],
								  [SurfaceRoughness],
								  [ManualLocation],
								  [SolutionReference],
								  [DispositionLimit],
								  CreatedBy,
								  CreatedDate)
				      VALUES      (
								  @workFlowSeqId,
								  @tvNumber,
								  @damageTypeId,
								  @feature,
								  @geometry,
								  @zoneArea,
								  @length,
								  @width,
								  @depth,
								  @thickness,
								  @angle,
								  @radius,
								  @dia,
								  @surfaceroughness,
								  @manualLoc,
								  @solutionRef,
								  @DispositionLimit,
								  @userId,
								  GETDATE())


			   END

		END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH

	END