﻿

-- =============================================
--PROCEDURE: [WFlow].[SaveorUpdateAmsTvWBodyDocumentsFileDetails]    
--PURPOSE: Save UploadandSubmitFile Collection
--CREATED: Blessy Babu 26/09/2018
-- ============================================= 
-- EXEC[WFlow].[SaveorUpdateAmsTvWBodyDocumentsFileDetails]    

CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyDocumentsFileDetails]    
	-- Add the parameters for the stored procedure here
	@WBodyWFlowBasicId BIGINT,
	@FileName          VARCHAR(250),
	@userId            UNIQUEIDENTIFIER,  
    @ProjectNamePath   NVARCHAR(1000),  
    @ContentPath       NVARCHAR(250),
	@ProcessFolder     NVARCHAR(250),
	@ProcessVersion    NVARCHAR(20),
	@SubFolder         NVARCHAR(250)
	   
AS
BEGIN	 
	SET NOCOUNT ON;
	DECLARE @fileid INT
	BEGIN TRY
 
		SET @fileid = (SELECT Id FROM [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] 
		               WHERE [FileName]=@FileName AND [ProjectNamePath]= @ProjectNamePath AND @ProcessFolder=@ProcessFolder
					         AND SubFolder=@SubFolder AND ProcessVersion=@ProcessVersion)  
		
		IF(@fileid>0)
			 BEGIN
				  UPDATE [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details]
				  SET
						  [WBodyWFlowSequenceId]=  @WBodyWFlowBasicId,
						  [FileName]            =  @FileName,
						  [ProjectNamePath]     =  @ProjectNamePath,   
						  [ContentPath]         =  @ContentPath,
						  [ProcessFolder]       =  @ProcessFolder,
						  [ProcessVersion]      =  @ProcessVersion,
						  [SubFolder]           =  @SubFolder,
						  [ModifiedBy]          =  @userId,
						  [ModifiedDate]        =  GETDATE()    
						 

				  WHERE   Id= @fileid
			 END
	   ELSE
		 
			 BEGIN
					INSERT INTO 
								[WFlow].[OT_TV_WBody_WFlow_Documents_file_Details]
				    (
								[WBodyWFlowSequenceId],
								[FileName],
								[ProjectNamePath],
								[ContentPath],
								[ProcessFolder],
	                            [ProcessVersion],
	                            [SubFolder],     
								[CreatedBy],
								[CreatedDate]
								
					)
					VALUES 
					(
								@WBodyWFlowBasicId,
								@FileName,
								@ProjectNamePath,
								@ContentPath,
								@ProcessFolder,
								@ProcessVersion,
								@SubFolder,
								@userId,
								GETDATE()
										
				    )
			  END
		  

	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END
