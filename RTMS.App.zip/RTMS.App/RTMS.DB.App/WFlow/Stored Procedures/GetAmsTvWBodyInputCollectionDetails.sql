﻿-- =============================================
--PROCEDURE: [WFlow].[GetAmsTvWBodyInputCollectionDetails]
--PURPOSE: Get Input Collection Details
--CREATED: Neethu Rose Peter 15/02/2018
-- ============================================= 
-- EXEC [WFlow].[GetAmsTvWBodyInputCollectionDetails] 300003,1,10841
CREATE PROCEDURE [WFlow].[GetAmsTvWBodyInputCollectionDetails]
	-- Add the parameters for the stored procedure here
	@tvNumber                BIGINT,
    @currentActivityScreenId INT,
    @TVActivityDetailId      BIGINT
	
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	 DECLARE @workSeqId BIGINT=0
	  
	BEGIN TRY
		 SELECT @workSeqId=[WFlow].[GetWorkSeqDetailsForTV] (@currentActivityScreenId,@TVActivityDetailId,'TV',@tvNumber)
		
		 IF(@workSeqId=0 and @TVActivityDetailId=0)
		 BEGIN
					SELECT
						dc.TVNumber                AS [TVNumber],
						dc.TVType                  AS [TVType],
						dc.ATA                     AS [AtaReference],
						dc.ReasonForRequest        AS [ReasonForEngineRemoval],
						dc.DateIn                  AS [DateIn],
						dc.ServiceLevelCategory    AS [ServiceLevelCategory],
						dc.RRPromisedDate          AS [RRPromisedDate],
						dc.EngineMark              AS [EngineMark],
						dc.PartNumber              AS [PartNumber],
						dc.PartDescription         AS [PartDescription],
						dc.Applicant               AS [Applicant],
						dc.Operator                AS [Operator],
						dc.EmpLevel                AS [EmployeeLevel],
						dc.ModuleNumber            AS [ModuleNumber],
						dc.PartSerialNumber        AS [PartSerialNumber],
						dc.Stock                   AS [Stock],
						dc.NSP                     AS [NSP],
						dc.HSN                     AS [HSN],
						dc.CSN                     AS [CSN],
						dc.HSR                     AS [HSR],
						dc.CSR                     AS [CSR],
						dc.[PlannedReBuild]        AS [PlannedRebuildLife],
						dc.Problem                 AS [ProblemDescription],
						ex.[TotalNumberDamages]    AS [TotalNoOfDamages],
						ex.[ManualInformation]     AS ManualInformation,
						ex.[NumberOffComponents]   AS NoOfComponents,
						--ex. as ManualReferenceNumber,
						ex.TVTitle                 AS TVTitle,
						ex.Material                AS Material,
						ex.[ManualTitle]           AS ManualTitle,
						dc.ApplicantsReference     AS OriginalRequestNo,
						--ex. as HSNCriticalSenModulator,
						--ex. as CSNCriticalSenModulator,
						ex.[ModuleSerialNumber]    AS ModuleSerialNumber,
						ex.[DamagesWithDimensions] AS DamageWithDimensions,
						dc.ESN                     AS EngineSerialNumberEx,
						dc.Problem                 AS ProblemDescription,
						ex.PartClassification      AS PartClassification,
						ex.Publication			   AS Publication,
						ex.PublicationReference    AS PublicationReference,
						ex.CertificationBasis	   AS CertificationBasis,
						ex.EngineType              AS EngineType

					FROM      [Edc].[OT_TV_Wide_Body_Data_Center] dc
				    LEFT JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac           ON dc.Id=ac.TVDataCenterId
				    LEFT JOIN [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ex ON ac.Id=ex.[WBodyActivityId]		
					WHERE dc.TVNumber=@tvNumber


			END
			ELSE
			BEGIN
					SELECT
						dc.TVNumber                AS [TVNumber],
						dc.TVType                  AS [TVType],
						dc.ATA                     AS [AtaReference],
						dc.ReasonForRequest        AS [ReasonForEngineRemoval],
						dc.DateIn                  AS [DateIn],
						dc.ServiceLevelCategory    AS [ServiceLevelCategory],
						dc.RRPromisedDate          AS [RRPromisedDate],
						dc.EngineMark              AS [EngineMark],
						dc.PartNumber              AS [PartNumber],
						dc.PartDescription         AS [PartDescription],
						dc.Applicant               AS [Applicant],
						dc.Operator                AS [Operator],
						dc.EmpLevel                AS [EmployeeLevel],
						dc.ModuleNumber            AS [ModuleNumber],
						dc.PartSerialNumber        AS [PartSerialNumber],
						dc.Stock                   AS [Stock],
						dc.NSP                     AS [NSP],
						dc.HSN                     AS [HSN],
						dc.CSN                     AS [CSN],
						dc.HSR                     AS [HSR],
						dc.CSR                     AS [CSR],
						dc.[PlannedReBuild]        AS [PlannedRebuildLife],
						dc.Problem                 AS [ProblemDescription],
						ex.[TotalNumberDamages]    AS [TotalNoOfDamages],
						ex.[ManualInformation]     AS ManualInformation,
						ex.[NumberOffComponents]   AS NoOfComponents,
						--ex. as ManualReferenceNumber,
						ex.TVTitle                 AS TVTitle,
						ex.Material                AS Material,
						ex.[ManualTitle]           AS ManualTitle,
						dc.ApplicantsReference     AS OriginalRequestNo,
						--ex. as HSNCriticalSenModulator,
						--ex. as CSNCriticalSenModulator,
						ex.[ModuleSerialNumber]    AS ModuleSerialNumber,
						ex.[DamagesWithDimensions] AS DamageWithDimensions,
						dc.ESN                     AS EngineSerialNumberEx,
						dc.Problem                 AS ProblemDescription,
						ex.PartClassification      AS PartClassification,
						ex.Publication			   AS Publication,
						ex.PublicationReference    AS PublicationReference,
						ex.CertificationBasis	   AS CertificationBasis,
						ex.EngineType              AS EngineType
			
					FROM      [Edc].[OT_TV_Wide_Body_Data_Center] dc
				    LEFT JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac           ON dc.Id=ac.TVDataCenterId
				    LEFT JOIN [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ex ON ac.Id=ex.[WBodyActivityId]		
					WHERE dc.TVNumber=@tvNumber 
					AND   ac.Id=@TVActivityDetailId


			END


		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END

