﻿		-- =============================================
		-- Author:		Mira Kumari
		-- Create date: 07/12/2018
		-- Description:	Get Tv wbody document file details by TV number and issue Number  
		-- EXEC  [WFlow].[GetAmsTvWBodyDocumentsFileByTVNumber] 193725,1
		-- =============================================
		CREATE procedure    [WFlow].[GetAmsTvWBodyDocumentsFileByTVNumber] 
		@TVNumber bigint,
		@IssueNumber int
		as
		begin
			 SELECT
					df.Id,dc.TVNumber, dc.IssueNumber,ac.TVDataCenterId,ws.WBodyActivityId, df.WBodyWFlowSequenceId AS WorkFlowSeqId,
					df.[FileName],df.ProjectNamePath,df.ContentPath,df.CreatedBy,df.CreatedDate,df.ModifiedBy,df.ModifiedDate
             
			 FROM		  [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] df
			 INNER JOIN  [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ws ON ws.Id=df.[WBodyWFlowSequenceId]
			 INNER JOIN  [Edc].[OT_TV_Wide_Body_Activity_Center] ac on ac.Id=ws.WBodyActivityId
			 INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center]  dc on dc.Id=ac.TVDataCenterId
			
			 WHERE dc.TVNumber=@TVNumber and dc.IssueNumber=@IssueNumber
		end
