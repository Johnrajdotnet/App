﻿-- =============================================
	-- Author:           <Mira>
	-- Create date:      <31/01/2019>
	-- Description:      Get Technical variance Details
	-- exec  [WFlow].[GetDraftAMSTvWBodyTechnicalVariance]   10725,55399
	CREATE PROCEDURE [WFlow].[GetDraftAMSTvWBodyTechnicalVariance] 
		@WBodyWFlowSeqId bigint,
		@WBodyActivityId bigint
	AS
	Begin
		 BEGIN TRY
		 ----Standard Report---
				SELECT
						sr.Id,sr.WBodyWFlowSequenceId, sr.StandardAttribute, sr.StandardAttrributeValue, sr.CreatedBy, sr.CreatedDate,
						sr.ModifiedBy, sr.ModifiedDate  

						FROM       [WFlow].[OT_TV_WBody_WFlow_Standard_Report_Details] sr 
						INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON sr.WBodyWFlowSequenceId=bd.Id
						WHERE      sr.WBodyWFlowSequenceId=@WBodyWFlowSeqId
						
						
						 
          ----Information Sheet---
			    SELECT  cd.Id,
						[AttributeGroupId]   AS GroupId,
						[AttributeName]      AS InforSheetAttribute,
						[AttributeValue]     AS InforSheetAttrributeValue,
					    cd.ChecklistValue    As Infosheet,
						cd.Comments          As Comments
			
				FROM       [Edc].[ST_TV_Register_Attribute] AS tra
				LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details] cd  
				ON         cd.ChecklistGroupId=tra.AttributeGroupId AND tra.AttributeValue=cd.ChecklistId 
				AND        cd.WBodyWFlowSequenceId=@WBodyWFlowSeqId AND cd.WBodyActivityId=@WBodyActivityId  AND cd.Active=1
				WHERE      tra.Active=1  AND tra.AttributeGroupId=53 
			    ORDER BY   CONVERT( INT, tra.AttributeValue)  ASC   
				
				                   
		 END TRY
		 BEGIN CATCH
			EXECUTE [dbo].[LogError]
		 END CATCH
	End