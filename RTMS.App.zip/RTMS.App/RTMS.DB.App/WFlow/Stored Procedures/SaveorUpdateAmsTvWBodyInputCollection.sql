﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveorUpdateAmsTvWBodyInputCollection]
--PURPOSE: Save Input Collection Details
--CREATED: Neethu Rose Peter 15/09/2018
-- ============================================= 
-- EXEC [WFlow].[SaveorUpdateAmsTvWBodyInputCollection]

CREATE PROCEDURE [WFlow].[SaveorUpdateAmsTvWBodyInputCollection]
       -- Add the parameters for the stored procedure here     
              @tvNumber            BIGINT,
			  @programId           INT ,
			  @tvTitle             NVARCHAR(max),
			  @material            NVARCHAR(max),
			  @operator            NVARCHAR(max),
			  @partdesc	           NVARCHAR(max),
			  @emplevel            NVARCHAR(250),
			  @partClassif         NVARCHAR(250),    
		      @partnum             NVARCHAR(250),
			  @enginemark          NVARCHAR(250),
			  @applicant           NVARCHAR(250),
			  @origialreqno        NVARCHAR(250),
			  @esnex               NVARCHAR(250),
			  @csn                 NVARCHAR(250),
			  @nsp                 NVARCHAR(250),
			  @hsn                 NVARCHAR(250),
			  @hsr                 NVARCHAR(250),
			  @plannedrebuildlife  NVARCHAR(250),
			  @stock               NVARCHAR(250),
			  @csr                 NVARCHAR(250),
			  @moduleno            NVARCHAR(250),
			  @totaldamage         NVARCHAR(250),
			  @damagedimension     NVARCHAR(250),
			  @partserialno        NVARCHAR(250),
			  @problemdesc         NVARCHAR(250),
              @StepName            NVARCHAR(50),
              @userId              UNIQUEIDENTIFIER,
              @previousScreen      INT,
              @currentScreen       INT,
              @actionFlag          NVARCHAR(10),
              @workFlowSeqId       BIGINT,
              @tvActivityDetailId  BIGINT,
			  @taskId			   INT,
              @outWorkFlowSeqRetId BIGINT OUTPUT,
			  @Publication         INT
              
AS
       -- SET NOCOUNT ON added to prevent extra result sets from
BEGIN      -- interfering with SELECT statements.
BEGIN TRY


          DECLARE @RetWorkFlowSeqRetId   BIGINT,
		          @ManualTitle           NVARCHAR(500),
				  @PublicationReference  NVARCHAR(250),
				  @CertificationBasis    NVARCHAR(250),
				  @EngineType            NVARCHAR(250)
		  
		  SELECT @ManualTitle= [ManualTitle], @PublicationReference=[PublicationReference]  FROM  [Edc].[ST_TV_Wide_Body_Manual_Ref]
		         WHERE 	Id = @Publication	
          SELECT @CertificationBasis=[CertificationBasis],@EngineType=[EngineType] FROM [Edc].[ST_TV_Wide_Body_EngType_Certification]
		         WHERE [Enginemark]=@enginemark      
				    
		 	   
			----------------------------Update Edc table----------------------------------

				UPDATE [Edc].[OT_TV_Wide_Body_Data_Center] SET 
					Operator            =  @operator,
					ESN                 =  @esnex,
					CSN                 =  @csn,
					NSP                 =  @nsp,
					HSR                 =  @hsr,
					HSN                 =  @hsn,
					Stock               =  @stock,
					CSR                 =  @csr,
					ModuleNumber        =  @moduleno,
					PartSerialNumber    =  @partserialno,
					Problem             =  @problemdesc,
					EngineMark          =  @enginemark,
					EmpLevel            =  @emplevel,
					ApplicantsReference =  @origialreqno,
					PartNumber          =  @partnum,
					PartDescription     =  @partdesc,
					PlannedReBuild      =  @plannedrebuildlife

					
				WHERE TVNumber=@tvNumber  	   		
                  
       IF(UPPER(@actionFlag)='ADD')
       BEGIN
	   
				IF(@taskId=1)
				
					BEGIN
	 
				------------------- Insert wFlow extend table------------------------------------
						INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
						(
						   WBodyActivityId,
						   TVTitle,
						   [EngineType],
						   [Material],
						   [PartClassification],
						   [TotalNumberDamages],
						   [DamagesWithDimensions],
						   [Publication],
						   [ManualTitle],
						   [PublicationReference],
						   [CertificationBasis],
						   Active,
						   CreatedBy,
						   CreatedDate
						)
						VALUES
						(
						@tvActivityDetailId,
						@tvTitle,
						@EngineType,
						@material,
						@partClassif,
						@totaldamage,
						@damagedimension,
						@Publication,
						@ManualTitle,
						@PublicationReference,
						@CertificationBasis,
						1,
						@userId,
						GETDATE()
						)
					END


				ELSE
					BEGIN

					------------------- Update  wFlow extend table when taskId = 2------------------------------------

						UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
					  SET 
						TVTitle                  =  @tvTitle,
						[EngineType]             =  @EngineType,
						[Material]               =  @material,
						[ModuleSerialNumber]     =  @moduleno,
						[PartClassification]     =  @partClassif,
						[TotalNumberDamages]     =  @totaldamage,
						[DamagesWithDimensions]  =  @damagedimension,
						[Publication]            =  @Publication,
						[ManualTitle]            =  @ManualTitle,
						[PublicationReference]   =  @PublicationReference,
						[CertificationBasis]     =  @CertificationBasis,
						ModifiedBy               =  @userId,
						ModfiedDate              =  GETDATE()
					WHERE WBodyActivityId=@tvActivityDetailId

				END
              



                 -----------------------------------Insert the TV WorkFlowSequence----------------------------------------   
                 EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
                               @TVActivityDetailId,@programId,@StepName,@previousScreen
                              ,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                   
                 SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId
				
              END


   ELSE IF(UPPER(@actionFlag)='UPDATE')       
       BEGIN

			------------------------------ update tv workflow extend table--------------------------------------
			UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
			SET 
				TVTitle                  =  @tvTitle,
				[EngineType]             =  @EngineType,
				[Material]               =  @material,
				[ModuleSerialNumber]     =  @moduleno,
				[PartClassification]     =  @partClassif,
				[TotalNumberDamages]     =  @totaldamage,
				[DamagesWithDimensions]  =  @damagedimension,
				[Publication]            =  @Publication,
                [ManualTitle]            =  @ManualTitle,
                [PublicationReference]   =  @PublicationReference,
                [CertificationBasis]     =  @CertificationBasis,
				ModifiedBy               =  @userId,
				ModfiedDate              =  GETDATE()
			WHERE WBodyActivityId=@tvActivityDetailId

	  
            
			 --------------------------------Insert the TV WorkFlowSequence------------------------------------ 
             EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
                                 @TVActivityDetailId,@programId,@StepName,@previousScreen
                                ,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                                   
               SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId
       END

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
   
END CATCH
END

