﻿-- =============================================
-- Author:		Mira Kumari
-- Create date: 18/12/2018
-- Description:	Insert Title Block Details  
-- =============================================
CREATE PROCEDURE [WFlow].[UpdateAmsTvWBodyDraftBlockDetails]
	-- Add the parameters for the stored procedure here
	@TVClassification int,
	@ApplicationType int,
	@ApplicationExpiryDate varchar(50),
	@GenericRepeat int,
	@GenericRepeatFrom nvarchar(250),
    @GenericRepeatNoOff nvarchar(250),
    @tvActivityDetailId  BIGINT,
	@RequestVariance     VARBINARY(max), 
	@ExistingRequirement VARBINARY(max), 
	@primaryExistReq     VARBINARY(max), 
    @EngExtendId         INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	
	SET NOCOUNT ON;
	
	BEGIN TRY
			 
			UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
			SET 
			    TVClassification         = @TVClassification,
				ApplicationType          = @ApplicationType,
			    ApplicationExpiryDate    = @ApplicationExpiryDate,
			    GenericRepeat            = @GenericRepeat,
			    GenericRepeatFrom        = @GenericRepeatFrom,
			    GenericRepeatNoOff       = @GenericRepeatNoOff,
				RequestVariance          = @RequestVariance, 
				ExistingReq			     = @ExistingRequirement,
				PrimaryExistingReq       = @primaryExistReq
			WHERE Id=@EngExtendId and WBodyActivityId=@tvActivityDetailId
	END TRY	
	BEGIN CATCH
	EXECUTE [dbo].[LogError]
	END CATCH
END
