﻿-- =============================================
-- Author:           <Mira>
-- Create date:      <21/06/2019>
-- Description:      <Retrives RedTopDetails from [Edc].[OT_TV_Wide_Body_RedTop_Center] of open>
-- exec [WFlow].[GetAmsTvWBodyRedTopOpenDetails]   198017
CREATE PROCEDURE [WFlow].[GetAmsTvWBodyRedTopOpenDetails] 
	   @TVNumber int
AS
BEGIN TRY
             declare @EngineMark varchar(50)
			 select @EngineMark= EngineMark from [Edc].[OT_TV_Wide_Body_Data_Center] where TVNumber=@TVNumber
   
			SELECT 
			r.RedTopReference as ReferenceName, r.Title
			FROM  [Edc].[OT_TV_Wide_Body_RedTop_Center] r
			WHERE ([EngineType] =@EngineMark)
			 OR   	([dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)) like '%'+@engineMark+'%'
			 AND   (DateClosed is null )
			ORDER BY [DateRaised] desc
							
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
