﻿

-- =============================================
--PROCEDURE: [WFlow].[GetAmsTvWBodyRedAndSARTopDetails]
--PURPOSE: Get Red & Sar Top Details
--CREATED: Mira Kumari 13/09/2018
-- ============================================= 
-- EXEC [WFlow].[GetAmsTvWBodyRedAndSARTopDetails] 1

CREATE PROCEDURE [WFlow].[GetAmsTvWBodyRedAndSARTopDetails]

	-- Add the parameters for the stored procedure here
	@WBodyWFlowSeqId bigint,
	@flag			nvarchar(max)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY

	IF(@flag='sar')
	BEGIN
				 SELECT
			          sd.Id as Id, 
					  sd.ReferenceName as ReferenceName, 
					  sd.Title as Title, 
					  sd.Comments as Comments
					  

		   FROM       [WFlow].[OT_TV_WBody_WFlow_SAR_Details] sd
		   INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON sd.WBodyWFlowSeqId=bd.Id
		   WHERE       sd.WBodyWFlowSeqId=@WBodyWFlowSeqId 
		   AND         sd.Active=1


	END
	
	ELSE IF(@flag='redTop')
	BEGIN
				
			SELECT
			           rd.Id as Id, 
					   rd.ReferenceName as ReferenceName, 
					   rd.Title as Title, 
					   rd.Comments as Comments 
					  

			FROM       [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details] rd 
			INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON rd.WBodyWFlowSeqId=bd.Id
			WHERE      rd.WBodyWFlowSeqId=@WBodyWFlowSeqId 
			AND        rd.Active=1


	END
	ELSE
	BEGIN 
				--Get Red Top----
			SELECT
			           rd.Id, 
					   rd.WBodyWFlowSeqId, 
					   rd.ReferenceName, 
					   rd.Title, 
					   rd.Comments, 
					   rd.Active, 
					   rd.CreatedBy, 
					   rd.CreatedDate,
					   rd.ModifiedBy, 
					   rd.ModfiedDate

			FROM       [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details] rd 
			INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON rd.WBodyWFlowSeqId=bd.Id
			WHERE      rd.WBodyWFlowSeqId=@WBodyWFlowSeqId 
			AND        rd.Active=1

		--Get SAR Top---
		   SELECT
			          sd.Id, 
					  sd.WBodyWFlowSeqId, 
					  sd.ReferenceName, 
					  sd.Title, 
					  sd.Comments, 
					  sd.Active, 
					  sd.CreatedBy, 
					  sd.CreatedDate, 
					  sd.ModifiedBy, 
					  sd.ModfiedDate

		   FROM       [WFlow].[OT_TV_WBody_WFlow_SAR_Details] sd
		   INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON sd.WBodyWFlowSeqId=bd.Id
		   WHERE       sd.WBodyWFlowSeqId=@WBodyWFlowSeqId 
		   AND         sd.Active=1


	END
	END TRY
	BEGIN CATCH
	EXECUTE [dbo].[LogError]
	END CATCH
END



