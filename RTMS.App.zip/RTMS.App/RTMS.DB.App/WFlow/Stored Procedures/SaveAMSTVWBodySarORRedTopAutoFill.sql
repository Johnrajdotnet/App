﻿-- =============================================
-- Author:           <arathy>
-- Create date:      <17/10/2018>
-- Description:      <>
-- exec [WFlow].[SaveAMSTVWBodySarORRedTopAutoFill] 91179,31226,'917614d4-e741-432d-bbf4-a3c6e4546129','1300,2468'
CREATE PROCEDURE [WFlow].[SaveAMSTVWBodySarORRedTopAutoFill]
 @tvActivityDetailId bigint,
 @wFlowSeqId bigint,
 @userId uniqueidentifier,
@actionFlag nvarchar(10),
 @sarOrRedtopId nvarchar(max)
AS
BEGIN TRY


IF(@actionFlag='sar')
BEGIN
   
				INSERT INTO [WFlow].[OT_TV_WBody_WFlow_SAR_Details]
					(
					[WBodyWFlowSeqId],
					[ReferenceName],
					[Title],
					[Active],
					[CreatedBy],
					[CreatedDate]
					)


					SELECT 
					@wFlowSeqId,
					[SARNumber],         
					[Title]   ,          
					1,
					@userId,
					getdate()

					FROM   [Edc].[OT_TV_Wide_Body_Sar_Center]
					WHERE Id IN (SELECT * FROM [dbo].[StringToTableValue](@sarOrRedtopId,','))
				 
END	
ELSE IF(@actionFlag='redtop')
	BEGIN 

	INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details]
					(
					[WBodyWFlowSeqId],
					[ReferenceName],
					[Title],
					[Active],
					[CreatedBy],
					[CreatedDate]
					)


					SELECT 
					@wFlowSeqId,
					[RedTopReference],         
					[Title]   ,          
					1,
					@userId,
					getdate()

					FROM   [Edc].[OT_TV_Wide_Body_RedTop_Center]
					WHERE Id IN (SELECT * FROM [dbo].[StringToTableValue](@sarOrRedtopId,','))


	END
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH