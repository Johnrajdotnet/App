﻿
-- =============================================
-- Author:		ARATHY
-- Create date: <05/10/2018>
-- Description:	<Get EXTEND TABLE Details> 193703
-- ============================================= [WFlow].[GetDraftAMSTvWBodySummaryInvestigation] 190066
CREATE PROCEDURE [WFlow].[GetDraftAMSTvWBodySummaryInvestigation]
	-- Add the parameters for the stored procedure here
	@tvNumber bigint,
	@TVActivityDetailId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
			SELECT				      
				       IIF(ed.RepeatativeTemplate IS NOT NULL,
			           (ISNULL(ed.InvestigationSummary,([TSection].[GetSectionContent](ed.RepeatativeTemplate,'Summary of Investigation')))),
				       ed.InvestigationSummary) AS InvestigationSummary,
					   IIF(ed.RepeatativeTemplate IS NOT NULL,
			           (ISNULL(ed.SpecialistOccurance,([TSection].[GetSectionContent](ed.RepeatativeTemplate,'Specialist Concurrence')))),
				       ed.SpecialistOccurance)  AS SpecialistOccurance,
					   ed.TVClassification      AS TVClassification,
                       ed.RedTops               AS RedTops,
                       ed.PreviousOccurance     AS PreviousOccurance,
					   IIF(ed.RepeatativeTemplate IS NOT NULL,
			           (ISNULL(ed.FutureArising,([TSection].[GetSectionContent](ed.RepeatativeTemplate,'Future Arising')))),
				       ed.FutureArising)        AS FutureArising

			FROM       [Edc].[OT_TV_Wide_Body_Data_Center] dc 			 
			INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac            ON ac.TVDataCenterId = dc.Id			 
			LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ed  ON ac.Id = ed.[WBodyActivityId]
			WHERE      dc.TVNumber=@tvNumber
			AND        ac.Id=@TVActivityDetailId
		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END


