﻿-- =============================================
-- Author:		Mira Kumari
-- Create date: 18/12/2018
-- Description:	Get Title Block Details  
-- EXEC [WFlow].[GetDraftTvWBodyDraftBlock] 195399,55304
-- =============================================

CREATE PROCEDURE [WFlow].[GetDraftTvWBodyDraftBlock]
	-- Add the parameters for the stored procedure here
	@tvNumber                BIGINT,
    @TVActivityDetailId      BIGINT
	
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	BEGIN TRY
		 
			SELECT
			    ex.TVClassification,
			    ex.ApplicationType ,  
			    ex.ApplicationExpiryDate , 
			    ex.GenericRepeat  ,          
			    ex.GenericRepeatFrom ,      
			    ex.GenericRepeatNoOff ,     
				ex.Id,						
				IIF(ex.RepeatativeTemplate IS NOT NULL,
			       (ISNULL(ex.ExistingReq,([TSection].[GetSectionContent](ex.RepeatativeTemplate,'Existing Requirement')))),
				    ex.ExistingReq)         AS ExistingReq,
				IIF(ex.RepeatativeTemplate IS NOT NULL,
			       (ISNULL(ex.PrimaryExistingReq,([TSection].[GetSectionContent](ex.RepeatativeTemplate,'Primary Existing Requirement')))),
				    ex.PrimaryExistingReq)  AS PrimaryExistingReq,
				IIF(ex.RepeatativeTemplate IS NOT NULL,
			       (ISNULL(ex.RequestVariance,([TSection].[GetSectionContent](ex.RepeatativeTemplate,'Primary Existing Requirement')))),
				    ex.RequestVariance)     AS RequestVariance
				
			
			FROM      [Edc].[OT_TV_Wide_Body_Data_Center] dc
			LEFT JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac           ON dc.Id=ac.TVDataCenterId
			LEFT JOIN [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ex ON ac.Id=ex.[WBodyActivityId]		
			WHERE dc.TVNumber=@tvNumber 
			AND   ac.Id=@TVActivityDetailId

		
	END TRY
	BEGIN CATCH
	EXECUTE [dbo].[LogError]
	END CATCH
END
