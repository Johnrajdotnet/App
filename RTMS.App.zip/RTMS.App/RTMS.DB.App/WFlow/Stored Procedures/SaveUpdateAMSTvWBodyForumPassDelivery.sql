﻿-- =============================================
--PROCEDURE: [Edc].[UpdateForumPassDelivery]
--PURPOSE: Update tv forum Pass Details
--CREATED: Mira 3/1/2019
-- ============================================= 
-- EXEC [Edc].[UpdateTVStatusByCA]

CREATE PROCEDURE [WFlow].[SaveUpdateAMSTvWBodyForumPassDelivery]
	-- Add the parameters for the stored procedure here
	@UserID UNIQUEIDENTIFIER,
	@tvActivityDetailId BIGINT,
	@forumPassURL    NVARCHAR(50),
	@forumPassId     NVARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	DECLARE @TempTable TABLE (Id INT IDENTITY (1,1), TVNumber BIGINT,ProjectNamePath NVARCHAR(1000),
	                         ContentPath NVARCHAR(250),ProcessVersion NVARCHAR(10))
	SET NOCOUNT ON;
	BEGIN TRY
			UPDATE Edc.[OT_TV_Wide_Body_Activity_Center]
			SET 
			DeliveredBy   = @UserID,
			DeliveredDate = getdate()
			WHERE Id=@tvActivityDetailId
			  
			UPDATE WFlow.OT_TV_WBody_WFlow_Engine_Extend_Details
			SET 
					ForumPassURL =  @forumPassURL,
					ForumPassId   = @forumPassId
			WHERE   WBodyActivityId=@tvActivityDetailId


	------ Inserting the Deliverable files into edc Documents Table
			  
			INSERT INTO @TempTable (TVNumber,ProjectNamePath,ContentPath,ProcessVersion)
			SELECT 
			DISTINCT  								
					dc.TVNumber,
					d.ProjectNamePath,
					d.ContentPath,
					d.ProcessVersion
					FROM          [WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] d
					INNER JOIN    [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] w ON w.Id=d.[WBodyWFlowSequenceId]
					INNER JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON ac.Id=w.WBodyActivityId
					INNER JOIN    [Edc].[OT_TV_Wide_Body_Data_Center] dc ON dc.Id= ac.TVDataCenterId
					WHERE  w.WBodyActivityId=@tvActivityDetailId
					AND    d.ProcessFolder='D'


			INSERT INTO [Edc].[OT_TV_Wide_Body_Documents_Details]
				(
				[TVNumber],             
                [ProjectNamePath],     
                [ContentPath] ,          
                [ProcessVersion] ,        
                [Active],             
                [CreatedBy] ,             
                [CreatedDate]
		  		)
            SELECT   								
				TVNumber,
				ProjectNamePath,
				ContentPath,
				ProcessVersion,
				0,
				@UserID,
				GetDate()
		    FROM   @TempTable  
		
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END


