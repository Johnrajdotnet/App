﻿
-- =============================================
--PROCEDURE: [WFlow].[GetAmsTvWBodyTVFeatures]
--PURPOSE: Get TV Features data
--CREATED: Neethu Rose Peter 14/09/2018
-- ============================================= 
-- EXEC [WFlow].[GetAmsTvWBodyTVFeatures] 1

CREATE PROCEDURE [WFlow].[GetAmsTvWBodyTVFeatures]
	-- Add the parameters for the stored procedure here
	@WBodyWFlowSeqId bigint
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		--Get Damage Data---
			SELECT
					  da.Id                AS [Id],
					  da.[TVNumber]        AS [TVNumber],
					  da.DamageTypeId      AS [damageTypeId],
					  da.Features          AS [Features],
					  da.Geometry          AS [Geometry],
					  da.ZoneArea          AS [ZoneArea],
					  da.Length            AS [Length1],
					  da.ManualLocation    AS [ManualLocation],
					  da.SolutionReference AS [SolutionReference],
					  da.DispositionLimit  AS [DispositionLmit1],
					  da.Width             AS [Width1],
					  da.Depth             AS [Depth1],
					  da.Thickness         AS [Thickness1],
					  da.Angle             AS [Angle1],
					  da.Radius            AS [Radius1],
					  da.Diamillmeter      AS [Diamillmeter1],
					  da.SurfaceRoughness  AS [SurfaceRoughness1],					  
			          da.CreatedBy,
					  da.CreatedDate,
					  da.ModifiedBy,
					  da.ModfiedDate
			FROM       [WFlow].[OT_TV_WFlow_WBody_Features_Details] da 
			INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] bd ON da.WBodyWFlowSeqId=bd.Id
			WHERE      da.WBodyWFlowSeqId=@WBodyWFlowSeqId and da.Active=1

	
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END