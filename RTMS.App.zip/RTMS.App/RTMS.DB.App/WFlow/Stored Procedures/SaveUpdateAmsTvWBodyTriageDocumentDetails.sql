﻿
	-- =============================================
	-- Author:		Mira Kumari
	-- Create date: 05/10/2018
	-- Description:	Insert Triage Details  
	-- =============================================
	CREATE PROCEDURE [WFlow].[SaveUpdateAmsTvWBodyTriageDocumentDetails]
		-- Add the parameters for the stored procedure here
		@userId              UNIQUEIDENTIFIER,
        @actionFlag          NVARCHAR(10),
		@WBodyActivityId     BIGINT,
        @Dscl                INT, 
		@WorkScopeCreep      BIT,
		@JudgementStatus     NVARCHAR(50), 
		@ProposalStatus      NVARCHAR(10), 
		@ProposalReason      NVARCHAR(max), 
		@ProposalAction      INT, 
		@RequestVariance     VARBINARY(max), 
		@ExistingRequirement VARBINARY(max), 
		@PartMating          VARBINARY(max), 
		@PartFunction        VARBINARY(max), 	
        @EngExtendId         INT
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
	
		BEGIN TRY

			  IF(UPPER(@actionFlag)='ADD')
			  BEGIN
				   INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
				   (
				   WBodyActivityId,
				   Dscl, 
				   JudgementStatus,
				   ProposalStatus, 
				   ProposalReason, 
				   ProposalAction, 
				   RequestVariance, 
				   PrimaryExistingReq, 
				   PartMating, 
				   PartFunction, 
				   WorkScopeCreep, 
				   CreatedBy, 
				   CreatedDate
				   ) 
				   VALUES
				   (
				   @WBodyActivityId,
				   @Dscl, 
				   @JudgementStatus,
				   @ProposalStatus, 
				   @ProposalReason, 
				   @ProposalAction,
				   @RequestVariance, 
				   @ExistingRequirement, 
				   @PartMating, 
				   @PartFunction, 
				   @WorkScopeCreep, 
				   @userId, 
				   GETDATE())
			  END


		      ELSE IF(UPPER(@actionFlag)='UPDATE')       
		      BEGIN
			    UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
				SET 
					WBodyActivityId      =  @WBodyActivityId, 
					Dscl                 =  @Dscl, 
					JudgementStatus      =  @JudgementStatus,
					ProposalStatus       =  @ProposalStatus, 
					ProposalReason       =  @ProposalReason, 
					ProposalAction       =  @ProposalAction,
					RequestVariance      =  @RequestVariance, 
					PrimaryExistingReq  =  @ExistingRequirement, 
					PartMating           =  @PartMating, 
					PartFunction         =  @PartFunction, 
					WorkScopeCreep       =  @WorkScopeCreep
			  WHERE Id=@EngExtendId

			  END
		END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
	END


