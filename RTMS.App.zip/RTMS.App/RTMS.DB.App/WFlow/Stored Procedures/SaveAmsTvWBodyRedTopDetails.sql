﻿
	
-- =============================================
--PROCEDURE: [WFlow].[SaveAmsTvWBodyRedTopDetails]
--PURPOSE: Insert RedTop Details 
--CREATED: Mira Kumari 13/09/2018
-- ============================================= 
-- EXEC[WFlow].[SaveAmsTvWBodyRedTopDetails]

	CREATE PROCEDURE [WFlow].[SaveAmsTvWBodyRedTopDetails]
		-- Add the parameters for the stored procedure here
		@userId          UNIQUEIDENTIFIER,
        @actionFlag      NVARCHAR(10),
        @workFlowSeqId   BIGINT,
		@ReferenceName   NVARCHAR(1000),
		@Title           NVARCHAR(1000),
		@Comments        NVARCHAR(1000),
        @RedTopId        INT
       
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
	
		BEGIN TRY

			   DECLARE @RetWorkFlowSeqRetId BIGINT	
			   IF(UPPER(@actionFlag)='ADD')
			   BEGIN
					 INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details]
									 (
									   WBodyWFlowSeqId,
									   ReferenceName, 
									   Title, 
									   Comments,
									   Active, 
									   CreatedBy, 
									   CreatedDate
									   )
					  VALUES		
					                  ( 
									   @workFlowSeqId, 
									   @ReferenceName, 
									   @Title, 
									   @Comments,
									   1,
									   @userId, 
									   GETDATE()
									   )

					  END


		     ELSE IF(UPPER(@actionFlag)='UPDATE')       
		     BEGIN

					 UPDATE  [WFlow].[OT_TV_WBody_WFlow_Red_Top_Details]
					 SET     ReferenceName   =  @ReferenceName, 
							 Comments        =  @Comments,
							 Active          =  1, 
							 ModifiedBy      =  @userId, 
							 ModfiedDate     =  GETDATE()
					 WHERE   Id=@RedTopId


			  END
		END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
	END



GO


