﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveOrUpdateWorkFlowSequenceDetails] 
--PURPOSE: SaveorUpdate workflow sequence details
--CREATED: Neethu Rose Peter 19/09/2018
-- ============================================= 
-- EXEC [WFlow].[SaveOrUpdateWorkFlowSequenceDetails] 

CREATE PROCEDURE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]  
	-- Add the parameters for the stored procedure here
        @TVActivityDetailId  BIGINT,
		@programId           INT,
        @StepName            NVARCHAR(50),
        @previousScreen      INT,
        @currentScreen       INT,
        @userId              UNIQUEIDENTIFIER,
        @workFlowSeqId       BIGINT,
        @actionFlag          NVARCHAR(10),
		@taskId				 INT,
        @outWorkFlowSeqRetId BIGINT OUTPUT
AS
BEGIN
		SET NOCOUNT ON;
		DECLARE @WorkflowStepId INT
		--DECLARE @i INT

	BEGIN TRY

		 SELECT  @WorkflowStepId =[WFlow].[GetWorkflowStepId](@programId,@StepName,@taskId)

		 IF(Upper(@actionFlag)='ADD')
		 BEGIN
		--set @i=1/0
						 INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Sequence_Details]
									 (
									 TaskWorkFlowStepId
									 ,WBodyActivityId
									 ,Active
									 ,PreviousStatus
									 ,CurrentStatus
									 ,CreatedBy
									 ,CreatedDate
									 )
						  VALUES
									 (
									  @WorkflowStepId
									 ,@TVActivityDetailId
									 ,1
									 ,@previousScreen
									 ,@currentScreen
									 ,@userId
									 ,GETDATE()
									 )

						  SET @outWorkFlowSeqRetId= SCOPE_IDENTITY()
						  SELECT @outWorkFlowSeqRetId       
		  END
		  ELSE IF(Upper(@actionFlag)='UPDATE')       
		  BEGIN


						  UPDATE [WFlow].[OT_TV_WBody_WFlow_Sequence_Details]
						  SET
									 ModifiedBy=@userId
									,ModfiedDate=GETDATE()
						  WHERE      Id=@workFlowSeqId

						  SELECT @outWorkFlowSeqRetId= @@rowcount
		   END
		END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
END

