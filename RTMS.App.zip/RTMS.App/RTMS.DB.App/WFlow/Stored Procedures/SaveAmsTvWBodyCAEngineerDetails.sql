﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveAmsTvWBodyCAEngineerDetails]
--PURPOSE: Save the CA details on Draft Submit
--CREATED: Arathy 13/06/2018
-- ============================================= 

CREATE PROCEDURE [WFlow].[SaveAmsTvWBodyCAEngineerDetails]
@tvActivityDetailId bigint,
@caEngineerId int,
@userId uniqueidentifier
AS

BEGIN TRY



-- ============================ Update Activity table ======================================
			UPDATE [Edc].[OT_TV_Wide_Body_Activity_Center]
			SET [CAEngineer]= [dbo].[GetOwnerIdByUserId](@caEngineerId)
			WHERE Id=@tvActivityDetailId



	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
