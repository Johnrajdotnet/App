﻿
-- =============================================
--PROCEDURE: [WFlow].[SaveOrUpdateWorkFlowSequenceDetails] 
--PURPOSE: Update HeadsUpDecisionDetails
--CREATED: ARATHY 19/09/2018
--exec [WFlow].[UpdateDraftTvWBodyHeadsUpDecision]
-- ============================================= 
-- EXEC [WFlow].[UpdateDraftTvWBodyHeadsUpDecision] 'AirbusTA','dfdg',2,'HUDECISION','UPDATE','917614d4-e741-432d-bbf4-a3c6e4546129',0,12,30855,91502,2,@outWorkFlowSeqRetId output


CREATE PROCEDURE [WFlow].[UpdateDraftTvWBodyHeadsUpDecision]
       -- Add the parameters for the stored procedure here     
            
			  @huDecision          NVARCHAR(250),
			  @huDecisionReason    NVARCHAR(250),
			  @programId           INT ,
              @StepName            NVARCHAR(50),
			  @actionFlag          NVARCHAR(50),
              @userId              UNIQUEIDENTIFIER,
              @previousScreen      INT,
              @currentScreen       INT,
              @workFlowSeqId       BIGINT,
              @tvActivityDetailId  BIGINT,
			  @taskId				INT,
			  @repeatativeTemplate NVARCHAR(100),
              @outWorkFlowSeqRetId BIGINT OUTPUT
              
AS
       -- SET NOCOUNT ON added to prevent extra result sets from
BEGIN      -- interfering with SELECT statements.
BEGIN TRY


          DECLARE @RetWorkFlowSeqRetId BIGINT	
			

			IF EXISTS(SELECT WBodyActivityId FROM [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
					  WHERE WBodyActivityId=@tvActivityDetailId)

      
			BEGIN

			------------------------------ update tv workflow extend table--------------------------------------
					UPDATE [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
					SET 
							HUDecision          =  @huDecision,
							HUDecisionReason    =  @huDecisionReason,
							RepeatativeTemplate =  @repeatativeTemplate,
							ModifiedBy          =  @userId,
							ModfiedDate         =  GETDATE()
					WHERE WBodyActivityId=  @tvActivityDetailId

			END
			ELSE
			BEGIN 
					INSERT INTO [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details]
					 (
							[WBodyActivityId],
							HUDecision,
							HUDecisionReason,
							RepeatativeTemplate,
							Active,
							[CreatedBy],
							[CreatedDate]
				     )
					VALUES
					(
							@tvActivityDetailId,
							@huDecision,
							@huDecisionReason,
							@repeatativeTemplate,
							1,
							@userId,
							GETDATE()
					)
			END
	  
		
			 --------------------------------Insert the TV WorkFlowSequence------------------------------------ 
             EXECUTE [WFlow].[SaveOrUpdateWorkFlowSequenceDetails]
                                 @TVActivityDetailId,@programId,@StepName,@previousScreen
                                ,@currentScreen,@userId,@workFlowSeqId,@actionFlag,@taskId,@RetWorkFlowSeqRetId OUTPUT
                                                   
               SET @outWorkFlowSeqRetId=@RetWorkFlowSeqRetId
	

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
   
END CATCH
END
