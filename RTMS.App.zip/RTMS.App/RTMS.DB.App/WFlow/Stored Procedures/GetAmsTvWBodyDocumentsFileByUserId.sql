﻿
-- =============================================
--PROCEDURE: [WFlow].[GetAmsTvWBodyDocumentsFileByUserId] 
--PURPOSE: Get UploadandSubmitFile Collection
--CREATED: Blessy Babu 26/09/2018
-- ============================================= 
-- EXEC [WFlow].[GetAmsTvWBodyDocumentsFileByUserId] 

CREATE PROCEDURE [WFlow].[GetAmsTvWBodyDocumentsFileByUserId]    
	-- Add the parameters for the stored procedure here	
	@UserId          uniqueidentifier,
	@WBodyActivityId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
			SELECT
				df.[Id]			          AS Id,
				df.[WBodyWFlowSequenceId] AS [WorkFlowSeqId],
				df.[FileName]		      AS [FileName],
				df.[ProjectNamePath]      AS [ProjectNamePath],
                df.[ContentPath]          AS [ContentPath],
				df.[ProcessFolder]        AS [ProcessFolder] ,
	            df.[ProcessVersion]       AS [ProcessVersion],
	            df.[SubFolder]            AS [SubFolder],
				df.[CreatedBy]		      AS [CreatedBy] ,
				df.[CreatedDate]	      AS [CreatedDate],
				df.[ModifiedBy]	          AS [ModifiedBy],
				df.[ModifiedDate]	      AS [ModifiedDate]
				
                
			FROM		[WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] df
			INNER JOIN  [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ws ON ws.Id=df.[WBodyWFlowSequenceId]

			WHERE ws.WBodyActivityId=@WBodyActivityId 
	
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END