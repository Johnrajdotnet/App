﻿
-- =============================================
--FUNCTION: [WFlow].[GetWorkSeqDetailsForTV] 
--PURPOSE: return workflow step id
--CREATED: Neethu Rose Peter 18/09/2018
-- ============================================= 
-- EXEC [WFlow].[GetWorkSeqDetailsForTV]  1,0,'TV',300001

CREATE FUNCTION [WFlow].[GetWorkSeqDetailsForTV] 
(
   @CurrentActivityScreenId INT
  ,@TVActivityDetailId BIGINT
  ,@TaskType NVARCHAR(10)
  ,@tvNumber bigint
)
RETURNS  INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE @workSequenceDetailId INT=0
	DECLARE @itemcount int=0
	DECLARE @tvActivityId int
	---
	IF(@TVActivityDetailId>0)
	BEGIN
	
		SET	   @workSequenceDetailId =(SELECT wk.Id  
		FROM [Edc].[OT_TV_Wide_Body_Activity_Center] ac
		INNER JOIN  [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] wk 
		ON wk.[WBodyActivityId]=ac.Id
		WHERE      ac.Id=@TVActivityDetailId 
		AND        wk.CurrentStatus=@CurrentActivityScreenId)

	END
    ELSE 
	BEGIN

		SET @tvActivityId = (SELECT ac.Id 
		FROM  [Edc].[OT_TV_Wide_Body_Data_Center] dc
		INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac 
		ON dc.Id = ac.[TVDataCenterId] where dc.TVNumber=@tvNumber)

		SET	   @itemcount =(SELECT count(*)  FROM [Edc].[OT_TV_Wide_Body_Activity_Center] ac
		INNER JOIN  [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] wk ON wk.[WBodyActivityId]=ac.Id
		WHERE      ac.Id=@tvActivityId 
		AND        wk.CurrentStatus=@CurrentActivityScreenId)

		IF(@itemcount=0)
		BEGIN
			SET	   @workSequenceDetailId =0
		END
		ELSE
		BEGIN

			SET	   @workSequenceDetailId =(SELECT wk.Id  
			FROM [Edc].[OT_TV_Wide_Body_Activity_Center] ac
			INNER JOIN  [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] wk ON wk.[WBodyActivityId]=ac.Id
			WHERE      ac.Id=@tvActivityId 
			AND        wk.CurrentStatus=@CurrentActivityScreenId)
		END 
	END

	
	-- Return the result of the function
	RETURN @workSequenceDetailId


END


GO


