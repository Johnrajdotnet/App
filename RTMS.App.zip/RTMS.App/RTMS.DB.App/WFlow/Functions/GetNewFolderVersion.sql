﻿
-- =============================================
--FUNCTION: [WFlow].[[GetNewFolderVersion]]
--PURPOSE: return new Folder Version
--CREATED: Blessy Babu 4/01/2019
-- ============================================= 
-- print [WFlow].[GetNewFolderVersion] (55307)

CREATE FUNCTION  [WFlow].[GetNewFolderVersion]
(
	-- Add the parameters for the function here
	  @WBodyActivityId int
)
RETURNS NVARCHAR(20)
AS
BEGIN
	-- Declare the return variable here
	 DECLARE @folderVersionNumber NVARCHAR(20)
     DECLARE @issueNumber NVARCHAR(3)
     DECLARE @versionNumber INT

	 SET @folderVersionNumber=(SELECT  TOP 1 [ProcessVersion] 
	                            FROM	[WFlow].[OT_TV_WBody_WFlow_Documents_file_Details] df
			              INNER JOIN    [WFlow].[OT_TV_WBody_WFlow_Sequence_Details] ws ON ws.Id=df.[WBodyWFlowSequenceId]
						       WHERE    ws.WBodyActivityId=@WBodyActivityId 
                            ORDER BY    [ProcessVersion] DESC) 
	
	-- Add the T-SQL statements to compute the return value here
	SELECT @issueNumber=SUBSTRING(@folderVersionNumber, 1, 2)
    SELECT @versionNumber=SUBSTRING(@folderVersionNumber, 4, 2)
    SET @versionNumber=@versionNumber+1
	SET @folderVersionNumber=@issueNumber+'_'+FORMAT(@versionNumber,'D2')
	
	-- Return the result of the function
	RETURN  @folderVersionNumber

END
