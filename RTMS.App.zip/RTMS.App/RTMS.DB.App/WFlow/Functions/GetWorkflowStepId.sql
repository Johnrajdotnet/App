﻿
-- =============================================
--FUNCTION: [WFlow].[GetWorkflowStepId]
--PURPOSE: return workflow step id
--CREATED: Neethu Rose Peter 19/09/2018
-- ============================================= 
-- EXEC [WFlow].[GetWorkflowStepId] 2,'INC'

CREATE FUNCTION  [WFlow].[GetWorkflowStepId]
(
	-- Add the parameters for the function here
	  @programId int
	 ,@stepName nvarchar(250)
	 ,@taskId int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @WorkflowStepId INT


	-- Add the T-SQL statements to compute the return value here
	SELECT @WorkflowStepId=Id FROM [Admin].[Syn_ST_Program_Task_WorkFlow_Step]
							      WHERE ProgramId=@programId and UPPER(RTRIM(StepName))=UPPER(RTRIM(@stepName))
								  and TaskId=@taskId

	-- Return the result of the function
	RETURN  @WorkflowStepId

END
GO


