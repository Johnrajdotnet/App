﻿CREATE TABLE [TSection].[OT_Template_Section_Details]
(
	[Id]                        INT              IDENTITY (1, 1)NOT NULL ,
	[TemplateSectionDetailId]   INT              NOT NULL,
	[ContentObject]             VARBINARY(MAX)   NULL,
	[Active]                    BIT              NOT NULL,
	[CreatedBy]                 UNIQUEIDENTIFIER NOT NULL,
	[CreatedDate]               DATETIME         NOT NULL,
	[ModifiedBy]                UNIQUEIDENTIFIER     NULL,
	[ModifiedDate]              DATETIME             NULL,
	CONSTRAINT [PK_Temp.OT_Template_Section_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_Template_Section_Details_ST_Template_Section_Details] FOREIGN KEY([TemplateSectionDetailId])REFERENCES [TSection].[ST_Template_Section_Details] ([Id]),
	CONSTRAINT [FK_OT_Template_Section_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_OT_Template_Section_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),

)
