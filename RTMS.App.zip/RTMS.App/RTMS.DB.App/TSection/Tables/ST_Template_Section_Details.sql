﻿CREATE TABLE [TSection].[ST_Template_Section_Details]
(
	[Id]            INT              NOT NULL,
	[TemplateName]  NVARCHAR(100)    NOT NULL,
	[SectionName]   NVARCHAR(100)    NOT NULL,
	[Active]        BIT              NOT NULL,
	[CreatedBy]     UNIQUEIDENTIFIER NOT NULL,
	[CreatedDate]   DATETIME         NOT NULL,
	[ModifiedBy]    UNIQUEIDENTIFIER     NULL,
	[ModifiedDate]  DATETIME             NULL,
	CONSTRAINT [PK_Temp.ST_Template_Section_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ST_Template_Section_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_ST_Template_Section_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),

)
