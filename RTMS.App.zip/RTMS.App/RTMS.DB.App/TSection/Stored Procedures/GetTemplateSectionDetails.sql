﻿-- =============================================
-- Author:		<Blessy Babu>
-- Create date: <1/07/2019>
-- Description:	<Get all Template section>
-- =============================================
CREATE PROCEDURE [TSection].[GetTemplateSectionDetails]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
			st.[Id]           AS Id,
			[TemplateName]    AS TemplateName,
            [SectionName]     AS SectionName,
			[ContentObject]   AS Content
			
		FROM      [TSection].[ST_Template_Section_Details] st 
		LEFT JOIN [TSection].[OT_Template_Section_Details] ot ON ot.[TemplateSectionDetailId] =st.Id
		WHERE st.Active=1


		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END
