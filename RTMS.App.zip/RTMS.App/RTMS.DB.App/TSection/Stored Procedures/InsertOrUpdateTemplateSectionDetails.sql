﻿-- =============================================
-- Author:		<Blessy Babu>
-- Create date: <1/07/2019>
-- Description:	<Get all Template section>
-- =============================================
CREATE PROCEDURE [TSection].[InsertOrUpdateTemplateSectionDetails]
	-- Add the parameters for the stored procedure here
@templateSectionId   INT,
@content             VARBINARY(MAX)	,
@userId              UNIQUEIDENTIFIER
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		IF EXISTS(SELECT Id FROM [TSection].[OT_Template_Section_Details] WHERE [TemplateSectionDetailId]=@templateSectionId)
		BEGIN
			UPDATE [TSection].[OT_Template_Section_Details]
			SET    [ContentObject] = @content,
				   [Active]        = 1,
				   [ModifiedBy]    = @userId,
                   [ModifiedDate]  = GETDATE()
			WHERE  [TemplateSectionDetailId]=@templateSectionId
			END
		ELSE
		BEGIN
			INSERT INTO [TSection].[OT_Template_Section_Details]
			      (
					[TemplateSectionDetailId],
					[ContentObject],
					[Active],
					[CreatedBy],
					[CreatedDate]
				   )
			SELECT
					@templateSectionId,
					@content,
					1,
					@userId,
					GETDATE()
		       
		END
		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END