﻿-- =============================================
--FUNCTION: [TSection].[GetSectionContent]
--PURPOSE: return content of ther particular template section
--CREATED: Blessy Babu 4/01/2019
-- ============================================= 
-- print [TSection].[GetSectionContent] (55307)

CREATE FUNCTION  [TSection].[GetSectionContent]
(
	-- Add the parameters for the function here
	  @templateName NVARCHAR(100),
	  @sectionName NVARCHAR(100)
)
RETURNS VARBINARY(max)
AS
BEGIN
	-- Declare the return variable here
	 DECLARE @content VARBINARY(max)

	 SET @content=(SELECT [ContentObject] FROM [TSection].[OT_Template_Section_Details] ot
				                               INNER JOIN [TSection].[ST_Template_Section_Details] st ON st.Id=ot.TemplateSectionDetailId
											   WHERE st.TemplateName=@templateName AND st.SectionName=@sectionName) 
	
	-- Add the T-SQL statements to compute the return value here
	
	
	-- Return the result of the function
	RETURN  @content

END
