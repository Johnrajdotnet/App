﻿-- =============================================
-- Author:           <Mira>
-- Create date:      <07/03/2019>
-- Description:      <Retrives latest upload drawing Details
-- exec [Mail].[GetDrawingUploadDetail] 
CREATE PROCEDURE [Mail].[GetDrawingUploadDetail] 
@TVDrawingPartNumber [Edc].[TVDrawingPartNumber] READONLY
AS
BEGIN TRY
     SELECT              otd.[FileName]                 AS FileName,
                         otd.[PartNumber]               AS PartNumber,
                         otd.[PartDescription]          AS PartDescription,
                         CONVERT(date, otd.[IssueDate]) AS IssueDate,
                         otd.[Revision]                 AS Revision,
                         otd.[Series]                   AS Series,
                         otd.[FilePath]                 AS FilePath,
						 otd.[CpiritLink]			   AS CpiritLink
                         
              FROM        [Edc].[OT_TV_Drawing_Details] otd
			  INNER JOIN  @TVDrawingPartNumber dp ON  dp.PartNumber= otd.PartNumber AND dp.EngineType=otd.Series 
			  WHERE       [Active]=1    
			
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH