
-- =============================================
-- Author:           <Arathy>
-- Create date: <20/03/2017>
-- Description:      <Gets List oF Manager email address>
-- =============================================
--EXEC [Mail].[GetWipManagerDetails] '2'
CREATE PROCEDURE [Mail].[GetEmailIdForDataImportSuccess]

AS
BEGIN
       SET NOCOUNT ON;

       BEGIN TRY
              BEGIN
					
					SELECT EmailAddress 
					FROM   [Admin].[Syn_ST_Users] 
					WHERE UserId=1003098  AND Active=1
					
              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END
