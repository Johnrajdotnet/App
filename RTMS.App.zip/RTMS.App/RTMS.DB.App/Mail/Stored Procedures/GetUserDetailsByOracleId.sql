﻿
-- =============================================
-- Author:           <Anupa>
-- Create date: <05-04-2017>
-- Description:      <Sp to fetch credentials of a particular user>
--[mail].[GetUserDetailsByOracleId] '1011116'
-- =============================================
CREATE PROCEDURE [Mail].[GetUserDetailsByOracleId] --'1011116'--'cdd388bf-dad0-4e0a-82cd-c45c2f42920a'
       @Userid int,
          @Oracleid bigint
AS
BEGIN
       SET NOCOUNT ON;

       DECLARE  @Id INT
       SELECT @Id = Id FROM Admin.ST_Users WHERE UserId = @Oracleid

       BEGIN TRY


              IF EXISTS(SELECT * FROM Admin.ST_User_RR_Credential WHERE UserId = @Id)
                     BEGIN
                             SELECT 
                                         u.UserId as [UserId],
                                         --u.UserName as [UserName],
                                         u.FirstName as [FirstName],
                                         u.MiddleName as [MiddleName],
                                         u.LastName as [LastName],
                                         u.EmailAddress as [EmailAddress],
                                         u.ExpiryDate as [ExpiryDate],
                                         u.Active as [Active],
                                         urm.Id as UniqueId,
                                         ngc.RRCareId as RRCareID

                                  FROM   
                                         [Admin].[Syn_ST_Users] u 
                                         INNER JOIN Admin.Syn_ST_User_Role_Module urm ON u.Id = urm.UserId 
                                         INNER JOIN Admin.Syn_ST_User_RR_Credential ngc ON u.Id = ngc.UserId
                                  WHERE ( u.UserId = @Oracleid OR u.Id = @Userid) AND U.Active=1

             
                      END

              ELSE if EXISTS(SELECT * FROM  [Admin].[Syn_ST_Users] where UserId= @Oracleid and Active=1 )

                     BEGIN
                             SELECT 
                                         u.UserId as [UserId],
                                         --u.UserName as [UserName],
                                         u.FirstName as [FirstName],
                                         u.MiddleName as [MiddleName],
                                         u.LastName as [LastName],
                                         u.EmailAddress as [EmailAddress],
                                         u.ExpiryDate as [ExpiryDate],
                                         u.Active as [Active],
                                         urm.Id as UniqueId,
                                         '' as RRCareID

                                  FROM   
                                         [Admin].[Syn_ST_Users] u 
                                         INNER JOIN Admin.Syn_ST_User_Role_Module urm ON u.Id = urm.UserId 
                                          WHERE u.Active=1 and u.UserId = @Oracleid OR u.Id = @Userid
                     END

                        ELSE
                              BEGIN
                                 SELECT 
                                         u.UserId as [UserId],
                                         --u.UserName as [UserName],
                                         u.FirstName as [FirstName],
                                         u.MiddleName as [MiddleName],
                                         u.LastName as [LastName],
                                         u.EmailAddress as [EmailAddress],
                                         u.ExpiryDate as [ExpiryDate],
                                         u.Active as [Active],
                                         urm.Id as UniqueId,
                                         '' as RRCareID

                                  FROM   
                                         [Admin].[Syn_ST_Users] u 
                                         INNER JOIN Admin.Syn_ST_User_Role_Module urm ON u.Id = urm.UserId 
                                          WHERE ( u.UserId = @Oracleid OR u.Id = @Userid) AND  u.Active=1
                              END
                           
       
       END TRY

       BEGIN CATCH
              EXECUTE [dbo].[LogError]
   END CATCH
END

