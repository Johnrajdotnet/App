﻿
	-- =============================================
	-- Author:           <Mira Kumari>
	-- Create date:		 <13/03/2019>
	-- Description:      <Get EDC Document Upload Details>
	-- exec [Mail].[GetEDCDocumentDownloadDetails]
	-- =============================================
	CREATE PROCEDURE [Mail].[GetEDCDocumentDownloadDetails]
	AS
	BEGIN
	      SET NOCOUNT ON;
	      BEGIN TRY
		            declare @TVNumber  nvarchar(max)
					SELECT @TVNumber= COALESCE(@TVNumber+ ',','')+CAST(TVNumber as nvarchar(max))  FROM 	[Edc].[OT_TV_Wide_Body_Documents_Details] 
					WHERE Active=1 AND CONVERT(NVARCHAR, ModifiedDate,112)= CONVERT(NVARCHAR, GETDATE(),112)
				     
					SELECT @TVNumber as TVNumber
				
		   END TRY
		   BEGIN CATCH
		   EXECUTE [dbo].[LogError]
		   END CATCH

    END

