﻿
-- =============================================
-- Author:           <Anupa>
-- Create date: <20/03/2017>
-- Description:      <Gets List oF Email Receipients>
-- =============================================
--EXEC [dbo].[GetUserDetailedDatatEST]'6edd2630-c821-4614-b026-04bdde06f8c3',null,null,null,null,null,null,null,null
CREATE PROCEDURE [Mail].[GetEmailRecepientAddress]--null,null,'ORACLEID','111'--1,null,'ROLE'--null,null,null,null,null,1,null,null,null
       @roleid nvarchar(50),
       @userId int, --user table id or oracle
       @emailFlag nvarchar(20),
       @oracleId int,
	   @businessId nvarchar(50)
AS
BEGIN
       SET NOCOUNT ON;


       BEGIN TRY
       

              IF(UPPER(@emailFlag)='ROLE' and @roleid is not null)
              BEGIN

                     SELECT users.EmailAddress AS EmailId FROM [Admin].Syn_ST_User_Role_Module rolemodule
                     INNER JOIN [Admin].Syn_ST_Users users ON rolemodule.UserId = users.Id WHERE RoleId IN
                     (SELECT Item FROM dbo.StringToTableValueWithIdentity(@roleid, ',')) and users.Active=1

              END    
              ELSE IF(UPPER(@emailFlag)='USER' and @userId is not null)
              BEGIN
                     --email by user table id
                     SELECT 
                              EmailAddress as EmailId                      
                     FROM [Admin].[Syn_ST_Users]  where Id=@userId and Active=1
              END
              ELSE IF(UPPER(@emailFlag)='ORACLEID' and @oracleId is not null)
              BEGIN
                     --email by oracleid
                     SELECT 
                              EmailAddress as EmailId                      
                     FROM [Admin].[Syn_ST_Users] u where UserId=@oracleId and Active=1
              END
              ELSE IF(UPPER(@emailFlag)='ALL')
              BEGIN
                     
                     SELECT 
                              EmailAddress as EmailId                      
                     FROM [Admin].[Syn_ST_Users] WHERE Active = 'True'
              END    
              ELSE IF(UPPER(@emailFlag)='SYSTEM')
              BEGIN
                     
                     SELECT 
                              EmailAddress as EmailId                      
                     FROM [Admin].[Syn_ST_Users] where upper(FirstName)='SYSTEM' and Active=1
              END    
			   ELSE IF(UPPER(@emailFlag)='BUSINESS')
              BEGIN

					SELECT 
							    u.EmailAddress AS EmailId 
					FROM	    [Admin].Syn_ST_Users u
					INNER JOIN  [Admin].Syn_ST_User_Role_Module rm  ON rm.UserId = u.Id  
					CROSS APPLY dbo.StringToTableValueWithIdentity(rm.BusinessModuleId, ',') b
					CROSS APPLY dbo.StringToTableValueWithIdentity(@businessId, ',') bi
					WHERE 
					b.Item=bi.Item and u.Active=1
					GROUP BY u.EmailAddress			 																								                     							 
              END  
			   ELSE IF(UPPER(@emailFlag)='DRAWINGREQUEST')
              BEGIN
				  SELECT 'mira.kumari@quest-global.com' as EmailAddress
			  END 
			   ELSE IF(UPPER(@emailFlag)='SARANDREDTOP')
              BEGIN
				  SELECT 'ServiceTV_Team@quest-global.com,RepairTV_Team@quest-global.com,BelgaumRepairTV@quest-global.com,BelgaumServiceTV@quest-global.com'as emailId
			  END
			    ELSE IF(UPPER(@emailFlag)='PostTVBookedIn')
              BEGIN
				  SELECT 'raghavendra.prabhu@quest-global.com' as EmailAddress
			  END  
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END

