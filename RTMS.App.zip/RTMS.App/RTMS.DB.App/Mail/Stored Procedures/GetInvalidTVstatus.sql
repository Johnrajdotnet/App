﻿
-- =============================================
-- Author:           Arathy
-- Create date: 5/8/2018
-- Description:      Insert TV information from excel to Database 
-- =============================================
CREATE PROCEDURE [Mail].[GetInvalidTVstatus] 

AS
BEGIN  
 SET NOCOUNT ON;      
BEGIN TRY

						SELECT    
						ow.OracleId                as OracleId, 
						tv.TVNumber                as TVNumber,
						u.FirstName+','+u.LastName as EngineerName
						,u.EmailAddress            as EmailAddress ,
						tv.RCIComments                                    
						FROM       [Edc].[ST_TV_Owner_Details] ow  
						LEFT JOIN  [Admin].[Syn_ST_Users] u ON u.UserId=ow.OracleId
						INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON ow.Id=ac.Engineer1
						INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] tv ON tv.Id=ac.TVDataCenterId
						WHERE ac.Status=100
						AND u.UserId IS NOT NULL 
						AND u.Active=1 
						AND ow.Active=1
						AND tv.DateCompleted is null
						ORDER BY EngineerName,TVNumber


END TRY
BEGIN CATCH
       
   EXECUTE [dbo].[LogError]
END CATCH
END
