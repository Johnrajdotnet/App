﻿
-- =============================================
-- Author:           <Mira Kumari>
-- Create date:      <04/12/2018>
-- Description:      <Retrives daily TV Status for RPN>
-- exec [Mail].[GetWBodyWipRPNDailyTVStatus] 
CREATE PROCEDURE [Mail].[GetWBodyWipRPNDailyTVStatus]
AS
 
                       
BEGIN TRY
 SET NOCOUNT ON;
                   
                     DECLARE @teamLeader NVARCHAR(MAX) ='ROPER,STEVE'            
                   
						SELECT    
								ow.OracleId as OracleId,t.TVNumber as TVNumber ,ow.OwnerName as TVOwner,
							t.TVType as [Type],
							Case
								WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN 'CRT' ELSE 'NCRT' 
							END AS [Category],
							t.DateIn,t.RRPromisedDate,t.CustomerRequiredDate,wi.StatusDescription AS [TVStatus],wi.Location,
							CASE
								WHEN (StatusTitle='H' OR StatusTitle='N')
								THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle)
                                                         
								WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
								THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle)              
 
								WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
								THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle)
 
								WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
								THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle)
                                                         
								WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate                                                     
								THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle)
							 END AS MileStoneStatus,
							 u.EmailAddress as EmailAddress,t.EngineMark ,t.Team as Team, t.TeamLeader,[dbo].[GetDateDifferenceInDays] (t.DateIn,'DAYS') as age,
							   StatusTitle
					FROM        [Edc].[ST_TV_Owner_Details] ow 
                    inner JOIN  [Admin].[Syn_ST_Users] u ON u.UserId=ow.OracleId
                    INNER JOIN  [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON ow.Id=ac.Engineer1
                    INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] t ON t.Id=ac.TVDataCenterId
			        INNER JOIN  [Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
					WHERE       t.DateCompleted  is null
                    AND         UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|'))     
                    AND          (Team='RE-RPN-REACT' OR Team='SE-RPN-REACT')

                                  
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
