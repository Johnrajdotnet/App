﻿
-- =============================================
-- Author:           <Mira Kumari>
-- Create date:      <05/06/2018>
-- Description:      <Retrives Wip Details spc]
-- exec [Mail].[GetWipWBodyManagerSPCEmailidByProgram]  'TRENT900'
CREATE PROCEDURE [Mail].[GetWipWBodyManagerSPCEmailidByProgram]
@EngineMark NVARCHAR(10)
AS
BEGIN TRY
SET NOCOUNT ON;
DECLARE @ProgramID nvarchar(max)
DECLARE @parentMenuId nvarchar(10)='2,3,4'
 
       SELECT @ProgramID=COALESCE(@ProgramID+ ',','')+CAST(Id as nvarchar(max)) FROM  [Admin].[Syn_ST_Program_Details] where ProgramName =@EngineMark
       and MenuId IN (SELECT Item FROM [dbo].[StringToTableValue] (@parentMenuId,','))
      
       SELECT distinct EmailId FROM [dbo].[GetAllSPCDetailsByProgram](@ProgramID,NULL)
       UNION
       SELECT distinct EmailId FROM [dbo].[GetAllManagerBottomUp](@ProgramID,NULL)
      
 
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH