﻿


-- =============================================
-- Author:           <Arathy>
-- Create date: <20/03/2017>
-- Description:      <Gets List oF owner email address>
-- =============================================
-- exec [Mail].[NotifyHeadsUpCompleted] 192527

CREATE PROCEDURE [Mail].[NotifyHeadsUpCompleted]
@tvnumber bigint
AS
BEGIN
DECLARE @tempTVDetails TABLE (Id INT IDENTITY (1,1), EmailAddress NVARCHAR(max), ProgramId NVARCHAR(max))
DECLARE @tempEmailTable TABLE (Id INT IDENTITY (1,1), EmailAddress NVARCHAR(max))
DECLARE @SPCEmailID nvarchar(max)
declare @ownerEmailID nvarchar(max)
       SET NOCOUNT ON;


       BEGIN TRY
              BEGIN
			  
							 INSERT INTO @tempTVDetails(EmailAddress,ProgramId)
							 SELECT 	u.EmailAddress as EmailAddress,rm.ProgramId as ProgramId 
						   	 FROM    [Edc].[ST_TV_Owner_Details] ow  
							 INNER JOIN [Admin].[Syn_ST_Users] u ON u.UserId=ow.OracleId
							 INNER JOIN [Admin].Syn_ST_User_Role_Module rm ON rm.UserId=u.Id
							 INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON ow.Id=ac.Engineer1
							 INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] tv ON tv.Id=ac.TVDataCenterId
							 WHERE tv.TVNumber= @tvnumber

							 

							 	
							 INSERT INTO @tempEmailTable(EmailAddress)
							 SELECT EmailId  FROM [dbo].[GetAllManagerBottomUp] ((SELECT ProgramId from @tempTVDetails),'1')

							 --SELECT EmailAddress  FROM @tempTVDetails
							 --SELECT EmailAddress  FROM @tempEmailTable

							SELECT @SPCEmailID=COALESCE(@SPCEmailID+ ',','')+CAST(EmailAddress as nvarchar(max)) FROM @tempEmailTable
							SELECT @ownerEmailID=COALESCE(@ownerEmailID+ ',','')+CAST(EmailAddress as nvarchar(max)) FROM @tempTVDetails
							
					 SELECT @SPCEmailID as SpcMailID ,@ownerEmailID as OwnerMailID



							 
              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END