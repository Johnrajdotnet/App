﻿
-- =============================================
-- Author:           <Arathy>
-- Create date: <20/03/2017>
-- Description:      <Gets List oF Manager email address>
-- =============================================
--EXEC [Mail].[GetAllManagerLevelByProgram]'12,9,7,8,7,8,9,10,11,12,13,14,12,13'
--EXEC [Mail].[GetAllManagerLevelByProgram]'12,9,7,8,10,11,12,13,14'

CREATE PROCEDURE [Mail].[GetAllManagerLevelByProgram]
@programList nvarchar(max),
@level int
AS
BEGIN
       SET NOCOUNT ON;

       BEGIN TRY
              BEGIN

			  SELECT EmailId FROM [dbo].[GetAllManagerBottomUp](@programList,@level)
					
              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END


--select * from GetAllManagerBottomUp('12,9,7,8,10,11,12,13,14')
