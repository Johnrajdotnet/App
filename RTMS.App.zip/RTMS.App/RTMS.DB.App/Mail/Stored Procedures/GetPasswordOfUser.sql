﻿
-- =============================================
-- Author:		<Anupa>
-- Create date: <05-04-2017>
-- Description:	<Sp to fetch credentials of a particular user>
-- =============================================
CREATE PROCEDURE [Mail].[GetPasswordOfUser] --'111'--'cdd388bf-dad0-4e0a-82cd-c45c2f42920a'
	@oracleId bigint
AS
BEGIN
	
	SET NOCOUNT ON;

	BEGIN TRY

			SELECT 
				u.Password as [Password]
			FROM 	
				[Admin].[Syn_ST_Users] u  
			WHERE u.Active=1 and u.UserId = @oracleId
	
	
	END TRY
	BEGIN CATCH
	EXECUTE [dbo].[LogError]
	END CATCH
	
END
