﻿


-- =============================================
-- Author:           <Arathy>
-- Create date: <20/03/2017>
-- Description:      <Gets forumpass details>
-- =============================================
-- exec [Mail].[GetForumPassDetails] 195546

CREATE PROCEDURE [Mail].[GetForumPassDetails]
@tvnumber bigint
AS
BEGIN

       SET NOCOUNT ON;


       BEGIN TRY
              BEGIN	
							 
							 SELECT		ex.ForumPassURL AS ForumPassURL
							 FROM		[Edc].[OT_TV_Wide_Body_Data_Center] dc
							 INNER JOIN [Edc].OT_TV_Wide_Body_Activity_Center ac on ac.TVDataCenterId=dc.Id
							 INNER JOIN [WFlow].[OT_TV_WBody_WFlow_Engine_Extend_Details] ex ON ex.WBodyActivityId=ac.Id
							 WHERE		TVNumber=@tvnumber

              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END


							 