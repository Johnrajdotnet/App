﻿
-- =============================================
-- Author:           <Arathy>
-- Create date: <20/03/2017>
-- Description:      <Gets List oF owner email address>
-- =============================================
--EXEC [Mail].[GetWipOwnerDetailsForRBody]
CREATE PROCEDURE [Mail].[GetWipOwnerDetailsForRBody]
AS
BEGIN
       SET NOCOUNT ON;


       BEGIN TRY
              BEGIN
					   SELECT ow.OracleId,u.UserId, 
					   tv.TVNumber as TVNumber,  
					   u.FirstName+','+u.LastName as EngineerName,
					   u.EmailAddress as EmailAddress,
					   rm.ProgramId as ProgramId,
						CASE WHEN (DATEDIFF(HH,ISNULL(ac.ModifiedDate,ac.CreatedDate), getdate())>9 
						AND  DATEDIFF(HH,ISNULL(ac.ModifiedDate,ac.CreatedDate), getdate())<=24) THEN 1 ELSE DATEDIFF(DD,ISNULL(ac.ModifiedDate,ac.CreatedDate), 
						getdate()) END as DateDiff	
						FROM [Edc].[ST_TV_Owner_Details] ow  
						LEFT JOIN [Admin].[Syn_ST_Users] u ON u.UserId=ow.OracleId
						LEFT JOIN [Admin].Syn_ST_User_Role_Module rm ON rm.UserId=u.Id
						INNER JOIN [Edc].[OT_TV_Regional_Body_Activity_Center] ac ON ow.Id=ac.Engineer1
						INNER JOIN [Edc].[OT_TV_Regional_Body_Data_Center] tv ON tv.Id=ac.TVDataCenterId
						WHERE tv.DateCompleted IS NULL AND DATEDIFF(HH,ISNULL(ac.ModifiedDate,ac.CreatedDate), getdate())>9
						AND u.UserId IS NOT NULL AND u.Active=1 AND ow.Active=1

					--SELECT EmailAddress,FirstName 
					--FROM [Admin].[ST_Users] 
					--WHERE UserId in (1003657,1002477)

							 
              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END

