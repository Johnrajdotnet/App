﻿	-- =============================================
	-- Author:           <Mira>
	-- Create date:		 <26/02/2019>
	-- Description:      <Get All Part Number of yesterday >
	-- exec [Mail].[GetHitCountPartNumber]
	-- =============================================
	CREATE PROCEDURE [Mail].[GetHitCountPartNumber]
	--@TableId int,
	--@ColumnName nvarchar(250),
	--@ColumnValue  nvarchar(250)
	AS
	BEGIN
		  SELECT ColumnValue AS PartNumber
		  FROM [dbo].[OT_Hit_Count_Column_Name_Details] 
		  WHERE TableId=3 AND ColumnName='PartNumber'
		        AND  CONVERT(nvarchar,CreatedDate,112)= CONVERT(nvarchar,GETDATE()-1,112) 
	end