﻿CREATE TABLE [Report].[ST_Edc_Wip_Status_Details]
(
    [Id]					INT				 IDENTITY (1, 1) NOT NULL,
	[StatusCategory]		NVARCHAR(100)	 NOT NULL,
	[StatusTitle]			CHAR(5)			 NOT NULL,
	[StatusCode]			CHAR(5)			 NOT NULL,
	[StatusSeqCode]         INT				 NULL,
	[Status]				NVARCHAR(500)	 NOT NULL,	
	[StatusDescription]	    NVARCHAR(500)	 NULL,
	[Location]				NVARCHAR(100)	 NOT NULL,
    [Active]				BIT              CONSTRAINT [DF_Edc_Wip_Status_Active] DEFAULT ((1)) NOT NULL,
    [CreatedDate]			DATETIME         CONSTRAINT [DF_Edc_Wip_Status_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedDate]			DATETIME         NULL,
    CONSTRAINT [PK_Edc_Wip_Status_Details] PRIMARY KEY CLUSTERED ([Id] ASC)
)
