﻿
-- =============================================
-- Author:           <neethu>
-- Create date:      <06/13/2018>
-- Description:      <Retrives Wip status Details from [Report].[ST_Edc_Wip_Status_Details]
-- exec [Report].[GetWipDisplayDetails] 
CREATE PROCEDURE [Report].[GetWipStatusDetails]
AS

BEGIN
			SET NOCOUNT ON;


						SELECT	   Id             AS Id,
								   Status         AS [Status],
								   StatusCategory AS [StatusCategory],
								   StatusTitle    AS [StatusTitle],
								   [Location]     AS [Location]

						FROM	   [Report].[ST_Edc_Wip_Status_Details]  

END