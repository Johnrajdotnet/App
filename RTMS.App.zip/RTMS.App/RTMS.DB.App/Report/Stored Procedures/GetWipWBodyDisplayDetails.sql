
-- =============================================
-- Author:           <Arathy>
-- Create date:      <05/06/2018>
-- Description:      <Retrives Wip Details from [[Edc].[OT_TV_Data_Center_Activity_Details]
-- exec [Report].[GetWipWBodyDisplayDetails] 't9','SERVICE','NONRPN'
CREATE PROCEDURE [Report].[GetWipWBodyDisplayDetails]
@seriesKey NVARCHAR(20)=null,
@tvType NVARCHAR(20)=null,
@flag NVARCHAR(20)
AS
DECLARE @tvnumber BIGINT

DECLARE @dateIn  DATETIME;
DECLARE @requiredDate  DATETIME;
DECLARE @totalAge  NVARCHAR(250);
DECLARE @teamLeader NVARCHAR(200);
BEGIN TRY
 SET NOCOUNT ON;

 IF(@flag='NONRPN')--non rpn
 BEGIN
	SET @teamLeader='LEE,VINCENT|KATUMBA,FRANK|LOWER,ANDREW|GREEN,TREVOR|THORNE, MARK|STOLWORTHY,MARK|WHYTE, JAMES'
				SELECT     t.TVNumber as TVNumber ,								 
                                  ISNULL(wi.StatusCategory,'YTS') AS [StatusCategory],
								  wi.StatusDescription as [StatusDescription],
								  wi.Location as Location,
                                  t.DateIn  as DateIn,
                                  ISNULL(wi.StatusTitle,'N') as StatusTitle,
								  --CRT CustomerRequiredDate
								  IIF(CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0 ,t.CustomerRequiredDate,t.RRPromisedDate ) as CustRequiredDate, 							
                                  t.InfoRequestedDetails as InfoRequestedDetails,
                                  [dbo].[GetDateDifferenceInDays](t.DateIn,'DAYS') AS TotalAge,
                                  t.HeadsupDate as HeadsupDate,  
								  ISNULL(wi.StatusCategory,'YTS')  AS [Status] ,                     
       				CASE 
						WHEN (StatusTitle='H' OR StatusTitle='N')
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 		

						WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 

						WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate							  
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						END
						as MileStoneStatus,
					CASE								  
						WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN '1' ELSE '2' 
					END 
					AS Category, 				
                    [dbo].[GetOwnerNameById] (ac.Engineer1)  as OwnerName,
                    [dbo].[GetOwnerNameById] (ac.CAEngineer) as CAEngineerName

        FROM          [Edc].[OT_TV_Wide_Body_Data_Center] t
        LEFT JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
        LEFT JOIN	[Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
        WHERE         t.DateCompleted  is  null
				AND t.TVType = isnull(@tvType, t.TVType)
				AND	UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|'))      
                AND t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 


 END
 ELSE IF(@flag='RPN')
 BEGIN
	SET @teamLeader='ROPER,STEVE'
		SELECT     t.TVNumber as TVNumber ,								 
                                  ISNULL(wi.StatusCategory,'YTS')   AS [StatusCategory],
								  wi.StatusDescription as [StatusDescription],
								  wi.Location as Location,
                                  t.DateIn  as DateIn,
                                  ISNULL(wi.StatusTitle,'N') as StatusTitle,
								  --CRT CustomerRequiredDate
								  IIF(CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0 ,t.CustomerRequiredDate,t.RRPromisedDate ) as CustRequiredDate, 

                                  t.InfoRequestedDetails as InfoRequestedDetails,
                                  [dbo].[GetDateDifferenceInDays](t.DateIn,'DAYS') AS TotalAge,
                                  t.HeadsupDate as HeadsupDate,  
								  ISNULL(wi.StatusCategory,'YTS')  AS [Status] ,                            
       							  CASE 
										WHEN (StatusTitle='H' OR StatusTitle='N')
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
										WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 		

										WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 

										WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
										WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate								  
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
					                 END
						             AS MileStoneStatus,
									 CASE								  
										WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN '1' ELSE '2' 
									 END 
					                 AS Category, 				
                                  [dbo].[GetOwnerNameById] (ac.Engineer1)  as OwnerName,
                                  [dbo].[GetOwnerNameById] (ac.CAEngineer) as CAEngineerName
              FROM          [Edc].[OT_TV_Wide_Body_Data_Center] t
              LEFT JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
              LEFT JOIN	[Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
              WHERE         t.DateCompleted  is  null 
						AND t.TVType = ISNULL(@tvType, t.TVType)
						 AND		   UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|'))      
                                   AND t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 
								   AND  (Team='RE-RPN-REACT' OR Team='SE-RPN-REACT')
 END
			                                                        
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH