
-- =============================================
-- Author:           <Arathy>
-- Create date:      <05/06/2018>
-- Description:      <Retrives Wip Details from [[Edc].[OT_TV_Data_Center_Activity_Details]
-- exec [Report].[GetWipRBodyDisplayDetails] t7,service,RPN
create PROCEDURE [Report].[GetWipRBodyDisplayDetails]
@seriesKey NVARCHAR(20)=null,
@tvType NVARCHAR(20)=null,
@flag NVARCHAR(20)
AS
DECLARE @tvnumber BIGINT
DECLARE @category NVARCHAR(250)
DECLARE @dateIn  DATETIME;
DECLARE @requiredDate  DATETIME;
DECLARE @totalAge  NVARCHAR(250);
DECLARE @teamLeader NVARCHAR(200);
BEGIN TRY
 SET NOCOUNT ON;

 IF(@flag='NONRPN')--non rpn
 BEGIN
	SET @teamLeader='LEE,VINCENT|KATUMBA,FRANK|LOWER,ANDREW|GREEN,TREVOR|THORNE, MARK|STOLWORTHY,MARK|WHYTE, JAMES'
	
		SELECT     t.TVNumber as TVNumber ,								 
                                  wi.StatusCategory      AS [StatusCategory],
								  wi.StatusDescription   AS [StatusDescription],
								  wi.Location            AS Location,
                                  t.DateIn               AS DateIn,
                                  wi.StatusTitle         AS StatusTitle,
                                  t.CustomerRequiredDate AS CustRequiredDate,
                                  t.InfoRequestedDetails AS InfoRequestedDetails,
                                  [dbo].[GetDateDifferenceInDays](t.DateIn,'DAYS') AS TotalAge,
                                  t.HeadsupDate          AS HeadsupDate,  
								  wi.StatusCategory      AS [Status] ,                          
       							  CASE 
								  WHEN StatusTitle='H' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,wi.StatusTitle) 
								  WHEN StatusTitle='D' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.InitialPSEOrPREOrCVEIn,t.InfoRequestedDetails,wi.StatusTitle) 
								  WHEN StatusTitle='A' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,wi.StatusTitle) 
								  END
								  AS MileStoneStatus,
								  CASE								  
								  WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN '1' ELSE '2' 
								  END AS Category, 				
                                  [dbo].[GetOwnerNameById] (ac.Engineer1)  AS OwnerName,
                                  [dbo].[GetOwnerNameById] (ac.CAEngineer) AS CAEngineerName
              FROM          [Edc].[OT_TV_Regional_Body_Data_Center] t
              INNER JOIN    [Edc].[OT_TV_Regional_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
              INNER JOIN	[Report].[ST_Edc_Wip_Status_Details] wi        ON wi.Id=ac.[Status]
              WHERE         t.DateCompleted  is  null 
			  AND			t.TVType = isnull(@tvType, t.TVType)
			  AND		    UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (SELECT UPPER(RTRIM(LTRIM(Item))) FROM [dbo].[StringToTableValue] (@teamLeader,'|'))      
              AND			t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 
END

ELSE IF(@flag='RPN')
 BEGIN
	SET @teamLeader='ROPER,STEVE'
			
			SELECT                t.TVNumber              AS TVNumber ,								 
                                  wi.StatusCategory       AS [StatusCategory],
								  wi.StatusDescription    AS [StatusDescription],
								  wi.Location             AS Location,
                                  t.DateIn                AS DateIn,
                                  wi.StatusTitle          AS StatusTitle,
                                  t.CustomerRequiredDate  AS CustRequiredDate,
                                  t.InfoRequestedDetails  AS InfoRequestedDetails,
                                  [dbo].[GetDateDifferenceInDays](t.DateIn,'DAYS') AS TotalAge,
                                  t.HeadsupDate           AS HeadsupDate,  
								  wi.StatusCategory       AS [Status] ,                          
       							  CASE 
								  WHEN StatusTitle='H' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,wi.StatusTitle) 
								  WHEN StatusTitle='D' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.InitialPSEOrPREOrCVEIn,t.InfoRequestedDetails,wi.StatusTitle) 
								  WHEN StatusTitle='A' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,wi.StatusTitle) 
								  END
								  AS MileStoneStatus,
								  CASE								  
								  WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN '1' ELSE '2' 
								  END AS Category, 				
                                  [dbo].[GetOwnerNameById] (ac.Engineer1)  AS OwnerName,
                                  [dbo].[GetOwnerNameById] (ac.CAEngineer) AS CAEngineerName
              FROM          [Edc].[OT_TV_Regional_Body_Data_Center] t
              INNER JOIN    [Edc].[OT_TV_Regional_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
              INNER JOIN	[Report].[ST_Edc_Wip_Status_Details] wi        ON wi.Id=ac.[Status]
              WHERE         t.DateCompleted  is  null 
			  AND			t.TVType = isnull(@tvType, t.TVType)
			  AND		    UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) FROM [dbo].[StringToTableValue] (@teamLeader,'|'))      
              AND			t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 
		      AND			(Team='RE-RPN-REACT' OR Team='SE-RPN-REACT')
	
						
	END					
				                                                        
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

