

-- =============================================
-- Author:           <Neethu>
-- Create date:            <11/06/2018>
-- Description:      <Retrives Wip Details from [[Edc].[OT_TV_Regional_Body_Activity_Center]
-- exec [Report].[GetWipRBodyActivityDetails] 177109,1
-- ==============================================================
CREATE PROCEDURE [Report].[GetWipRBodyActivityDetails]
@tvNumber bigint,
@issueNumber int

AS


declare @tvDataCenterId bigint ,@count int=0


BEGIN TRY
 SET NOCOUNT ON;

 SET @tvDataCenterId=(SELECT Id FROM [Edc].[OT_TV_Regional_Body_Data_Center]   WHERE TVNumber=@tvNumber and IssueNumber=@issueNumber)
 SET @count=(SELECT count(Id) FROM [Edc].[OT_TV_Regional_Body_Activity_Center] WHERE TVDataCenterId=@tvDataCenterId)
				
		IF(	@count!=0)
		BEGIN	
			


				SELECT	    t.TVNumber             AS TVNumber ,
							t.IssueNumber          AS IssueNUmber,
							t.InfoRequestedDetails AS CategoryValue,
							ac.Engineer1           AS Engineer1,
							ac.CAEngineer          AS CAEngineer,
							[Status]               AS Status,
							CONVERT(varchar(10),t.DateIn,101)                AS DateIn,
							CONVERT(varchar(10),t.CustomerRequiredDate,101)  AS CustRequiredDate,
							CONVERT(varchar(10),t.RRPromisedDate,101)        AS RequestedDate,
							ac.Complexity          AS Complexity,
							ac.NumberofDamages     AS NumberofDamages,
							t.Id                   AS TVDataCenterId,
							ac.Id                  AS TVDataCenterActivityId,	
							t.DateCompleted        AS DateCompleted,
							t.EngineMark           AS EngineMark												

				FROM		[Edc].[OT_TV_Regional_Body_Data_Center] t
                INNER JOIN	[Edc].[OT_TV_Regional_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 				
				WHERE t.TVNumber=@tvNumber 
				AND   t.IssueNumber=@issueNumber
				     
            END
			ELSE
			BEGIN
				SELECT	        t.TVNumber             AS TVNumber ,
								t.IssueNumber          AS IssueNUmber,
								t.InfoRequestedDetails AS CategoryValue,
								CONVERT(varchar(10),t.DateIn,101)               AS DateIn,
								CONVERT(varchar(10),t.CustomerRequiredDate,101) AS CustRequiredDate	,
								CONVERT(varchar(10),t.DateInfoRequested,101)    AS RequestedDate	,
								t.Id                   AS TVDataCenterId,
								0                      AS TVDataCenterActivityId,
								t.DateCompleted        AS DateCompleted,
								t.EngineMark           AS EngineMark		

					FROM		[Edc].[OT_TV_Regional_Body_Data_Center] t								
					WHERE t.TVNumber=@tvNumber 
					AND   t.IssueNumber=@issueNumber
			END               
                         

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH



