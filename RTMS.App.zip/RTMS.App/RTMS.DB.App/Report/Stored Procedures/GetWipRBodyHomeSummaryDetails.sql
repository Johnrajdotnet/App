
-- =============================================
-- Author:           <John.Raj>
-- Create date:      <11/06/2018>
-- Description:      <Retrives Wip home Summary Details
-- exec [Report].[GetWipRBodyHomeSummaryDetails] 't7','Trent700'
CREATE PROCEDURE [Report].[GetWipRBodyHomeSummaryDetails] 
 @seriesKey NVARCHAR(10),
 @seriesName NVARCHAR(20)
AS
DECLARE @serviceYTS         INT
DECLARE @serviceHeadUp      INT
DECLARE @serviceDraft       INT
DECLARE @serviceApproval    INT
DECLARE @repairYTS          INT
DECLARE @repairHeadUp       INT
DECLARE @repairDraft        INT
DECLARE @repairApproval     INT
DECLARE @serviceRpnYTS      INT
DECLARE @serviceRpnHeadUp   INT
DECLARE @serviceRpnDraft    INT
DECLARE @serviceRpnApproval INT
DECLARE @repairRpnYTS       INT
DECLARE @repairRpnHeadUp    INT
DECLARE @repairRpnDraft     INT
DECLARE @repairRpnApproval  INT
DECLARE @totalOfSeries      INT                        
BEGIN TRY 
 SET NOCOUNT ON;

                     DECLARE @temptable TABLE
                     (
                           Id              INT IDENTITY(1,1),
                           TVNumber        INT,
                           TVType          NVARCHAR(50),
                           EngineMark      NVARCHAR(50),
                           StatusCategory  NVARCHAR(50),
                           TVCategory      NVARCHAR(50),
                           StatusTitle     CHAR(5),
                           MileStoneStatus NVARCHAR(50),
						   Team            NVARCHAR(50),
                           TeamLeader      NVARCHAR(50)
                     )                                               
                     DECLARE @resulttable TABLE
                     (
                           Id              INT IDENTITY(1,1),
                           SeriesName      INT,
                           ServiceYTS      INT,
                           ServiceHeadUp   INT,
                           ServiceDraft    INT,
                           ServiceApproval INT,                     
                           RepairHeadUp    INT,
                           RepairDraft     INT,
                           RepairApproval  INT,
                           RPNHeadUp       INT,
                           RPNDraft        INT,
                           RPNApproval     INT
                     ) 
                     
					 DECLARE @teamLeader NVARCHAR(MAX)='LEE,VINCENT|KATUMBA,FRANK|LOWER,ANDREW|GREEN,TREVOR|THORNE, MARK|STOLWORTHY,MARK|WHYTE, JAMES'
					 INSERT @temptable (TVNumber,TVType,EngineMark,Team,TeamLeader,StatusCategory,TVCategory,StatusTitle,MileStoneStatus) 
					 SELECT     
                                                       t.TVNumber        AS TVNumber ,
                                                       t.TVType          AS TVType,
                                                       t.EngineMark      AS EngineMark,
													   t.Team            AS Team,
													   t.TeamLeader      AS TeamLeader,
                                                       wi.StatusCategory AS [StatusCategory],
                                                        CASE 
                                                        WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN '1' ELSE '2' END AS [TVCategory],
														ISNULL(wi.StatusTitle,'N') AS StatusTitle,
														CASE 
														WHEN StatusTitle='H' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,wi.StatusTitle) 
														WHEN StatusTitle='D' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.InitialPSEOrPREOrCVEIn,t.InfoRequestedDetails,wi.StatusTitle) 
														WHEN StatusTitle='A' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,wi.StatusTitle) 
														END
														as MileStoneStatus
                     FROM          [Edc].[OT_TV_Regional_Body_Data_Center] t
                     INNER JOIN    [Edc].[OT_TV_Regional_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
                     INNER JOIN    [Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
                     WHERE         t.DateCompleted  is null
									AND	UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) FROM [dbo].[StringToTableValue] (@teamLeader,'|'))   
                                    AND t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 
                       
                     --SELECT * FROM @temptable
                     --Service
                     SET    @serviceYTS = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='N' AND UPPER(TVType)='SERVICE')
                     SET    @serviceHeadUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND UPPER(TVType)='SERVICE')
                     SET    @serviceDraft = ( SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND UPPER(TVType)='SERVICE')
                     SET    @serviceApproval = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='A' AND UPPER(TVType)='SERVICE')


                     ----Repair--todo
                     SET  @repairYTS = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='N' AND UPPER(TVType)='REPAIR')
                     SET  @repairHeadUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND UPPER(TVType)='REPAIR')
                     SET  @repairDraft = ( SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND UPPER(TVType)='REPAIR')
                     SET  @repairApproval = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='A' AND UPPER(TVType)='REPAIR')


					 DELETE @temptable
					SET @teamLeader ='ROPER,STEVE'

					INSERT @temptable (TVNumber,TVType,EngineMark,Team,TeamLeader,StatusCategory,TVCategory,StatusTitle,MileStoneStatus) 
					SELECT     
                                                       t.TVNumber        AS TVNumber ,
                                                       t.TVType          AS TVType,
                                                       t.EngineMark      AS EngineMark,
													   t.Team            AS Team,
													   t.TeamLeader      AS TeamLeader,
                                                       wi.StatusCategory AS [StatusCategory],
                                                       CASE 
                                                       WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN '1' ELSE '2' END AS [TVCategory],
														ISNULL(wi.StatusTitle,'N') AS StatusTitle,
														CASE 
														WHEN StatusTitle='H' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,wi.StatusTitle) 
														WHEN StatusTitle='D' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.InitialPSEOrPREOrCVEIn,t.InfoRequestedDetails,wi.StatusTitle) 
														WHEN StatusTitle='A' THEN [dbo].[CheckTVMetOrMissedForRBody](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,wi.StatusTitle) 
														END
														as MileStoneStatus
                     FROM          [Edc].[OT_TV_Regional_Body_Data_Center] t
                     INNER JOIN    [Edc].[OT_TV_Regional_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
                     INNER JOIN    [Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
                     WHERE         t.DateCompleted  is null
									AND	UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|'))   
                                    AND t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 
									 AND  (Team='RE-RPN-REACT' OR Team='SE-RPN-REACT')


                     ----RPN--todo
					 SET  @serviceRpnYTS = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='N' AND UPPER(TVType)='SERVICE')
                     SET  @serviceRpnHeadUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND UPPER(TVType)='SERVICE')
                     SET  @serviceRpnDraft = ( SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND UPPER(TVType)='SERVICE')
                     SET  @serviceRpnApproval = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='A' AND UPPER(TVType)='SERVICE')

					 SET  @repairRpnYTS = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='N' AND UPPER(TVType)='REPAIR')
                     SET  @repairRpnHeadUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND UPPER(TVType)='REPAIR')
                     SET  @repairRpnDraft = ( SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND UPPER(TVType)='REPAIR')
                     SET  @repairRpnApproval = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='A' AND UPPER(TVType)='REPAIR')
             
                     SET @totalOfSeries = @serviceYTS + @serviceHeadUp + @serviceDraft + @serviceApproval+
										  @repairYTS + @repairHeadUp + @repairDraft + @repairApproval+
										  @serviceRpnYTS + @serviceRpnHeadUp + @serviceRpnDraft + @serviceRpnApproval+
										  @repairRpnYTS + @repairRpnHeadUp + @repairRpnDraft + @repairRpnApproval


                     SELECT  @seriesName AS SeriesName,@seriesKey AS SeriesKey,@serviceYTS AS ServiceYTS,
                             @serviceHeadUp AS ServiceHeadUp,@serviceDraft AS ServiceDraft,
							 @serviceApproval AS ServiceApproval ,@repairYTS AS RepairYTS,
							 @repairHeadUp AS RepairHeadup,@repairDraft AS RepairDraft,
							 @repairApproval AS RepairApproval,@serviceRpnYTS AS RpnYTS,
							 @serviceRpnHeadUp AS RpnHeadup,@serviceRpnDraft AS RpnDraft,
							 @serviceRpnApproval AS RpnApproval,@repairRpnYTS AS RpnRepairYTS,
							 @repairRpnHeadUp AS RpnRepairHeadUp,@repairRpnDraft AS RpnRepairDraft,
							 @repairRpnApproval AS RpnRepairApproval,@totalOfSeries as TotalOfSeries 
						
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH





