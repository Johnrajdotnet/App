
-- =============================================
-- Author:           <John.Raj>
-- Create date:            <11/06/2018>
-- Description:      <Retrives Wip Summary
-- exec [Report].[GetWipWBodySummaryDisplayDetails] 't9','SERVICE','NONRPN'
CREATE PROCEDURE [Report].[GetWipWBodySummaryDisplayDetails] 
@seriesKey NVARCHAR(20)=null,
@tvType NVARCHAR(20)=null,
@flag NVARCHAR(20)
AS

DECLARE @ytsHeadsUp INT
DECLARE @inWorkHeadsUp INT
DECLARE @queryHeadsUp INT
DECLARE @rrReviewHeadsUp INT
DECLARE @agerHeadsUp INT
DECLARE @ytdDraft INT
DECLARE @inWorkDraft INT
DECLARE @caReviewDraft INT
DECLARE @returnDraft INT
DECLARE @agerDraft INT
DECLARE @queryDraft INT
DECLARE @iwApproval INT
DECLARE @agerApproval INT	
DECLARE	@teamLeader NVARCHAR(max)			
BEGIN TRY 
 SET NOCOUNT ON;
			DECLARE @questTeamLeader NVARCHAR(MAX)='LEE,VINCENT|KATUMBA,FRANK|LOWER,ANDREW|GREEN,TREVOR|THORNE, MARK|STOLWORTHY,MARK|WHYTE, JAMES|ROPER,STEVE'					
			DECLARE @temptable TABLE
			(
				Id INT IDENTITY(1,1),
				TVNumber INT,
				TVType  NVARCHAR(20),
				StatusCategory NVARCHAR(20),
				StatusTitle CHAR(5),
				MileStoneStatus NVARCHAR(20)
			) 
		if(@flag='NONRPN')
		BEGIN
			 SET @teamLeader='LEE,VINCENT|KATUMBA,FRANK|LOWER,ANDREW|GREEN,TREVOR|THORNE, MARK|STOLWORTHY,MARK|WHYTE, JAMES'

			 INSERT @temptable (TVNumber,TVType,StatusCategory,StatusTitle,MileStoneStatus)
			 SELECT     
				t.TVNumber as TVNumber,
				t.TVType as TVType,
                ISNULL(wi.StatusCategory,'YTS') AS [StatusCategory],-- YTS Fault or NEW
                ISNULL(wi.StatusTitle,'N')  as StatusTitle,
					
				CASE 
					WHEN (StatusTitle='H' OR StatusTitle='N')
					THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
					WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
					THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 		

					WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
					THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 

					WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
					THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
					WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate  								  
					THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
					END
					AS MileStoneStatus
              FROM          [Edc].[OT_TV_Wide_Body_Data_Center] t
              LEFT JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
              LEFT JOIN	 [Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
              WHERE         
								t.DateCompleted  is null
							AND UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|')) 
			  				AND t.EngineMark Like '%'+isnull(@seriesKey,t.EngineMark)+'%'
							AND t.TVType = isnull(@tvType, t.TVType)
						
		END
		ELSE IF(@flag='RPN')
		BEGIN
			SET @teamLeader='ROPER,STEVE'
			
			INSERT @temptable (TVNumber,TVType,StatusCategory,StatusTitle,MileStoneStatus)
			 SELECT     
					t.TVNumber as TVNumber,
					t.TVType as TVType,
					ISNULL(wi.StatusCategory,'YTS') AS [StatusCategory],-- YTS Fault or NEW
					ISNULL(wi.StatusTitle,'N')  as StatusTitle,
								
					CASE 
						WHEN (StatusTitle='H' OR StatusTitle='N')
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 		

						WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 

						WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate								  
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						END
						AS MileStoneStatus

              FROM          [Edc].[OT_TV_Wide_Body_Data_Center] t
              LEFT JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
              LEFT JOIN	[Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
              WHERE         t.DateCompleted  is null
			  				AND t.EngineMark Like '%'+isnull(@seriesKey,t.EngineMark)+'%'
							AND t.TVType = isnull(@tvType, t.TVType)
							AND	UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|'))
							AND	(Team='RE-RPN-REACT' OR Team='SE-RPN-REACT')
	END			      


			 -- SELECT * FROM @temptable

	SET	@ytsHeadsUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='N' AND StatusCategory='YTS')
	SET	@inWorkHeadsUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND StatusCategory='InWork')
	SET	@queryHeadsUp = ( SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND StatusCategory='Query')
	SET	@rrReviewHeadsUp = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND StatusCategory='RRReview')
	SET	@agerHeadsUp =(SELECT COUNT(1) FROM @temptable WHERE StatusTitle='H' AND MileStoneStatus='MISSED' OR MileStoneStatus='RISK')
	SET	@ytdDraft = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND StatusCategory='YTD')
	SET	@inWorkDraft = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND StatusCategory='InWork')
	SET	@caReviewDraft = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND StatusCategory='CAReview')
	SET	@returnDraft = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND StatusCategory='Return')
	SET @agerDraft = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND MileStoneStatus='MISSED')
	SET @queryDraft = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='D' AND StatusCategory='Query')
	SET @iwApproval = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='A' AND StatusCategory='InWork')
	SET @agerApproval = (SELECT COUNT(1) FROM @temptable WHERE StatusTitle='A' AND MileStoneStatus='MET')



	SELECT  @ytsHeadsUp AS YTSHeadsUp,@inWorkHeadsUp AS InWorkHeadsUp,@queryHeadsUp AS QueryHeadsUp,
			@rrReviewHeadsUp AS RRreviewHeadsUp, @agerHeadsUp AS AgerHeadsUp, @ytdDraft AS YTDDraft,
			@inWorkDraft AS InWorkDraft,@caReviewDraft AS CAReviewDraft,@returnDraft AS ReturnDraft,
			@agerDraft AS AgerDraft,@queryDraft AS QueryDraft,@iwApproval AS IWApproval,
			@agerApproval AS AgerApproval
                           
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
