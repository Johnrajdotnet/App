
-- =============================================
--PROCEDURE: [Report].[SaveWipWBodyDetails]
--PURPOSE: Save the wip details
--CREATED: Neethu 13/06/2018
-- ============================================= 

CREATE PROCEDURE [Report].[SaveWipWBodyDetails]

@tvDataCenterId bigint,
@tvDataCenterActivityId bigint,
@engineer1 int,
@caengineer int,
@status nvarchar(200),
@category nvarchar(200),
@noofdamages nvarchar(200),
@userRoleId uniqueidentifier

AS


BEGIN TRY
-- ============================ Update Parent table ======================================
	UPDATE [Edc].[OT_TV_Wide_Body_Data_Center]
	SET InfoRequestedDetails=@category
		--DateIn=@dateIn,
		--CustomerRequiredDate=@requiredDate
	WHERE Id=@tvDataCenterId


-- ======================================= Insert/Update Child table ===============================
	IF(@tvDataCenterActivityId=0)
	BEGIN

		INSERT INTO [Edc].[OT_TV_Wide_Body_Activity_Center]
		(
			[TVDataCenterId],
			[Engineer1],
			[CAEngineer],
			[Status],
			[NumberofDamages],
			[CreatedBy],
			[CreatedDate]
		)
		VALUES
		(
			@tvDataCenterId,
			@engineer1,			
			@caengineer,
			@status,
			@noofdamages,
			@userRoleId,
			GETDATE()
		)
	END

	ELSE IF(@tvDataCenterActivityId!=0)
	BEGIN
		
		UPDATE [Edc].[OT_TV_Wide_Body_Activity_Center] SET
			[Engineer1]=@engineer1,			
			[CAEngineer]=@caengineer,
			[Status]=@status,
			[NumberofDamages]=@noofdamages,
			[ModifiedBy]=@userRoleId,
			[ModifiedDate]=GETDATE()
		WHERE Id=@tvDataCenterActivityId
	END
		

	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
GO


