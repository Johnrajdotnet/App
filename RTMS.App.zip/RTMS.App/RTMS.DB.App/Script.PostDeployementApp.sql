﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/



DBCC CHECKIDENT('[Edc].[ST_TV_Register_Attribute]', RESEED, 1)

GO
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(22B)-1RR', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(524)-2RR', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(524)-3RR', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(524)-7RR', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(535)-5RR', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(535)-4RR', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-211(535)-6RR', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EH-524-2RR', N'9', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EH-524-3RR', N'10', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EH-524-7RR', N'11', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EHC-22B-1RR', N'12', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EHC-535C-5RR', N'13', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EHC-535E4-4RR', N'14', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EHC-535E4-6RR', N'15', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EHC-TRENT-5RR', N'16', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EHC-TRENT-9RR', N'17', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EH-TRENT-1RR', N'18', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'EH-TRENT-2RR', N'19', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-TRENT-1RR', N'20', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-TRENT-5RR', N'21', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-TRENT-9RR', N'22', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MECH-22B-1RR', N'23', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MECH-535C-5RR', N'24', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MECH-535E4-4RR', N'25', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MECH-535E4-6RR', N'26', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MISC-524-7RR', N'27', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MISC-TRENT-1RR', N'28', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MISC-TRENT-2RR', N'29', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MISC-TRENT-5RR', N'30', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MISC-TRENT-9RR', N'31', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MM-524-2RR', N'32', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'MM-524-3RR', N'33', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'RR-CAEL-SPM', N'34', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'SN-22B-1RR', N'35', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'SN-524-2RR', N'36', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'SN-524-3RR', N'37', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'TH-22B-1RR', N'38', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'TH-524-2RR', N'39', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'TH-524-3RR', N'40', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-524-7RR', N'41', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-535C-5RR', N'42', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-535E4-4RR', N'43', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-535E4-6RR', N'44', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-TRENT-1RR', N'45', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-TRENT-2RR ', N'46', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-TRENT-5RR', N'47', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'THD-TRENT-9RR', N'48', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'Ser211-T', N'49', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(22B)1RR', N'50', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(524)2RR', N'51', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(524)3RR', N'52', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(535)4RR', N'53', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(535)5RR', N'54', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(535)6RR', N'55', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T211(524)7RR', N'56', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T(Trent)1RR', N'57', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T(Trent)2RR', N'58', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'T(Trent)5RR', N'59', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'E-TRENT-2RR', N'60', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (1, N'CR-TRENT-5RR', N'61', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (2, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (3, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'535C-37', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'535E4-37', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'535E4-B-37', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'535E4-B-75', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'535E4-C-37', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT553-61', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT553A2-61', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556-61', N'9', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556A2-61', N'10', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT768-60', N'11', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT772-60', N'12', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT772B-60', N'13', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT772C-60', N'14', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT875-17', N'15', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT877-17', N'16', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT884-17', N'17', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT884B-17', N'18', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT892-17', N'19', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT892B-17', N'20', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT895-17', N'21', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524G2-19', N'22', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524G2-T-19', N'23', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524H2-19', N'24', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524H2-T-19', N'25', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524H-36', N'26', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524H-T-36', N'27', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556A99-01', N'28', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'22B-02', N'29', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524B-02', N'30', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524B2-19', N'31', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524B3-02', N'32', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524B4-02', N'33', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524C2-19', N'34', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524D4-19', N'35', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524D4-39', N'36', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'524G3-T-19', N'37', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT1000', N'38', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556B-61', N'39', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT970-84', N'40', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT972-84', N'41', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT560-61', N'42', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT977-84', N'43', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT980-84', N'44', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556A2-62', N'45', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556-62', N'46', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556-63', N'47', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT556B2-61', N'48', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT560A2-61', N'49', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT970B-84', N'50', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT972B-84', N'51', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENT977B-84', N'52', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENTXWB-84', N'53', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (4, N'TRENTXWB-97', N'54', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (5, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'Linera Assy Combustion Outer Rear', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'None', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'20 DEG RH DEFLECTOR BOX', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ACAC DUCT', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ACAC DUCT ADAPTER ASSY.', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ACCESS COVER', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ACOUSTIC FAIRING SUPPORT STRUCTURE', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'AFTERBODY FAIRING ASSY', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'AIR INTAKE COWL', N'9', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'AIR MOTOR MOUNTING BRACKET', N'10', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'AIR SEAL TUBE ASSY', N'11', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'AIR TUBE', N'12', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ANGLE DRIVE SHAFT LOWER SHROUD', N'13', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ANNULUS FORMER STRIP', N'14', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ANTI ICING AIR DUCT', N'15', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BEVEL GEAR HSG', N'16', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLANKING BOX', N'17', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLEED VALVE SEAL PLATE', N'18', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLOCKER FLAP', N'19', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLOCKER FLAP - HINGE BRACKET', N'20', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLOCKER FLAP - SPHERICAL BEARING HOUSING ASSY', N'21', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLOCKER FLAP ACTUATING ROD', N'22', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BLOCKER FLAP BLISTER FAIRING', N'23', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BORESCOPE PLUG', N'24', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BREATHER ROTOR', N'25', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'BREATHER ROTOR GEARSHAFT', N'26', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'CABIN AIR DUCT', N'27', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'CENTRAL OIL TUBE', N'28', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'CENTRAL OIL TUBE SUPPORT', N'29', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COLD NOZZLE ASSY', N'30', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMB FRONT INNER CASE', N'31', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMB LINER ASSY', N'32', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMB OUTER CASE', N'33', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMB REAR INNER CASE', N'34', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMB SECTION GAS GENERATOR FAIRING', N'35', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMB SUPPORT CASE', N'36', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMBUSTION', N'37', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMMON NOZZLE ASSEMBLY', N'38', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMP GAS GENERATOR FAIRINGS', N'39', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMP INTERMEDIATE CASE', N'40', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMP SECTION GAS GENERATOR FAIRING', N'41', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COMP/TURB SUPPORT DISC', N'42', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COOLING AIR INLET MANIFOLD DUCT', N'43', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'COOLING AIR MANIFOLD', N'44', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'CORE FAIRING', N'45', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'CORONA', N'46', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'DEFLECTOR OIL ROTATING SEAL', N'47', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'DETACHABLE FAIRING - L/H', N'48', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'DETACHABLE FAIRING - R/H', N'49', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'DFC ADAPTOR GEARBOX', N'50', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'DRAINS MAST', N'51', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'DRIVING BEVEL LOCATION BEARING HOUSING', N'52', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EEC DEDICATED GENERATOR', N'53', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EEC SUITCASE', N'54', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ELECTRICAL HARNESSES', N'55', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ENGINE', N'56', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ENGINE ELECTRONIC CONTROLLER (EEC)', N'57', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXHAUST COLLECTOR', N'58', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXHAUST COLLECTOR AFTERBODY FAIRING', N'59', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXHAUST CONE', N'60', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXHAUST FAN THRUST REVERSER CONE', N'61', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXHAUST TRANSITION CASE', N'62', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXTERNAL GEARBOX DRIVE SHAFT', N'63', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXTERNAL GEARBOX DRIVE SHAFT COUPLING', N'64', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXTERNAL GEARBOX DRIVE SHAFT SHROUDS', N'65', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'EXTERNAL GEARBOX INPUT DRIVE BEVEL GEARS HOUSING', N'66', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FAN COWL DOOR, L/H', N'67', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FAN COWL DOOR, RH', N'68', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FBH FRONT OUTER STATIC SEAL', N'69', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FBH REAR OUTER STEPPED SEAL', N'70', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FBH REAR STATIC SEAL ASSY', N'71', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FCL - BURNER SEALING RINGS', N'72', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FCL - HEATSHIELD', N'73', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FCU DRIVE GEARSHAFT', N'74', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FIRESEAL PYLON TO SUPPORT STRUCTURE', N'75', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FIREWALL', N'76', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FOHE SUPPORT LINK', N'77', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FORCED MIXER', N'78', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT BEARING CHAMBER OIL SEAL', N'79', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT BEARING HOUSING', N'80', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT COMB LINER', N'81', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT COMB LINER ASSY', N'82', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT COMB LINER HEATSHIELD', N'83', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT COMB LINER MOUNTING PINS', N'84', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT COMBUSTION OUTER CASE', N'85', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT EM CENTRE THRUST LINK', N'86', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT EM FAILSAFE LINK', N'87', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT EM SUPPORT BRACKET', N'88', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT EM SUPPORT LINK', N'89', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT ENGINE MOUNT', N'90', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT GEARBOX HOUSING', N'91', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT INNER COMB CASE', N'92', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT MOUNT COMPONENTS', N'93', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT MOUNT COMPONENTS', N'94', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT MOUNT OUTER SUPPORT', N'95', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT MOUNT SUPPORT BRACKET', N'96', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'<FRONT MOUNT VERTICAL LOAD LINKS', N'97', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N' MOUNT VERTICAL LOAD SUPPORT ASSY', N'98', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT SEAL, HP/IPT BRG SUPPORT', N'99', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT SEALING RING', N'100', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT STATIC AIR SEAL ', N'101', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT STATIC OIL SEAL ', N'102', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FRONT SUPPORT OIL SEAL CARRIER', N'103', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FSN SEAL CARRIER', N'104', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FUEL DRAIN TANK', N'105', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FUEL MANIFOLD', N'106', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FUEL SPRAY NOZZLE', N'107', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FUEL SPRAY NOZZLE', N'108', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'FUEL TUBE', N'109', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'GAS GENERATOR FAIRING - COMBUSTION', N'110', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'GAS GENERATOR FAIRING SUPPORT STRUCTURE', N'111', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HARNESS', N'112', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HINGED COWL SUPPORT STRUCTURE', N'113', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HOOP PLATE', N'114', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP AIR DUCT', N'115', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP BLEED VALVE DUCT', N'116', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP COMPRESSOR', N'117', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP LOCATION BALL BRG', N'118', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP LOCATION BALL BRG ASSY', N'119', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP LOCATION SUPPORT CONE', N'120', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP OGV CASE', N'121', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP OGV REAR CASE', N'122', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP RETAINING RING', N'123', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP TURBINE', N'124', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IP AIR DUCT', N'125', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IP BEARING SUPPORT', N'126', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IP OUTER BEARING SUPPORT CASE', N'127', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IP SUPPORT FRONT BAFFLE PLATE', N'128', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IP TURBINE OUTER CASE', N'129', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IP TURBINE ROLLER BRG ASSY', N'130', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IPT BRG SLEEVE', N'131', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IPT BRG SUPP FRONT INNER AIR SEAL', N'132', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HP/IPT CASE COOLING AIR MANIFOLDS', N'133', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC CASE AND VANES', N'134', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC CENTRE LOCATING CONE', N'135', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC DRIVING BEVEL GEARSHAFT', N'136', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC FRONT LOCATING CONE', N'137', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC OGV ASSY', N'138', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC OGV CASE', N'139', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC OUTER LOCATION RING', N'140', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC OUTER SEAL HSG', N'141', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC REAR LOCATING CONE', N'142', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC ROTOR SHAFT', N'143', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC SEAL HSG', N'144', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC SEAL HSG', N'145', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STAGE 5-6 ROTOR SHAFT', N'146', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1 BLADE', N'147', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1 CASE', N'148', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1 INNER SHROUD RING', N'149', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1 INNER SHROUD RING', N'150', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1 ROTOR PATH RING', N'151', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1 VANE ASSY', N'152', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-2 DISC', N'153', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-2 ROTOR', N'154', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-2 SUPPORT CASE', N'155', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-4 DISC', N'156', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-4 ROTOR SHAFT', N'157', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-5 VANE ASSY', N'158', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-6 BLADES', N'159', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 1-6 ROTOR SHAFT', N'160', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 BLADE', N'161', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 CASE', N'162', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 HEAT SHIELD', N'163', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 INNER SHROUD RING', N'164', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 ROTOR PATH RING', N'165', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 VANE', N'166', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2 VANE ASSY', N'167', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 2-3 HEAT SHIELD', N'168', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3 BLADE', N'169', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3 CASE', N'170', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3 DISC', N'171', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3 INNER SHROUD RING', N'172', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3 ROTOR PATH RING', N'173', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3 VANE ASSY', N'174', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 3-4 SUPPORT CASE', N'175', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4 BLADE', N'176', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4 CASE', N'177', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4 HEAT SHIELD', N'178', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4 INNER SHROUD RING', N'179', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4 ROTOR PATH RING', N'180', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4 VANE ASSY', N'181', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 4-6 ROTOR SHAFT', N'182', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 5 BLADE', N'183', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 5 INNER SHROUD RING', N'184', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 5 OUTER CASE', N'185', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 5 ROTOR PATH RING', N'186', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'<HPC STG 5 VANEHPC STG 5 VANE', N'187', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 5 VANE ASSY', N'188', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 5-6 ROTOR SHAFT', N'189', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 6 BLADE', N'190', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 6 OUTER CASE', N'191', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STG 6 ROTOR PATH RING', N'192', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPC STUB SHAFT', N'193', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT BEARING FRONT RETAINER', N'194', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT BLADE', N'195', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT BLADE ASSEMBLY', N'196', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT BLADE SEALING DAMPER', N'197', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT BRG RACE SUPPORT PANEL', N'198', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT CONICAL SHAFT', N'199', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT COVER PLATE', N'200', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT DISC', N'201', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT DISC FRONT SEALING PLATE', N'202', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT DISC REAR PANEL', N'203', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT DRIVE SHAFT', N'204', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT FRONT OUTER INNER AIRSEAL', N'205', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT INNER SEAL', N'206', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT LP AIR NOZZLE', N'207', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT NGV', N'208', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT NGV SUPPORT RING', N'209', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT OUTER AIR SEAL', N'210', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT PRE-SWIRL NOZZLE', N'211', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT RACE', N'212', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT REAR OUTER SEAL', N'213', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT REAR OUTER SUPPORT ASSY', N'214', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT ROLLER BRG', N'215', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT SEAL PLATE', N'216', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT SEAL SEGMENT', N'217', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT SEAL SEGMENT RETAINING RING', N'218', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT STUB SHAFT', N'219', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HPT STUB SHAFT ASSY', N'220', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HSGB FRONT AND REAR HSGS', N'221', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HSGB FRONT HSG', N'222', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HSGB MAIN HSG', N'223', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HSGB REAR HSG', N'224', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HYDRAULIC PUMP NO 1 GEARSHAFT', N'225', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HYDRAULIC PUMP NO 2 GEARSHAFT', N'226', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HYDRAULIC SYSTEM RIGID TUBES', N'227', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'HYDRAULIC TUBE', N'228', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'ICE IMPACT PANELS/ACOUSTIC PANELS', N'229', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IDG ACCESS DOOR', N'230', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IDG CONTROL HARNESS', N'231', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IDG COOLER OUTLET DUCT', N'232', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IDG GEARSHAFT', N'233', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IDG IDLER GEARSHAFT', N'234', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IDG INLET DUCT', N'235', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INT GBOX DRIVE SHAFT SEAL HSG', N'236', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTEGRATED NOZZLE ASSY', N'237', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTEGRATED NOZZLE FAIRING', N'238', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE', N'239', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE FRONT AIR SEAL', N'240', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE FRONT AIR/OIL SEAL', N'241', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE REAR AIR SEAL', N'242', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE REAR OIL/AIR SEAL', N'243', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE SPHERICAL  BEARING HOUSING', N'244', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE SPHERICAL BUSHES', N'245', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE CASE/HPC OUTER LOCATION RING', N'246', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERMEDIATE COMP CASE ASSY.', N'247', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERNAL GBOX DRIVE SHAFT', N'248', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERNAL GBOX DRIVEN BEVEL GEAR', N'249', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERNAL GBOX DRIVING BEVEL GEAR', N'250', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERSERVICES FAIRING, ACCESS PANEL ', N'251', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTERSERVICES FAIRING, STRUCTURE', N'252', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'INTRASCOPE PLUG', N'253', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP AIR DUCT', N'254', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP COMPRESSOR', N'255', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP LOCATION BALL BRG', N'256', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP LOCATION BALL BRG SLEEVE', N'257', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP LOCATION SUPPORT RING', N'258', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP NOZZLE ASSEMBLY', N'259', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP OGV INNER SHROUD', N'260', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP TURBINE', N'261', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP TURBINE BLADE RETAINING PLATE', N'262', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP/HP INTERFACE AIR DUCT', N'263', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP/LP LOCATION BEARING ASSEMBLY', N'264', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IP/LP SPLITTER FAIRING', N'265', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC BEARING SUPPORT', N'266', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC CARBON SEAL RUNNER', N'267', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC CARBON SEAL STATIC HSG', N'268', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC CASE AND VANE ASSEMBLY', N'269', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC COMP REAR CURVIC RING', N'270', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC FRONT CASE ASSY', N'271', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC FRONT SEAL CARRIER', N'272', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC FRONT STUB SHAFT', N'273', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC FRONT STUB SHAFT LINER', N'274', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC OGV', N'275', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC OGV CASE', N'276', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC REAR CASE', N'277', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC REAR CURVIC RING', N'278', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC REAR SEAL RETAINER', N'279', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC REAR SHAFT ASSEMBLY', N'280', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC REAR STUB SHAFT', N'281', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC REAR STUB SHAFT SEAL CARRIER', N'282', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC ROLLER BRG AND REAR OIL SEAL HSG', N'283', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC ROLLER BRG ASSY', N'284', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC ROTOR ASSEMBLY', N'285', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC ROTOR FRONT AIR SEAL', N'286', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC ROTOR SHAFT', N'287', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STAGE 1 TO 8 BLADES', N'288', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STAGE 3 DISC', N'289', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STAGE 5 DISC', N'290', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STATIC SEAL', N'291', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STATOR VANES', N'292', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 BLADE', N'293', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 CASE', N'294', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 DISC', N'295', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 INNER SHROUD RING', N'296', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 VANES', N'297', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 VSV', N'298', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1 VSV INNER SHROUD RING', N'299', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1-2 VSV', N'300', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1-5 ROTOR SHAFT', N'301', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1-6 ROTOR', N'302', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1-7 BLADES', N'303', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 1-8 ROTOR', N'304', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 BLADE', N'305', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 CASE', N'306', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 DISC', N'307', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 INNER SHROUD RING', N'308', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 VANES', N'309', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 VSV', N'310', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2 VSV INNER SHROUD RING', N'311', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2-6 BLADE', N'312', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 2-6 CASE', N'313', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3 BLADE', N'314', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3 CASING', N'315', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3 DISC', N'316', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3 INNER SHROUD RING', N'317', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3 VANES', N'318', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3-7 SHROUD RINGS', N'319', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3-7 VANES', N'320', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3-8 CASE', N'321', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 3-8 CASE AND VANE ASSY', N'322', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 4 BLADE', N'323', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 4 CASE', N'324', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 4 DISC', N'325', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 4 INNER SHROUD RING', N'326', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 4 VANES', N'327', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 5 BLADE', N'328', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 5 DISC', N'329', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 5 DISC', N'330', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 5 INNER SHROUD RING', N'331', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 5 VANES', N'332', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 6 BLADE', N'333', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 6 INNER SHROUD RING', N'334', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 6 VANES', N'335', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 6-7 ROTOR SHAFT', N'336', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 7 BLADE', N'337', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 7 INNER SHROUD RING', N'338', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 7 VANES', N'339', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 8 BLADE', N'340', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG 8 INNER SHROUD RING', N'341', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC STG2 CASE', N'342', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC VIGV', N'343', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'<IPC VIGV ACTUATING MECHANISMIPC VIGV ACTUATING MECHANISM', N'344', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC VSV ACTUATING MECHANISM', N'345', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC VSV CASE', N'346', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPC VSV PLATE ASSEMBLY', N'347', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT ANNULUS SEGMENTS', N'348', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT BLADE', N'349', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT BRG INNER RACE ASSY', N'350', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT BRG RETAINER', N'351', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT DISC', N'352', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT DISC &amp; SHAFT', N'353', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT DISC LOCK PLATE', N'354', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT DISC STOP RING', N'355', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT NGV', N'356', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT NGV FRONT SEALING RING', N'357', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT NGV REAR SEAL SUPPORT', N'358', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT NGV REAR SEALING RING', N'359', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT OUTER CASE', N'360', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT REAR AIR SEAL', N'361', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT ROLLER BRG', N'362', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT ROTOR ASSY', N'363', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT SEAL SEGMENT', N'364', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT SEAL SEGMENT THERMAL SHIELD', N'365', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT SHAFT', N'366', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT STUB SHAFT', N'367', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'IPT STUB SHAFT AIR TRANSFER TUBE', N'368', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LH AIR INTAKE COWL', N'369', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LH UPPER SUPPORT ASSEMBLY', N'370', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LOWER BIFURCATION DISCONNECT PANEL', N'371', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LOWER BLEED VALVE DUCT', N'372', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LOWER SPLITTER FAIRING', N'373', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP AIR NOZZLE ASSEMBLY', N'374', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP COMPRESSOR', N'375', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP COMPRESSOR A FRAME SUPPORT', N'376', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP FUEL FILTER HOUSING', N'377', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP LOCATION BALL BRG ASSY', N'378', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP LOCATION BRG RING SEAL HSG', N'379', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP TURBINE', N'380', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (6, N'LP/IPC SPLITTER FAIRING', N'381', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP1 NGV FRONT SUPPORT', N'382', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP1 TURBINE DISC SEAL SUPPORT PANEL ASSEMBLY', N'383', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP1-LP2 INTERSTAGE SEAL', N'384', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP1-LP2 INTERSTAGE SEAL RETAINING RING', N'385', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP2-LP3 INTERSTAGE SEAL', N'386', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP2-LP3 INTERSTAGE SEAL RETAINING RING', N'387', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LP2/LP3 TURBINE OUTER CASE', N'388', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC A-FRAME SUPPORT FAIRING', N'389', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC ACCESSORIES MOUNTING STRAP', N'390', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC ANNULUS FILLER', N'391', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC ANTI-ICING TUBE', N'392', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC BEARING HOUSING', N'393', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC BEARING INNER RACE', N'394', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC BLADE', N'395', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC BLADE DAMPER', N'396', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC CARBON SEAL RUNNER', N'397', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC CARBON SEAL STATIC HSG', N'398', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC CASE SUPPORT STRUCTURE', N'399', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC DISC', N'400', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC DISC ANTI SCORE RING', N'401', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC DISC SLIDER ASSY', N'402', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC FAILSAFE SHAFT', N'403', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC FAN RETENTION SHAFT', N'404', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC FRONT CASE', N'405', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC NOSE CONE SUPPORT RING', N'406', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC OGV ASSY', N'407', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC OUTER SHAFT ASSY', N'408', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC REAR CASE', N'409', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC REAR SEAL PLATE', N'410', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC REAR SHAFT', N'411', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC REAR SPINNER', N'412', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC ROLLER BRG ASSY', N'413', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC ROLLER BRG HSG', N'414', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC ROTOR ASSEMBLY', N'415', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC SHAFT', N'416', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC SPINNER ASSY', N'417', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC SPINNER FAIRING', N'418', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC STATIC AIR SEAL', N'419', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC STUB SHAFT', N'420', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPC SUPPORT RING ASSY', N'421', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT AIR GUIDE TUBE', N'422', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT BRG AND SUPPT EXHAUST CASE', N'423', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT BRG HSG END COVER', N'424', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'<LPT BRG SUPPORT ASSYLPT BRG SUPPORT ASSY', N'425', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT BRG SUPPORT HOUSING STATIC AIR SEAL', N'426', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT BRG SUPPORT SPOKE FAIRINGS', N'427', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT BRG SUPPT HUB SHROUD ASSY', N'428', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT CASE', N'429', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT CASE COOLING DUCT', N'430', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT COOLING AIR MANIFOLD', N'431', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT EXHAUST CASE', N'432', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT MODULE 05', N'433', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT MODULE 08', N'434', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT NGV CASE', N'435', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT NGV LOCATION STUDS', N'436', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT OUTER CASE', N'437', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT PHONIC RING', N'438', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT ROLLER BRG ASSY', N'439', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT SHAFT', N'440', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT SHAFT ASSY', N'441', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 1 BLADE ASSY', N'442', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 1 DISC', N'443', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 1 NGV', N'444', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 1 SEAL SEGMENT', N'445', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 1-2 SEAL', N'446', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 2 BLADE ASSY', N'447', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 2 DISC', N'448', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 2 INTERSTAGE SEAL', N'449', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 2 NGV', N'450', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 2 NGV ASSY', N'451', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 2 SEAL SEGMENT', N'452', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 BLADE ASSY', N'453', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 DISC', N'454', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 INTERSTAGE SEAL', N'455', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 NGV', N'456', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 NGV ASSY', N'457', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 SEAL SEGMENT', N'458', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3 SEAL SEGMENT SUPPORT RING', N'459', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 3-5 SEAL SEGMENTS', N'460', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 4 BLADE ASSY', N'461', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 4 DISC', N'462', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 4 INTERSTAGE SEAL', N'463', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 4 NGV', N'464', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 4 SEAL SEGMENT', N'465', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 5 BLADE ASSY', N'466', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 5 DISC', N'467', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 5 INTERSTAGE SEAL', N'468', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 5 NGV', N'469', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG 5 SEAL SEGMENT', N'470', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STG1 SEAL SUPPORT PANEL', N'471', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STRUT SUPPORT FAIRING', N'472', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LPT STUB SHAFT', N'473', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LWTR CORONA', N'474', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LWTR CORONA CLEVIS END ASSEMBLY', N'475', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'LWTR FIXED STRUCTURE', N'476', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'MODULE 04', N'477', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'No 1 HYDRAULIC PUMP GEARSHAFT', N'478', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'No 2 HYDRAULIC PUMP GEARSHAFT', N'479', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE CONE SUPPORT RING ASSEMBLY', N'480', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE COWL', N'481', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE COWL ACOUSTIC PANEL', N'482', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE COWL LIP SKIN', N'483', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE SPLITTER FAIRING - LOWER', N'484', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE SPLITTER FAIRING - UPPER', N'485', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOSE SPLITTER FAIRING - UPPER AND LOWER', N'486', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'NOZZLE EXTENSION AND SEAL', N'487', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'OIL PUMP HOUSING', N'488', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'OIL TANK', N'489', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'OIL TANK COVER', N'490', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'OIL TUBE', N'491', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'P20/T20 PROBE', N'492', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'PIVOT DOOR', N'493', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'PRESSURE PUMP HSG', N'494', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'PROCESS (TSD594-J)', N'495', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'PYLON FAIRING', N'496', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'PYLON FAIRING STRUCTURE', N'497', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'PYLON SPLITTER FAIRING NOSE SECTION', N'498', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'RADIAL DRIVE FAIRING', N'499', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'RADIAL DRIVE SHROUD TUBE', N'500', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR EM FAILSAFE LINK', N'501', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR EM SUPPORT BRACKET', N'502', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR EM SUPPORT LINK', N'503', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR INNER COMB CASE', N'504', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR INNER COMB LINER', N'505', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR INNER SEAL CARRIER', N'506', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR LOCATING CONE', N'507', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR MOUNT BRACKET ASSY', N'508', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR MOUNT COMPONENTS', N'509', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR MOUNT LINKS', N'510', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR OIL/AIR SEAL ', N'511', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR OUTER COMB LINER', N'512', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR OUTER COMB LINER ASSY', N'513', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR ROTATING AIR SEAL', N'514', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR SPINNER', N'515', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR SPLITTER FAIRING', N'516', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR STATIC AIR SEAL ', N'517', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'REAR STATIC OIL SEAL ', N'518', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'RH OUTER CASE FAIRING', N'519', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'RIGID TUBES', N'520', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SAGB - HSGB DRIVING GEAR ASSY', N'521', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SAGB HOUSING', N'522', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SCAVENGE PUMP HSG', N'523', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SERVICES DISCONNECT PLATFORM', N'524', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SPHERICAL BEARING', N'525', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SPOKE FAIRING REAR SUPPORT', N'526', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'STARTER AIR DUCT', N'527', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'STARTER GEARSHAFT', N'528', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'SWIVEL FLAP SUPPORT', N'529', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THERMAL ANTI-ICE DUCT', N'530', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THERMOCOUPLE', N'531', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER', N'532', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER AIR SUPPLY DUCT', N'533', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER BLOCKER DOOR', N'534', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER C-DUCTS', N'535', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER DEFLECTOR BOX', N'536', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER FIXED STRUCTURE', N'537', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER HINGE ACCESS COVER', N'538', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER LH C-DUCT', N'539', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER LOWER LEFT HAND PIVOT DOOR', N'540', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER LOWER PIVOT DOORS', N'541', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER LOWER RIGHT HAND PIVOT DOOR', N'542', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER RAMP BRACKET', N'543', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER RH C-DUCT', N'544', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER TCC DUCT', N'545', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER TRANSLATING COWL', N'546', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER UPPER &amp; LOWER PIVOT DOORS', N'547', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER UPPER LEFT HAND PIVOT DOOR', N'548', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER UPPER PIVOT DOORS', N'549', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER UPPER RIGHT HAND PIVOT DOOR', N'550', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER, FWD PRESSURE SEAL', N'551', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER, TRANSLATING SLEEVE, L/H', N'552', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'THRUST REVERSER, TRANSLATING SLEEVE, R/H', N'553', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSFER DRIVE FAIRING-LH', N'554', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSFER DRIVE FAIRING-RH', N'555', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSFER GEARBOX HOUSING ASSEMBLY', N'556', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSITION CASE', N'557', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSLATING COWL', N'558', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSLATING COWL FINGER BRACKET', N'559', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TRANSLATING SLEEVE', N'560', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TURB SECTION GAS GENERATOR FAIRING', N'561', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'TURBINE EXHAUST PLUG', N'562', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'UPPER BIFURCATION FAIRING', N'563', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'V-GROOVE ASSY', N'564', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'VIGV', N'565', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'VIGV ACTUATOR RING ASSY', N'566', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 6, N'VIGV INNER PIVOT RING ASSEMBLY', N'567', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 7, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 8, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 9, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 10, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 11, N'Serviceability', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 11, N'Check & Repair', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 11, N'Qverhaul', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 11, N'Performance Restoration', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 11, N'Not Applicable', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 12, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'05-00-01', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'10/5/2001', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'10/5/2002', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'05-20-01', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'05-20-02', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-11-03', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-11-04', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-11-05', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-11-06', N'9', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-11-12', N'10', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-21-12', N'11', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-21-15', N'12', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-21-61', N'13', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-22-11', N'14', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'24-22-49', N'15', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'26-11-01', N'16', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'26-12-15', N'17', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'26-21-14', N'18', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'26-21-49', N'19', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-02', N'20', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-03', N'21', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-06', N'22', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-11', N'23', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-18', N'24', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-48', N'25', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'29-11-49', N'26', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'30-21-02', N'27', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'30-21-03', N'28', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'30-21-04', N'29', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'30-21-09', N'30', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'30-21-48', N'31', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-11-01', N'32', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-11-02', N'33', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-11-06', N'34', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-11-48', N'35', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-11-49', N'36', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-11-52', N'37', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-12-05', N'38', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'36-12-06', N'39', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'70-00-00', N'40', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'70-00-20', N'41', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-00', N'42', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-31', N'43', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-32', N'44', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-33', N'45', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-34', N'46', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-41', N'47', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-52', N'48', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-00-61', N'49', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-01', N'50', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-02', N'51', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-03', N'52', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-04', N'53', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-06', N'54', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-07', N'55', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-09', N'56', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-11-17', N'57', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-12-11', N'58', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-12-12', N'59', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-12-15', N'60', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-12-16', N'61', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-21-00', N'62', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-21-01', N'63', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-21-02', N'64', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-21-11', N'65', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-21-12', N'66', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-21-42', N'67', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-22-42', N'68', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-30-01', N'69', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-30-02', N'70', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-30-03', N'71', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-40-01', N'72', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-40-02', N'73', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-40-03', N'74', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-40-11', N'75', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-01', N'76', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-02', N'77', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-03', N'78', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-04', N'79', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-05', N'80', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-06', N'81', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-07', N'82', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-08', N'83', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-09', N'84', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-10', N'85', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-11', N'86', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-12', N'87', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-13', N'88', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-14', N'89', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-15', N'90', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-16', N'91', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-17', N'92', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-18', N'93', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-19', N'94', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-20', N'95', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-21', N'96', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-22', N'97', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-23', N'98', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-24', N'99', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-24', N'100', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-28', N'101', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-29', N'102', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-30', N'103', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-31', N'104', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-32', N'105', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-33', N'106', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (13, N'71-51-34', N'107', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-35', N'108', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-36', N'109', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-39', N'110', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-40', N'111', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-41', N'112', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-42', N'113', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-44', N'114', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-45', N'115', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-46', N'116', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-52', N'117', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-53', N'118', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-54', N'119', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-55', N'120', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-56', N'121', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-57', N'122', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-58', N'123', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-60', N'124', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-61', N'125', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-62', N'126', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-64', N'127', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-65', N'128', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-66', N'129', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-70', N'130', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-71', N'131', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-72', N'132', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-73', N'133', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-74', N'134', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-76', N'135', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-77', N'136', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-78', N'137', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-79', N'138', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-51-80', N'139', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-11', N'140', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-12', N'141', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-13', N'142', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-14', N'143', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-15', N'144', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-16', N'145', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-17', N'146', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-18', N'147', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-23', N'148', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-26', N'149', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-28', N'150', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-29', N'151', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-30', N'152', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-31', N'153', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-52-60', N'154', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-61-00', N'155', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-61-11', N'156', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-61-41', N'157', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-01', N'158', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-02', N'159', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-03', N'160', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-05', N'161', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-11', N'162', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-12', N'163', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-13', N'164', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-14', N'165', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-47', N'166', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-48', N'167', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'71-71-49', N'168', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-00', N'169', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-05', N'170', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-31', N'171', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-32', N'172', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-33', N'173', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-34', N'174', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-41', N'175', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-51', N'176', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-52', N'177', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-00-61', N'178', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-02-01', N'179', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-00', N'180', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-01', N'181', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-02', N'182', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-03', N'183', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-04', N'184', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-05', N'185', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-06', N'186', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-11', N'187', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-03-14', N'188', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-00', N'189', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-10', N'190', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-11', N'191', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-12', N'192', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-16', N'193', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-17', N'194', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-20', N'195', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-31-25', N'196', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-00', N'197', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-10', N'198', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-11', N'199', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-12', N'200', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-13', N'201', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-14', N'202', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-20', N'203', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-30', N'204', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-31', N'205', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-32', N'206', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-40', N'207', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-41', N'208', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-42', N'209', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-43', N'210', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-45', N'211', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-46', N'212', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-32-47', N'213', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-00', N'214', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-08', N'215', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-10', N'216', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-11', N'217', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-12', N'218', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-20', N'219', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-21', N'220', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-22', N'221', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-23', N'222', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-24', N'223', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-25', N'224', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-30', N'225', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-31', N'226', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-32', N'227', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-35', N'228', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-36', N'229', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-37', N'230', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-38', N'231', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-40', N'232', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-41', N'233', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-42', N'234', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-43', N'235', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-44', N'236', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-45', N'237', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-46', N'238', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-47', N'239', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-33-48', N'240', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-00', N'241', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-10', N'242', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-11', N'243', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-12', N'244', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-13', N'245', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-14', N'246', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-15', N'247', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-34-16', N'248', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-00', N'249', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-01', N'250', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-02', N'251', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-03', N'252', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-04', N'253', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-05', N'254', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-11', N'255', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-13', N'256', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-15', N'257', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-35-16', N'258', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-41-00', N'259', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-41-10', N'260', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-41-11', N'261', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 13, N'72-41-12', N'262', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 14, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 15, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 16, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 17, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 18, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 19, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 20, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 21, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 22, N'', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'BCAR Section C', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'CS-25', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'CS-E', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'FAR-25', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'JAR-25', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'JAR-E', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'None', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 23, N'Not Applicable', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'1', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'2', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'3', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'4', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'5', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'6', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'Major', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'Minor', N'9', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 24, N'Not Applicable', N'10', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 25, N'Service', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 25, N'Repair', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 25, N'Performance', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 25, N'Not Specified', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 25, N'None', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Front office off wing', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Front office on wing', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Back office', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Repair', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'LCC Management', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Bangalore', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Long term or Repeats', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 26, N'Bangalore Long Term or Repeat', N'9', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (27,'Jacob, R',1,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (27,'Oberstadt, Dirk',2,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (27,'Payne, C',1,3, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (27,'QuEST Pro Active',4,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (27,'Sundstrem, G',5,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)
------------------already commented-----------------------------------------------------------------
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'None',1,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Abhijith, C S',2,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Amirthavarshini.S',3,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Aravind Kumar P',4,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chakraborty, K',5,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chambers. L',6,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chandrabhan',7,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chetan Goudra',8,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chetan Shastry',9,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chikkalingaiah, AG',10,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Chikkalingaiah, AH',11,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Deepak S',12,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Dupre, J',13,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Elsdon, C',14,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Farquhar, B',15,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Fengler, T',16,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Ferguson, S',17,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'George, E',18,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Gerakis, J',19,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Gläser, S',20,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Grant, F',21,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Grübe, M',22,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Gupta, A',23,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Handuja, R',24,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Henschel, K',25,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Herold, C',26,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Higson, P',27,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Jain, A',28,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Jain, JC',29,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Jakayumar, P',30,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Jayaganesh, S',31,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Jose, Bintu',32,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Kaarthikeyan G',33,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Koehler, T',34,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Kouloubandi, P',35,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Kumar M, Ranjith',36,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Kumaraswamy, S',37,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Kuralekh, S',38,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Liepke, A',39,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Lipke, M',40,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Litzenberg , H',41,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Lux, A',42,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Majumder, A',43,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Mandrek, M',44,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Martin-Arroyo Lopiz, M',45,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'McColl, A',46,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'McGovern, G',47,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Megha Kondamudi',48,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Mohideen. K',49,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Mueller, B',50,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Mukherjee, P',51,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Müller, H',52,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Murali, MB',53,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Nagamalleswararao, K',54,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Nagaraj, Rao',55,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Nagaraju, S',56,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Nahrstedt, C',57,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Naveen M',58,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Panchal, N',59,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Patel, S',60,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Paties-Simon, E',61,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Payne, C',62,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Petchiappan, P',63,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Peter, N',64,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Prasanna, K',65,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Pratsch, T',66,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Rai, VK',67,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Rajeev, S',68,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Ravi, V',69,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Ravikumar, S',70,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Richters, B',71,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Rostock, S',72,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sah, S',73,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sampath, M',74,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sanal, S',75,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sanjai, JK',76,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Santhanraj, J',77,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Saravanan, NB',78,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sasidhar P',79,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Schirmer, J',80,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Schreck, A',81,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Schulze, R',82,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Shajan, N',83,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Shanmugham, G',84,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sharma, G',85,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Shunmugam,G',86,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Silvestre, D',87,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Singh, S',88,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sivakumar, C',89,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Soloman, R',90,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Specht, A',91,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sreenivasa, RJ',92,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sundstrem, G',93,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Sundstrem, J',94,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Uhe, S',95,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Vanavi Boopalan',96,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Veerakumar, P',97,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Vempilly, K',98,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Vinayak Barigidad',99,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Westrik, S',100,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Wisniewski, K',101,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Woodland, P',102,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Yamani, S',103,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Yashwanth Choudhary',104,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Yeshwant Aradhya',105,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Yule, S',106,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)
--INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName],[AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES (28,'Zube, D',107,1, CAST(N'2018-04-10 16:07:23.907' AS DateTime),NULL)																																
-----------------------------------------------------------------------------------------------------------------------------

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'AOG', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'Build', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'Component Repair', N'4', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'Hospital Shop', N'5', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'On wing', N'6', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'Other', N'7', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 34, N'Strip', N'8', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 35, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 35, N'Complex', N'2', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 35, N'Non-Complex', N'3', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES ( 43, N'None', N'1', N'1', CAST(N'2018-02-15 16:07:23.907' AS DateTime), NULL)
/* DAMAGE TYPE AND Type of component */

INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Dent',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Nick',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Score',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Frettage',4,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Galling',5,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Gouge',6,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Pitting',7,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Crack',8,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Corrosion',9,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Scratch',10,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Wear',11,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Coating Loss',12,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Blister',13,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Distortion',14,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Dis-coloration',15,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Chipping',16,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Undersize',17,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Oversize',18,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Material Pick-ups',19,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Material Deposit',20,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Dis-bonding',21,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Cross-threads',22,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Missing',23,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Buldge',24,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Erosion',25,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(44,'Non-compliance to Maintenance Instructions',26,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Critical rotating',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Non-Critical rotating',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Critical S&T',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Casings',4,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Combustor',5,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Turbines',6,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Installations',7,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Externals',8,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Fans ',9,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(45,'Compressors',10,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Diameter',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Face',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Hole',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Leading Edge',4,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Trailing Edge',5,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Profile',6,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Root',7,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Radius',8,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Fir Tree',9,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Dovetail',10,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Tip',11,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Groove',12,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Slot',13,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Coating area',14,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Seal Fin',15,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Tube',16,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Pin',17,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Stud',18,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Panel',19,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Looms',20,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Liners',21,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Vanes',22,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Bush',23,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Rivet',24,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Web',25,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Splines',26,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Airfoil',27,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(46,'Curvic',28,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Mating face',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Fillet',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Pressure face',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Non-Pressure face',4,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Sealing face',5,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Outer',6,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Inner',7,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Edge',8,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Convex',9,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Concave',10,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Side face',11,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Bottom face',12,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(47,'Chamfer',13,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(48,'Check & Repair',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(48,'Not Applicable',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(48,'Overhaul',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(48,'Serviceability',4,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(48,'Performance Restoration',5,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(48,'Other',6,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(49,'Sensitive',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(49,'Classified',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(49,'UnClassified',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(49,'Critical Group A',4,1,GETDATE(),GETDATE())


INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'None',1,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Accept TV',2,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Airbus TA',3,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Aircelle TV',4,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Amend FRS',5,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'AOG TV',6,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'GKN TV',7,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Hispano Suiza TV',8,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Hospital Shop TV (Service)',9,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'IOR',10,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'New FRS',11,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Reject',12,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Reject for Info',13,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Repair TV',14,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Service TV (RMR)',15,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Service TV',16,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Shorts TV',17,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Trial TV',18,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(further info req.)',19,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(likely accept)',20,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(likely MRO Repair)',21,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(likely operator repair)',22,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(likely reject)',23,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(likely reject/replace unit)',24,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'Under inv(likely repair)',25,1,GETDATE(),GETDATE())
INSERT [Edc].[ST_TV_Register_Attribute] ([AttributeGroupId], [AttributeName], [AttributeValue], [Active], [CreateDate], [ModifiedDate]) VALUES 
(50,'UTAS TV',26,1,GETDATE(),GETDATE())
 GO

--SET IDENTITY_INSERT [Edc].[OT_TV_Drawing_Details] OFF

--INSERT INTO [Edc].[OT_TV_Drawing_Details] (FileName,PartNumber,PartDescription,IssueDate,Revision,Series,FilePath,Active,CreatedBy) 
--VALUES ('DFW45729_1.pdf','DFW45730','Blade, Stage 8 - I.P Compressor','2005-10-06 00:00:00','1','Trent1000','Trent1000',1,'2266F1F7-D846-E811-BB59-64006A64502A')
--INSERT INTO [Edc].[OT_TV_Drawing_Details] (FileName,PartNumber,PartDescription,IssueDate,Revision,Series,FilePath,Active,CreatedBy) 
--VALUES ('FW41900_B.pdf','FW41900','Instruction, fitting front acoustiuc panel','2007-12-01 00:00:00','B','Trent1000','Trent1000',1,'2266F1F7-D846-E811-BB59-64006A64502A')

--SET IDENTITY_INSERT [Edc].[OT_TV_Drawing_Details] OFF
/*----------------------------------------------wip status details-------------------------------------*/
GO
SET IDENTITY_INSERT [Report].[ST_Edc_Wip_Status_Details] ON

INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(1,'YTS','N','S1','TV Booked In (DAY 0)','TV Booked In (DAY 0)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(2,'YTS','N','S2','TV Allocated to Owner','TV Allocated to Owner','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(3,'InWork','H','S3','Under Investigation','Under Investigation','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(4,'Query','H','S4','Add info req. from Applicant. (QUERY)','Add info req. from Applicant. (QUERY)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(5,'Query','H','S5','Awaiting Replicasts (QUERY)','Awaiting Replicasts (QUERY)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(6,'RRReview','H','S6','Pack sent for specialist Assessment.','Pack sent for specialist Assessment.','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(7,'Query','H','S7','Additional info requested by the specialist. (QUERY)','Additional info requested by the specialist. (QUERY)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(8,'YTD','D','S8','Firm HU received. (DAY 5)','Firm HU received. (DAY 5)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(9,'InWork','D','S10','Under Draft.','Under Draft.','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(10,'CAReview','D','S11','Under CA review.','Under CA review.','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(11,'InWork','D','S12','Under CA correction. (INTERNAL RW)','Under CA correction. (INTERNAL RW)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(12,'RRReview','A','S13','Under Initial CVE/ PRE approval.','Under Initial CVE/ PRE approval.','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(13,'Query','D','S14','Under CVE/ PRE correction. (EXTERNAL RW)','Under CVE/ PRE correction. (EXTERNAL RW)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(14,'InWork','A','S15','CVE/PRE Approved  (DAY 10/13)','CVE/PRE Approved  (DAY 10/13)','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(15,'InWork','A','S16','Under specialist approval.','Under specialist approval.','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(16,'InWork','A','S17','Specialist Query (QUERY)','Specialist Query (QUERY)','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(17,'InWork','A','S18','Under Airworthiness approval.','Under Airworthiness approval.','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(18,'InWork','A','S19','Under Final CVE/PRE','Under Final CVE/PRE','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(19,'Close','C','S20','TV Closed (DAY 20)','TV Closed (DAY 20)','ONSITE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(20,'Reject','R','S9','TV Rejected.','TV Rejected.','OFFSHORE',1)
INSERT INTO [Report].[ST_Edc_Wip_Status_Details] (Id,StatusCategory,StatusTitle,StatusCode,[Status],StatusDescription,Location,Active)
VALUES(100,'NoStatus','NS','S100','No Status Available','No Status Available','OFFSHORE',1)

SET IDENTITY_INSERT [Report].[ST_Edc_Wip_Status_Details] OFF
GO
--/*--------------------------------Hit COunt table details----------------------------------------------*/
SET IDENTITY_INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ON 

INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [TableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (1, N'WideBodyTV', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2018-07-09 15:49:19.453' AS DateTime))
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [TableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (2, N'RegionalBodyTV', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2018-07-09 15:49:19.453' AS DateTime))
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [TableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (3, N'Drawing', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2018-07-09 15:49:19.453' AS DateTime))
SET IDENTITY_INSERT [dbo].[ST_Hit_Count_Table_Name_Details] OFF
GO
/*--------------------------------Owner Table----------------------------------------------*/
SET IDENTITY_INSERT [Edc].[ST_TV_Owner_Details] ON 

GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (1, 2004708, N' Akhil,Vijayan', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.670' AS DateTime), CAST(N'2018-07-24 11:07:46.670' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (2, 2004729, N' Amit Kumar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.677' AS DateTime), CAST(N'2018-07-24 11:07:46.677' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (3, NULL, N'Evans,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:46.680' AS DateTime), CAST(N'2018-07-24 11:07:46.680' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (4, 1018206, N' Nithin,Joseph', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.683' AS DateTime), CAST(N'2018-07-24 11:07:46.683' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (5, NULL, N'Abbott,Graham', NULL, N'0', CAST(N'2018-07-24 11:07:46.687' AS DateTime), CAST(N'2018-07-24 11:07:46.687' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (6, NULL, N'Adam,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:46.690' AS DateTime), CAST(N'2018-07-24 11:07:46.690' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (7, NULL, N'Adamson,Bill', NULL, N'0', CAST(N'2018-07-24 11:07:46.697' AS DateTime), CAST(N'2018-07-24 11:07:46.697' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (8, NULL, N'Adarsh,Joseph', NULL, N'0', CAST(N'2018-07-24 11:07:46.700' AS DateTime), CAST(N'2018-07-24 11:07:46.700' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (9, NULL, N'Adepu,swapnika', NULL, N'0', CAST(N'2018-07-24 11:07:46.703' AS DateTime), CAST(N'2018-07-24 11:07:46.703' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (10, NULL, N'Aggas,Tim', NULL, N'0', CAST(N'2018-07-24 11:07:46.720' AS DateTime), CAST(N'2018-07-24 11:07:46.720' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (11, NULL, N'Aircelle', NULL, N'0', CAST(N'2018-07-24 11:07:46.740' AS DateTime), CAST(N'2018-07-24 11:07:46.740' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (12, NULL, N'Airworthiness', NULL, N'0', CAST(N'2018-07-24 11:07:46.747' AS DateTime), CAST(N'2018-07-24 11:07:46.747' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (13, NULL, N'Akram,Mohammed', NULL, N'0', CAST(N'2018-07-24 11:07:46.760' AS DateTime), CAST(N'2018-07-24 11:07:46.760' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (14, NULL, N'Akshay, Ajit', NULL, N'0', CAST(N'2018-07-24 11:07:46.770' AS DateTime), CAST(N'2018-07-24 11:07:46.770' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (15, 1016239, N'Akshay, Iyer', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.777' AS DateTime), CAST(N'2018-07-24 11:07:46.777' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (16, NULL, N'Aldridge,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:46.780' AS DateTime), CAST(N'2018-07-24 11:07:46.780' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (17, 1003374, N'AM, Arunkumar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.783' AS DateTime), CAST(N'2018-07-24 11:07:46.783' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (18, NULL, N'Amsah,Jemal', NULL, N'0', CAST(N'2018-07-24 11:07:46.787' AS DateTime), CAST(N'2018-07-24 11:07:46.787' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (19, NULL, N'Andrew Robinson', NULL, N'0', CAST(N'2018-07-24 11:07:46.790' AS DateTime), CAST(N'2018-07-24 11:07:46.790' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (20, NULL, N'Ang,Charis', NULL, N'0', CAST(N'2018-07-24 11:07:46.797' AS DateTime), CAST(N'2018-07-24 11:07:46.797' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (21, NULL, N'Ang,Chin Soon', NULL, N'0', CAST(N'2018-07-24 11:07:46.800' AS DateTime), CAST(N'2018-07-24 11:07:46.800' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (22, 1016566, N'Anisha,Premkumar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.803' AS DateTime), CAST(N'2018-07-24 11:07:46.803' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (23, NULL, N'Anitha,N', NULL, N'0', CAST(N'2018-07-24 11:07:46.807' AS DateTime), CAST(N'2018-07-24 11:07:46.807' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (24, NULL, N'Anji PV', NULL, N'0', CAST(N'2018-07-24 11:07:46.810' AS DateTime), CAST(N'2018-07-24 11:07:46.810' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (25, 1011319, N'Ankitha,George', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:46.817' AS DateTime), CAST(N'2018-07-24 11:07:46.817' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (26, NULL, N'Ansell,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:46.820' AS DateTime), CAST(N'2018-07-24 11:07:46.820' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (27, NULL, N'Anthony,Colin', NULL, N'0', CAST(N'2018-07-24 11:07:46.823' AS DateTime), CAST(N'2018-07-24 11:07:46.823' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (28, NULL, N'Anuj,Saini', NULL, N'0', CAST(N'2018-07-24 11:07:46.827' AS DateTime), CAST(N'2018-07-24 11:07:46.827' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (29, 1011857, N'Apoorva,Jain', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.830' AS DateTime), CAST(N'2018-07-24 11:07:46.830' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (30, NULL, N'Armon,Nandan', NULL, N'0', CAST(N'2018-07-24 11:07:46.837' AS DateTime), CAST(N'2018-07-24 11:07:46.837' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (31, 1020437, N'Arote,Rohit', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:46.840' AS DateTime), CAST(N'2018-07-24 11:07:46.840' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (32, NULL, N'Arthurs,Ben', NULL, N'0', CAST(N'2018-07-24 11:07:46.843' AS DateTime), CAST(N'2018-07-24 11:07:46.843' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (33, NULL, N'AS,Balu', NULL, N'0', CAST(N'2018-07-24 11:07:46.847' AS DateTime), CAST(N'2018-07-24 11:07:46.847' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (34, NULL, N'Ashraff, Ashir', NULL, N'0', CAST(N'2018-07-24 11:07:46.850' AS DateTime), CAST(N'2018-07-24 11:07:46.850' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (35, 1015270, N'Aswanth Sreesan', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:46.857' AS DateTime), CAST(N'2018-07-24 11:07:46.857' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (36, NULL, N'Attridge,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:46.860' AS DateTime), CAST(N'2018-07-24 11:07:46.860' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (37, NULL, N'Au,Andy', NULL, N'0', CAST(N'2018-07-24 11:07:46.863' AS DateTime), CAST(N'2018-07-24 11:07:46.863' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (38, NULL, N'B,Mithun', NULL, N'0', CAST(N'2018-07-24 11:07:46.870' AS DateTime), CAST(N'2018-07-24 11:07:46.870' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (39, NULL, N'Bacon,Nigel', NULL, N'0', CAST(N'2018-07-24 11:07:46.873' AS DateTime), CAST(N'2018-07-24 11:07:46.873' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (40, 1010033, N'Bagalwadi, Ajay', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:46.877' AS DateTime), CAST(N'2018-07-24 11:07:46.877' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (41, 1020482, N'Balaramshekhar,P', NULL, N'1', CAST(N'2018-07-24 11:07:46.880' AS DateTime), CAST(N'2018-07-24 11:07:46.880' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (42, NULL, N'Balasubramanian,Saravanan', NULL, N'0', CAST(N'2018-07-24 11:07:46.883' AS DateTime), CAST(N'2018-07-24 11:07:46.883' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (43, 1009061, N'Balram,Vishruth', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.890' AS DateTime), CAST(N'2018-07-24 11:07:46.890' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (44, NULL, N'Bancroft,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:46.893' AS DateTime), CAST(N'2018-07-24 11:07:46.893' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (45, NULL, N'Barker,Peter', NULL, N'0', CAST(N'2018-07-24 11:07:46.897' AS DateTime), CAST(N'2018-07-24 11:07:46.897' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (46, NULL, N'Barkley, Rick', NULL, N'0', CAST(N'2018-07-24 11:07:46.900' AS DateTime), CAST(N'2018-07-24 11:07:46.900' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (47, NULL, N'Barnett,Joel', NULL, N'0', CAST(N'2018-07-24 11:07:46.903' AS DateTime), CAST(N'2018-07-24 11:07:46.903' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (48, NULL, N'Bee,Thomas', NULL, N'0', CAST(N'2018-07-24 11:07:46.910' AS DateTime), CAST(N'2018-07-24 11:07:46.910' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (49, NULL, N'Belfield,Scott', NULL, N'0', CAST(N'2018-07-24 11:07:46.913' AS DateTime), CAST(N'2018-07-24 11:07:46.913' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (50, NULL, N'Beula,Reno', NULL, N'0', CAST(N'2018-07-24 11:07:46.917' AS DateTime), CAST(N'2018-07-24 11:07:46.917' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (51, NULL, N'Bhan,Chandra', NULL, N'0', CAST(N'2018-07-24 11:07:46.920' AS DateTime), CAST(N'2018-07-24 11:07:46.920' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (52, NULL, N'Bhasin,Jagrit', NULL, N'0', CAST(N'2018-07-24 11:07:46.923' AS DateTime), CAST(N'2018-07-24 11:07:46.923' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (53, 1012084, N'BHEKANI,NITESH', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:46.930' AS DateTime), CAST(N'2018-07-24 11:07:46.930' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (54, NULL, N'Bibby,Tim', NULL, N'0', CAST(N'2018-07-24 11:07:46.933' AS DateTime), CAST(N'2018-07-24 11:07:46.933' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (55, NULL, N'Bilsborough,Peter', NULL, N'0', CAST(N'2018-07-24 11:07:46.937' AS DateTime), CAST(N'2018-07-24 11:07:46.937' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (56, 1002785, N'Biswas, Debajyoti', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:46.940' AS DateTime), CAST(N'2018-07-24 11:07:46.940' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (57, NULL, N'Blake,Grant', NULL, N'0', CAST(N'2018-07-24 11:07:46.943' AS DateTime), CAST(N'2018-07-24 11:07:46.943' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (58, NULL, N'Blakeley,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:46.950' AS DateTime), CAST(N'2018-07-24 11:07:46.950' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (59, NULL, N'Bondade,Amarnath', NULL, N'0', CAST(N'2018-07-24 11:07:46.953' AS DateTime), CAST(N'2018-07-24 11:07:46.953' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (60, NULL, N'Bordel,Jan', NULL, N'0', CAST(N'2018-07-24 11:07:46.957' AS DateTime), CAST(N'2018-07-24 11:07:46.957' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (61, NULL, N'Borysiak,Jez', NULL, N'0', CAST(N'2018-07-24 11:07:46.960' AS DateTime), CAST(N'2018-07-24 11:07:46.960' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (62, NULL, N'Bown,David', NULL, N'0', CAST(N'2018-07-24 11:07:46.963' AS DateTime), CAST(N'2018-07-24 11:07:46.963' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (63, NULL, N'Bradley,Robin', NULL, N'0', CAST(N'2018-07-24 11:07:46.970' AS DateTime), CAST(N'2018-07-24 11:07:46.970' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (64, NULL, N'Brambleby,Luke', NULL, N'0', CAST(N'2018-07-24 11:07:46.973' AS DateTime), CAST(N'2018-07-24 11:07:46.973' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (65, NULL, N'Brandon,Glyn', NULL, N'0', CAST(N'2018-07-24 11:07:46.977' AS DateTime), CAST(N'2018-07-24 11:07:46.977' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (66, NULL, N'Brearley,Leo', NULL, N'0', CAST(N'2018-07-24 11:07:46.980' AS DateTime), CAST(N'2018-07-24 11:07:46.980' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (67, NULL, N'Bretherton,Graham', NULL, N'0', CAST(N'2018-07-24 11:07:46.983' AS DateTime), CAST(N'2018-07-24 11:07:46.983' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (68, NULL, N'Bridges,Will', NULL, N'0', CAST(N'2018-07-24 11:07:46.990' AS DateTime), CAST(N'2018-07-24 11:07:46.990' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (69, NULL, N'Britton,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:46.993' AS DateTime), CAST(N'2018-07-24 11:07:46.993' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (70, NULL, N'Brodrick,Graham', NULL, N'0', CAST(N'2018-07-24 11:07:46.997' AS DateTime), CAST(N'2018-07-24 11:07:46.997' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (71, NULL, N'Brown,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:47.000' AS DateTime), CAST(N'2018-07-24 11:07:47.000' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (72, NULL, N'Brown,Jim', NULL, N'0', CAST(N'2018-07-24 11:07:47.003' AS DateTime), CAST(N'2018-07-24 11:07:47.003' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (73, NULL, N'Brown,Richard D', NULL, N'0', CAST(N'2018-07-24 11:07:47.010' AS DateTime), CAST(N'2018-07-24 11:07:47.010' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (74, NULL, N'Brownlee,Duncan', NULL, N'0', CAST(N'2018-07-24 11:07:47.013' AS DateTime), CAST(N'2018-07-24 11:07:47.013' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (75, NULL, N'Buerklin, Holger', NULL, N'0', CAST(N'2018-07-24 11:07:47.017' AS DateTime), CAST(N'2018-07-24 11:07:47.017' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (76, NULL, N'Bullock,Nigel', NULL, N'0', CAST(N'2018-07-24 11:07:47.020' AS DateTime), CAST(N'2018-07-24 11:07:47.020' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (77, NULL, N'Burgess,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:47.027' AS DateTime), CAST(N'2018-07-24 11:07:47.027' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (78, NULL, N'Carr,Roger', NULL, N'0', CAST(N'2018-07-24 11:07:47.030' AS DateTime), CAST(N'2018-07-24 11:07:47.030' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (79, NULL, N'Carter, Louise', NULL, N'0', CAST(N'2018-07-24 11:07:47.033' AS DateTime), CAST(N'2018-07-24 11:07:47.033' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (80, NULL, N'Cass,Chris', NULL, N'0', CAST(N'2018-07-24 11:07:47.037' AS DateTime), CAST(N'2018-07-24 11:07:47.037' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (81, NULL, N'Chakraborthy, Tushar', NULL, N'0', CAST(N'2018-07-24 11:07:47.040' AS DateTime), CAST(N'2018-07-24 11:07:47.040' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (82, 1020425, N'Chakraborty,Rajdeep', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.047' AS DateTime), CAST(N'2018-07-24 11:07:47.047' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (83, NULL, N'Chambard,Romain', NULL, N'0', CAST(N'2018-07-24 11:07:47.050' AS DateTime), CAST(N'2018-07-24 11:07:47.050' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (84, NULL, N'Chan, Ka Him', NULL, N'0', CAST(N'2018-07-24 11:07:47.053' AS DateTime), CAST(N'2018-07-24 11:07:47.053' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (85, NULL, N'Chan,Chris', NULL, N'0', CAST(N'2018-07-24 11:07:47.057' AS DateTime), CAST(N'2018-07-24 11:07:47.057' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (86, NULL, N'Chan,Louis', NULL, N'0', CAST(N'2018-07-24 11:07:47.060' AS DateTime), CAST(N'2018-07-24 11:07:47.060' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (87, NULL, N'Chan,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.063' AS DateTime), CAST(N'2018-07-24 11:07:47.063' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (88, NULL, N'Chekkera Prakash,Somaiah', NULL, N'0', CAST(N'2018-07-24 11:07:47.070' AS DateTime), CAST(N'2018-07-24 11:07:47.070' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (89, NULL, N'Cheung,Billy', NULL, N'0', CAST(N'2018-07-24 11:07:47.073' AS DateTime), CAST(N'2018-07-24 11:07:47.073' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (90, NULL, N'Chikkalingaiah,AH', NULL, N'0', CAST(N'2018-07-24 11:07:47.077' AS DateTime), CAST(N'2018-07-24 11:07:47.077' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (91, NULL, N'Chikkappa, Rangaswamy', NULL, N'0', CAST(N'2018-07-24 11:07:47.080' AS DateTime), CAST(N'2018-07-24 11:07:47.080' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (92, 1003725, N'Choudhury,Joy', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.087' AS DateTime), CAST(N'2018-07-24 11:07:47.087' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (93, NULL, N'Christmas 1', NULL, N'0', CAST(N'2018-07-24 11:07:47.090' AS DateTime), CAST(N'2018-07-24 11:07:47.090' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (94, NULL, N'Christmas 10', NULL, N'0', CAST(N'2018-07-24 11:07:47.093' AS DateTime), CAST(N'2018-07-24 11:07:47.093' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (95, NULL, N'Christmas 11', NULL, N'0', CAST(N'2018-07-24 11:07:47.097' AS DateTime), CAST(N'2018-07-24 11:07:47.097' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (96, NULL, N'Christmas 12', NULL, N'0', CAST(N'2018-07-24 11:07:47.100' AS DateTime), CAST(N'2018-07-24 11:07:47.100' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (97, NULL, N'Christmas 2', NULL, N'0', CAST(N'2018-07-24 11:07:47.107' AS DateTime), CAST(N'2018-07-24 11:07:47.107' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (98, NULL, N'Christmas 3', NULL, N'0', CAST(N'2018-07-24 11:07:47.110' AS DateTime), CAST(N'2018-07-24 11:07:47.110' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (99, NULL, N'Christmas 4', NULL, N'0', CAST(N'2018-07-24 11:07:47.113' AS DateTime), CAST(N'2018-07-24 11:07:47.113' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (100, NULL, N'Christmas 5', NULL, N'0', CAST(N'2018-07-24 11:07:47.117' AS DateTime), CAST(N'2018-07-24 11:07:47.117' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (101, NULL, N'Christmas 6', NULL, N'0', CAST(N'2018-07-24 11:07:47.120' AS DateTime), CAST(N'2018-07-24 11:07:47.120' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (102, NULL, N'Christmas 7', NULL, N'0', CAST(N'2018-07-24 11:07:47.127' AS DateTime), CAST(N'2018-07-24 11:07:47.127' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (103, NULL, N'Christmas 8', NULL, N'0', CAST(N'2018-07-24 11:07:47.130' AS DateTime), CAST(N'2018-07-24 11:07:47.130' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (104, NULL, N'Christmas 9', NULL, N'0', CAST(N'2018-07-24 11:07:47.133' AS DateTime), CAST(N'2018-07-24 11:07:47.133' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (105, NULL, N'Christmas Held', NULL, N'0', CAST(N'2018-07-24 11:07:47.137' AS DateTime), CAST(N'2018-07-24 11:07:47.137' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (106, NULL, N'CHU,S.L. Chris', NULL, N'0', CAST(N'2018-07-24 11:07:47.140' AS DateTime), CAST(N'2018-07-24 11:07:47.140' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (107, NULL, N'Chua, Hui Peng', NULL, N'0', CAST(N'2018-07-24 11:07:47.147' AS DateTime), CAST(N'2018-07-24 11:07:47.147' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (108, NULL, N'Chung,Katherine', NULL, N'0', CAST(N'2018-07-24 11:07:47.150' AS DateTime), CAST(N'2018-07-24 11:07:47.150' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (109, NULL, N'Chuter,Allan', NULL, N'0', CAST(N'2018-07-24 11:07:47.153' AS DateTime), CAST(N'2018-07-24 11:07:47.153' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (110, NULL, N'Clarke,Jack', NULL, N'0', CAST(N'2018-07-24 11:07:47.157' AS DateTime), CAST(N'2018-07-24 11:07:47.157' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (111, NULL, N'Clarke,Tim', NULL, N'0', CAST(N'2018-07-24 11:07:47.160' AS DateTime), CAST(N'2018-07-24 11:07:47.160' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (112, NULL, N'Clerigo,Mikel', NULL, N'0', CAST(N'2018-07-24 11:07:47.167' AS DateTime), CAST(N'2018-07-24 11:07:47.167' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (113, NULL, N'Connolly, Becky', NULL, N'0', CAST(N'2018-07-24 11:07:47.170' AS DateTime), CAST(N'2018-07-24 11:07:47.170' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (114, NULL, N'Conroy,Philip', NULL, N'0', CAST(N'2018-07-24 11:07:47.173' AS DateTime), CAST(N'2018-07-24 11:07:47.173' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (115, NULL, N'Crane,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:47.177' AS DateTime), CAST(N'2018-07-24 11:07:47.177' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (116, NULL, N'Crawford,Brenda', NULL, N'0', CAST(N'2018-07-24 11:07:47.180' AS DateTime), CAST(N'2018-07-24 11:07:47.180' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (117, NULL, N'Cripps,Nick', NULL, N'0', CAST(N'2018-07-24 11:07:47.187' AS DateTime), CAST(N'2018-07-24 11:07:47.187' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (118, NULL, N'Da Costa,Felton', NULL, N'0', CAST(N'2018-07-24 11:07:47.190' AS DateTime), CAST(N'2018-07-24 11:07:47.190' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (119, NULL, N'Davis, Ben', NULL, N'0', CAST(N'2018-07-24 11:07:47.193' AS DateTime), CAST(N'2018-07-24 11:07:47.193' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (120, NULL, N'Deb,Gaurav', NULL, N'0', CAST(N'2018-07-24 11:07:47.197' AS DateTime), CAST(N'2018-07-24 11:07:47.197' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (121, NULL, N'Deley,Scott', NULL, N'0', CAST(N'2018-07-24 11:07:47.200' AS DateTime), CAST(N'2018-07-24 11:07:47.200' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (122, NULL, N'Desai, Shirish', NULL, N'0', CAST(N'2018-07-24 11:07:47.207' AS DateTime), CAST(N'2018-07-24 11:07:47.207' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (123, NULL, N'Devine,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:47.210' AS DateTime), CAST(N'2018-07-24 11:07:47.210' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (124, NULL, N'Dinesh, Babu', NULL, N'0', CAST(N'2018-07-24 11:07:47.213' AS DateTime), CAST(N'2018-07-24 11:07:47.213' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (125, NULL, N'Divye,Singh', NULL, N'0', CAST(N'2018-07-24 11:07:47.217' AS DateTime), CAST(N'2018-07-24 11:07:47.217' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (126, 1010730, N'Dominic,Philip', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:47.220' AS DateTime), CAST(N'2018-07-24 11:07:47.220' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (127, NULL, N'Douglas,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:47.227' AS DateTime), CAST(N'2018-07-24 11:07:47.227' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (128, NULL, N'Doyle,Daniel', NULL, N'0', CAST(N'2018-07-24 11:07:47.230' AS DateTime), CAST(N'2018-07-24 11:07:47.230' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (129, NULL, N'Draper,Mike', NULL, N'0', CAST(N'2018-07-24 11:07:47.233' AS DateTime), CAST(N'2018-07-24 11:07:47.233' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (130, NULL, N'Drinkall,Daniel', NULL, N'0', CAST(N'2018-07-24 11:07:47.237' AS DateTime), CAST(N'2018-07-24 11:07:47.237' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (131, NULL, N'Duman,Shanawaaz', NULL, N'0', CAST(N'2018-07-24 11:07:47.240' AS DateTime), CAST(N'2018-07-24 11:07:47.240' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (132, NULL, N'Engineer,Uttung', NULL, N'0', CAST(N'2018-07-24 11:07:47.247' AS DateTime), CAST(N'2018-07-24 11:07:47.247' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (133, NULL, N'Erwis,Mohammad', NULL, N'0', CAST(N'2018-07-24 11:07:47.250' AS DateTime), CAST(N'2018-07-24 11:07:47.250' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (134, NULL, N'Evans,Jamie', NULL, N'0', CAST(N'2018-07-24 11:07:47.253' AS DateTime), CAST(N'2018-07-24 11:07:47.253' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (135, NULL, N'Fearn,Simon', NULL, N'0', CAST(N'2018-07-24 11:07:47.257' AS DateTime), CAST(N'2018-07-24 11:07:47.257' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (136, NULL, N'Feliciano,Ben', NULL, N'0', CAST(N'2018-07-24 11:07:47.260' AS DateTime), CAST(N'2018-07-24 11:07:47.260' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (137, NULL, N'Ferguson,Neil', NULL, N'0', CAST(N'2018-07-24 11:07:47.267' AS DateTime), CAST(N'2018-07-24 11:07:47.267' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (138, NULL, N'Findlay,Nick', NULL, N'0', CAST(N'2018-07-24 11:07:47.270' AS DateTime), CAST(N'2018-07-24 11:07:47.270' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (139, NULL, N'Fitzpatrick,Gerard', NULL, N'0', CAST(N'2018-07-24 11:07:47.273' AS DateTime), CAST(N'2018-07-24 11:07:47.273' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (140, NULL, N'Flagstadt,Joseph', NULL, N'0', CAST(N'2018-07-24 11:07:47.277' AS DateTime), CAST(N'2018-07-24 11:07:47.277' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (141, NULL, N'Flello,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.280' AS DateTime), CAST(N'2018-07-24 11:07:47.280' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (142, NULL, N'Flint,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.287' AS DateTime), CAST(N'2018-07-24 11:07:47.287' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (143, NULL, N'Foo,Lewis', NULL, N'0', CAST(N'2018-07-24 11:07:47.290' AS DateTime), CAST(N'2018-07-24 11:07:47.290' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (144, NULL, N'Francis,Christy', NULL, N'0', CAST(N'2018-07-24 11:07:47.293' AS DateTime), CAST(N'2018-07-24 11:07:47.293' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (145, NULL, N'Gamage,Amila', NULL, N'0', CAST(N'2018-07-24 11:07:47.297' AS DateTime), CAST(N'2018-07-24 11:07:47.297' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (146, NULL, N'Gan,Benjamin', NULL, N'0', CAST(N'2018-07-24 11:07:47.300' AS DateTime), CAST(N'2018-07-24 11:07:47.300' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (147, NULL, N'Garishma', NULL, N'0', CAST(N'2018-07-24 11:07:47.307' AS DateTime), CAST(N'2018-07-24 11:07:47.307' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (148, 1006083, N'Geevarghese, Bobby', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:47.310' AS DateTime), CAST(N'2018-07-24 11:07:47.310' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (149, NULL, N'Gilchrist,Alastair', NULL, N'0', CAST(N'2018-07-24 11:07:47.313' AS DateTime), CAST(N'2018-07-24 11:07:47.313' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (150, NULL, N'GKN', NULL, N'0', CAST(N'2018-07-24 11:07:47.317' AS DateTime), CAST(N'2018-07-24 11:07:47.317' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (151, NULL, N'Glover,Stephen', NULL, N'0', CAST(N'2018-07-24 11:07:47.320' AS DateTime), CAST(N'2018-07-24 11:07:47.320' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (152, NULL, N'Gokul K', NULL, N'0', CAST(N'2018-07-24 11:07:47.327' AS DateTime), CAST(N'2018-07-24 11:07:47.327' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (153, NULL, N'Goold,Kerry', NULL, N'0', CAST(N'2018-07-24 11:07:47.330' AS DateTime), CAST(N'2018-07-24 11:07:47.330' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (154, NULL, N'Govindhan,Shanmugam', NULL, N'0', CAST(N'2018-07-24 11:07:47.333' AS DateTime), CAST(N'2018-07-24 11:07:47.333' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (155, NULL, N'Gozzard,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:47.337' AS DateTime), CAST(N'2018-07-24 11:07:47.337' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (156, NULL, N'Grassby,Tony', NULL, N'0', CAST(N'2018-07-24 11:07:47.340' AS DateTime), CAST(N'2018-07-24 11:07:47.340' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (157, NULL, N'Green,Dan', NULL, N'0', CAST(N'2018-07-24 11:07:47.347' AS DateTime), CAST(N'2018-07-24 11:07:47.347' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (158, 1017777, N'Guru,Mahadev', NULL, N'1', CAST(N'2018-07-24 11:07:47.350' AS DateTime), CAST(N'2018-07-24 11:07:47.350' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (159, NULL, N'Haber,Ben', NULL, N'0', CAST(N'2018-07-24 11:07:47.353' AS DateTime), CAST(N'2018-07-24 11:07:47.353' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (160, NULL, N'Halloway,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:47.357' AS DateTime), CAST(N'2018-07-24 11:07:47.357' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (161, NULL, N'Hammond,Stewart', NULL, N'0', CAST(N'2018-07-24 11:07:47.360' AS DateTime), CAST(N'2018-07-24 11:07:47.360' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (162, NULL, N'Hardy,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:47.367' AS DateTime), CAST(N'2018-07-24 11:07:47.367' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (163, 1016955, N'Harish Gr', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.370' AS DateTime), CAST(N'2018-07-24 11:07:47.370' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (164, NULL, N'Harrop,Nick', NULL, N'0', CAST(N'2018-07-24 11:07:47.373' AS DateTime), CAST(N'2018-07-24 11:07:47.373' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (165, NULL, N'Harvey,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.377' AS DateTime), CAST(N'2018-07-24 11:07:47.377' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (166, NULL, N'Haslam,Ash', NULL, N'0', CAST(N'2018-07-24 11:07:47.380' AS DateTime), CAST(N'2018-07-24 11:07:47.380' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (167, NULL, N'Heath,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:47.387' AS DateTime), CAST(N'2018-07-24 11:07:47.387' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (168, NULL, N'Hendry,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:47.390' AS DateTime), CAST(N'2018-07-24 11:07:47.390' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (169, NULL, N'Henry,Carlo', NULL, N'0', CAST(N'2018-07-24 11:07:47.393' AS DateTime), CAST(N'2018-07-24 11:07:47.393' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (170, NULL, N'Hesling,Graham', NULL, N'0', CAST(N'2018-07-24 11:07:47.397' AS DateTime), CAST(N'2018-07-24 11:07:47.397' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (171, NULL, N'Hogg,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:47.400' AS DateTime), CAST(N'2018-07-24 11:07:47.400' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (172, NULL, N'Holness,Dennis', NULL, N'0', CAST(N'2018-07-24 11:07:47.410' AS DateTime), CAST(N'2018-07-24 11:07:47.410' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (173, NULL, N'Hood, Matthew', NULL, N'0', CAST(N'2018-07-24 11:07:47.413' AS DateTime), CAST(N'2018-07-24 11:07:47.413' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (174, NULL, N'Hopkins,Noel', NULL, N'0', CAST(N'2018-07-24 11:07:47.417' AS DateTime), CAST(N'2018-07-24 11:07:47.417' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (175, NULL, N'Hora, Joel', NULL, N'0', CAST(N'2018-07-24 11:07:47.420' AS DateTime), CAST(N'2018-07-24 11:07:47.420' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (176, NULL, N'House,Rachel', NULL, N'0', CAST(N'2018-07-24 11:07:47.427' AS DateTime), CAST(N'2018-07-24 11:07:47.427' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (177, NULL, N'Howard,Marie', NULL, N'0', CAST(N'2018-07-24 11:07:47.430' AS DateTime), CAST(N'2018-07-24 11:07:47.430' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (178, NULL, N'Howard,Scott', NULL, N'0', CAST(N'2018-07-24 11:07:47.433' AS DateTime), CAST(N'2018-07-24 11:07:47.433' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (179, NULL, N'Hughes,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:47.437' AS DateTime), CAST(N'2018-07-24 11:07:47.437' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (180, NULL, N'Hughes,Richard', NULL, N'0', CAST(N'2018-07-24 11:07:47.440' AS DateTime), CAST(N'2018-07-24 11:07:47.440' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (181, NULL, N'Hunter,Rob', NULL, N'0', CAST(N'2018-07-24 11:07:47.447' AS DateTime), CAST(N'2018-07-24 11:07:47.447' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (182, 2004493, N'Immanuel B', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.450' AS DateTime), CAST(N'2018-07-24 11:07:47.450' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (183, 1012081, N'Inamdar,Ruta', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.453' AS DateTime), CAST(N'2018-07-24 11:07:47.453' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (184, NULL, N'Irving,Stephen', NULL, N'0', CAST(N'2018-07-24 11:07:47.457' AS DateTime), CAST(N'2018-07-24 11:07:47.457' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (185, NULL, N'J,Ananthkumar', NULL, N'0', CAST(N'2018-07-24 11:07:47.460' AS DateTime), CAST(N'2018-07-24 11:07:47.460' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (186, NULL, N'J,Rajasekar', NULL, N'0', CAST(N'2018-07-24 11:07:47.467' AS DateTime), CAST(N'2018-07-24 11:07:47.467' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (187, NULL, N'Jackson,Tom', NULL, N'0', CAST(N'2018-07-24 11:07:47.470' AS DateTime), CAST(N'2018-07-24 11:07:47.470' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (188, NULL, N'Jafar,Habshee', NULL, N'0', CAST(N'2018-07-24 11:07:47.473' AS DateTime), CAST(N'2018-07-24 11:07:47.473' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (189, NULL, N'James, Nick', NULL, N'0', CAST(N'2018-07-24 11:07:47.477' AS DateTime), CAST(N'2018-07-24 11:07:47.477' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (190, 1002768, N'Jatin,Sachdeva', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.480' AS DateTime), CAST(N'2018-07-24 11:07:47.480' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (191, NULL, N'Jenkins,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:47.487' AS DateTime), CAST(N'2018-07-24 11:07:47.487' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (192, NULL, N'Jennings,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.490' AS DateTime), CAST(N'2018-07-24 11:07:47.490' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (193, NULL, N'Jez Borysiak', NULL, N'0', CAST(N'2018-07-24 11:07:47.493' AS DateTime), CAST(N'2018-07-24 11:07:47.493' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (194, 1001697, N'Jha,Gajendra', N'Current User at Onsite', N'0', CAST(N'2018-07-24 11:07:47.497' AS DateTime), CAST(N'2018-07-24 11:07:47.497' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (195, NULL, N'Jha,Nilesh', NULL, N'0', CAST(N'2018-07-24 11:07:47.500' AS DateTime), CAST(N'2018-07-24 11:07:47.500' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (196, 1006152, N'Jith Joseph Kallupurackal', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:47.507' AS DateTime), CAST(N'2018-07-24 11:07:47.507' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (197, NULL, N'Joerg,Christophe', NULL, N'0', CAST(N'2018-07-24 11:07:47.520' AS DateTime), CAST(N'2018-07-24 11:07:47.520' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (198, NULL, N'Johnson, Andy ', NULL, N'0', CAST(N'2018-07-24 11:07:47.537' AS DateTime), CAST(N'2018-07-24 11:07:47.537' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (199, NULL, N'Johnson,Dominic', NULL, N'0', CAST(N'2018-07-24 11:07:47.570' AS DateTime), CAST(N'2018-07-24 11:07:47.570' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (200, NULL, N'Jones,Ffion', NULL, N'0', CAST(N'2018-07-24 11:07:47.580' AS DateTime), CAST(N'2018-07-24 11:07:47.580' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (201, 1010882, N'Joseph,John', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.587' AS DateTime), CAST(N'2018-07-24 11:07:47.587' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (202, 1006000, N'Jyotsana,Sharma', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.590' AS DateTime), CAST(N'2018-07-24 11:07:47.590' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (203, NULL, N'K Goold, G Turner', NULL, N'0', CAST(N'2018-07-24 11:07:47.593' AS DateTime), CAST(N'2018-07-24 11:07:47.593' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (204, NULL, N'Kallannavar,Vinayak', NULL, N'0', CAST(N'2018-07-24 11:07:47.597' AS DateTime), CAST(N'2018-07-24 11:07:47.597' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (205, 1003738, N'Kamalakannan, S', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.600' AS DateTime), CAST(N'2018-07-24 11:07:47.600' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (206, NULL, N'Kandulna,Royan', NULL, N'0', CAST(N'2018-07-24 11:07:47.607' AS DateTime), CAST(N'2018-07-24 11:07:47.607' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (207, NULL, N'Kannan,Malar', NULL, N'0', CAST(N'2018-07-24 11:07:47.610' AS DateTime), CAST(N'2018-07-24 11:07:47.610' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (208, NULL, N'Kapusta,Oleg', NULL, N'0', CAST(N'2018-07-24 11:07:47.613' AS DateTime), CAST(N'2018-07-24 11:07:47.613' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (209, NULL, N'Karmakar,Pinak', NULL, N'0', CAST(N'2018-07-24 11:07:47.617' AS DateTime), CAST(N'2018-07-24 11:07:47.617' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (210, NULL, N'karthik A', NULL, N'0', CAST(N'2018-07-24 11:07:47.620' AS DateTime), CAST(N'2018-07-24 11:07:47.620' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (211, NULL, N'Kartik, Angalagi', NULL, N'0', CAST(N'2018-07-24 11:07:47.627' AS DateTime), CAST(N'2018-07-24 11:07:47.627' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (212, NULL, N'Kaur,Prabh', NULL, N'0', CAST(N'2018-07-24 11:07:47.630' AS DateTime), CAST(N'2018-07-24 11:07:47.630' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (213, NULL, N'Kavya, Gangadhar', NULL, N'0', CAST(N'2018-07-24 11:07:47.633' AS DateTime), CAST(N'2018-07-24 11:07:47.633' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (214, 1002743, N'Kaza,Durgaprasad', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.637' AS DateTime), CAST(N'2018-07-24 11:07:47.637' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (215, NULL, N'Kebell,Dan', NULL, N'0', CAST(N'2018-07-24 11:07:47.640' AS DateTime), CAST(N'2018-07-24 11:07:47.640' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (216, NULL, N'Keogh,Myles', NULL, N'0', CAST(N'2018-07-24 11:07:47.647' AS DateTime), CAST(N'2018-07-24 11:07:47.647' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (217, NULL, N'Kerry,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.650' AS DateTime), CAST(N'2018-07-24 11:07:47.650' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (218, NULL, N'Khan,Qumar', NULL, N'0', CAST(N'2018-07-24 11:07:47.653' AS DateTime), CAST(N'2018-07-24 11:07:47.653' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (219, NULL, N'Khoo,Yi Wen', NULL, N'0', CAST(N'2018-07-24 11:07:47.657' AS DateTime), CAST(N'2018-07-24 11:07:47.657' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (220, NULL, N'Kimbley,Jeremy', NULL, N'0', CAST(N'2018-07-24 11:07:47.660' AS DateTime), CAST(N'2018-07-24 11:07:47.660' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (221, 1016563, N'Kiran,Bellad', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:47.667' AS DateTime), CAST(N'2018-07-24 11:07:47.667' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (222, 1015089, N'KM,Arshad', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:47.670' AS DateTime), CAST(N'2018-07-24 11:07:47.670' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (223, NULL, N'Kourentzis,Evangelos', NULL, N'0', CAST(N'2018-07-24 11:07:47.673' AS DateTime), CAST(N'2018-07-24 11:07:47.673' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (224, NULL, N'Krause,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:47.677' AS DateTime), CAST(N'2018-07-24 11:07:47.677' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (225, NULL, N'Krishna,Sanjan', NULL, N'0', CAST(N'2018-07-24 11:07:47.680' AS DateTime), CAST(N'2018-07-24 11:07:47.680' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (226, NULL, N'Krishnamaneni, Kishore', NULL, N'0', CAST(N'2018-07-24 11:07:47.687' AS DateTime), CAST(N'2018-07-24 11:07:47.687' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (227, NULL, N'Kumar, Anil', NULL, N'0', CAST(N'2018-07-24 11:07:47.690' AS DateTime), CAST(N'2018-07-24 11:07:47.690' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (228, NULL, N'Kumar,Arun', NULL, N'0', CAST(N'2018-07-24 11:07:47.693' AS DateTime), CAST(N'2018-07-24 11:07:47.693' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (229, NULL, N'Kumar,Arun.V.U', NULL, N'0', CAST(N'2018-07-24 11:07:47.697' AS DateTime), CAST(N'2018-07-24 11:07:47.697' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (230, 1018492, N'Kumar,Krishna', NULL, N'1', CAST(N'2018-07-24 11:07:47.700' AS DateTime), CAST(N'2018-07-24 11:07:47.700' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (231, NULL, N'Kumar,Mithan', NULL, N'0', CAST(N'2018-07-24 11:07:47.707' AS DateTime), CAST(N'2018-07-24 11:07:47.707' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (232, 1008502, N'Kumar,Pavan', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:47.710' AS DateTime), CAST(N'2018-07-24 11:07:47.710' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (233, NULL, N'Kumar,Prasanna', NULL, N'0', CAST(N'2018-07-24 11:07:47.713' AS DateTime), CAST(N'2018-07-24 11:07:47.713' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (234, 1020339, N'Kumar,Rajesh', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.717' AS DateTime), CAST(N'2018-07-24 11:07:47.717' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (235, 1001534, N'Kumar,Ravindra', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.720' AS DateTime), CAST(N'2018-07-24 11:07:47.720' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (236, NULL, N'Kumar,Saravana', NULL, N'0', CAST(N'2018-07-24 11:07:47.727' AS DateTime), CAST(N'2018-07-24 11:07:47.727' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (237, NULL, N'Kumar,Sathish', NULL, N'0', CAST(N'2018-07-24 11:07:47.730' AS DateTime), CAST(N'2018-07-24 11:07:47.730' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (238, NULL, N'Kumar,Vaibhav', NULL, N'0', CAST(N'2018-07-24 11:07:47.733' AS DateTime), CAST(N'2018-07-24 11:07:47.733' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (239, 1001476, N'Kumar,Veera', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.737' AS DateTime), CAST(N'2018-07-24 11:07:47.737' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (240, 1018518, N'Kumar,Vipul', NULL, N'1', CAST(N'2018-07-24 11:07:47.740' AS DateTime), CAST(N'2018-07-24 11:07:47.740' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (241, 1001971, N'Kumara,Swamy', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.747' AS DateTime), CAST(N'2018-07-24 11:07:47.747' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (242, 1009780, N'Kushwaha,Rounak', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.750' AS DateTime), CAST(N'2018-07-24 11:07:47.750' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (243, NULL, N'Laffan,Jeremy', NULL, N'0', CAST(N'2018-07-24 11:07:47.753' AS DateTime), CAST(N'2018-07-24 11:07:47.753' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (244, NULL, N'Lafrenais,Christopher', NULL, N'0', CAST(N'2018-07-24 11:07:47.757' AS DateTime), CAST(N'2018-07-24 11:07:47.757' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (245, NULL, N'Lam,Nhuong', NULL, N'0', CAST(N'2018-07-24 11:07:47.760' AS DateTime), CAST(N'2018-07-24 11:07:47.760' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (246, NULL, N'Lancaster, Nigel', NULL, N'0', CAST(N'2018-07-24 11:07:47.767' AS DateTime), CAST(N'2018-07-24 11:07:47.767' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (247, NULL, N'Laughlin,Eric', NULL, N'0', CAST(N'2018-07-24 11:07:47.770' AS DateTime), CAST(N'2018-07-24 11:07:47.770' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (248, NULL, N'Lavery,Tony', NULL, N'0', CAST(N'2018-07-24 11:07:47.773' AS DateTime), CAST(N'2018-07-24 11:07:47.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (249, NULL, N'Lawer,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:47.777' AS DateTime), CAST(N'2018-07-24 11:07:47.777' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (250, NULL, N'Le Mesurier,Neil', NULL, N'0', CAST(N'2018-07-24 11:07:47.780' AS DateTime), CAST(N'2018-07-24 11:07:47.780' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (251, NULL, N'Leadbeater,Marie', NULL, N'0', CAST(N'2018-07-24 11:07:47.787' AS DateTime), CAST(N'2018-07-24 11:07:47.787' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (252, NULL, N'Lee,Chee Chai', NULL, N'0', CAST(N'2018-07-24 11:07:47.790' AS DateTime), CAST(N'2018-07-24 11:07:47.790' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (253, NULL, N'Lee,Feiwen', NULL, N'0', CAST(N'2018-07-24 11:07:47.793' AS DateTime), CAST(N'2018-07-24 11:07:47.793' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (254, NULL, N'Lee,Henry(HAESL)', NULL, N'0', CAST(N'2018-07-24 11:07:47.797' AS DateTime), CAST(N'2018-07-24 11:07:47.797' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (255, NULL, N'Lee,Jonathan', NULL, N'0', CAST(N'2018-07-24 11:07:47.800' AS DateTime), CAST(N'2018-07-24 11:07:47.800' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (256, NULL, N'Lee,Mildred', NULL, N'0', CAST(N'2018-07-24 11:07:47.807' AS DateTime), CAST(N'2018-07-24 11:07:47.807' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (257, NULL, N'Lee,Vincent', NULL, N'0', CAST(N'2018-07-24 11:07:47.810' AS DateTime), CAST(N'2018-07-24 11:07:47.810' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (258, NULL, N'Lemar,Tim', NULL, N'0', CAST(N'2018-07-24 11:07:47.813' AS DateTime), CAST(N'2018-07-24 11:07:47.813' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (259, NULL, N'Leo,Gabriel', NULL, N'0', CAST(N'2018-07-24 11:07:47.817' AS DateTime), CAST(N'2018-07-24 11:07:47.817' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (260, NULL, N'Leung,Jason', NULL, N'0', CAST(N'2018-07-24 11:07:47.820' AS DateTime), CAST(N'2018-07-24 11:07:47.820' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (261, NULL, N'Lim,Kendrick', NULL, N'0', CAST(N'2018-07-24 11:07:47.827' AS DateTime), CAST(N'2018-07-24 11:07:47.827' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (262, NULL, N'Lim,Sherilyn', NULL, N'0', CAST(N'2018-07-24 11:07:47.830' AS DateTime), CAST(N'2018-07-24 11:07:47.830' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (263, NULL, N'Ling,Thomas', NULL, N'0', CAST(N'2018-07-24 11:07:47.833' AS DateTime), CAST(N'2018-07-24 11:07:47.833' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (264, NULL, N'Lloyd,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:47.837' AS DateTime), CAST(N'2018-07-24 11:07:47.837' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (265, NULL, N'Lo,Carmel', NULL, N'0', CAST(N'2018-07-24 11:07:47.840' AS DateTime), CAST(N'2018-07-24 11:07:47.840' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (266, NULL, N'Lo,Henry', NULL, N'0', CAST(N'2018-07-24 11:07:47.847' AS DateTime), CAST(N'2018-07-24 11:07:47.847' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (267, NULL, N'Lo,Tom', NULL, N'0', CAST(N'2018-07-24 11:07:47.850' AS DateTime), CAST(N'2018-07-24 11:07:47.850' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (268, NULL, N'Loh,Xun Yong', NULL, N'0', CAST(N'2018-07-24 11:07:47.853' AS DateTime), CAST(N'2018-07-24 11:07:47.853' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (269, NULL, N'Lokesh C', NULL, N'0', CAST(N'2018-07-24 11:07:47.857' AS DateTime), CAST(N'2018-07-24 11:07:47.857' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (270, NULL, N'Loveridge,Lance', NULL, N'0', CAST(N'2018-07-24 11:07:47.860' AS DateTime), CAST(N'2018-07-24 11:07:47.860' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (271, NULL, N'Lovering,Grant', NULL, N'0', CAST(N'2018-07-24 11:07:47.867' AS DateTime), CAST(N'2018-07-24 11:07:47.867' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (272, NULL, N'Lower,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:47.870' AS DateTime), CAST(N'2018-07-24 11:07:47.870' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (273, NULL, N'Lu,Alvan', NULL, N'0', CAST(N'2018-07-24 11:07:47.873' AS DateTime), CAST(N'2018-07-24 11:07:47.873' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (274, 1008072, N'M, Gopikrishnan', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.877' AS DateTime), CAST(N'2018-07-24 11:07:47.877' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (275, NULL, N'M,Dhamodharan', NULL, N'0', CAST(N'2018-07-24 11:07:47.880' AS DateTime), CAST(N'2018-07-24 11:07:47.880' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (276, NULL, N'M,Shyamili', NULL, N'0', CAST(N'2018-07-24 11:07:47.887' AS DateTime), CAST(N'2018-07-24 11:07:47.887' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (277, 1002479, N'm1,rajesh ', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:47.890' AS DateTime), CAST(N'2018-07-24 11:07:47.890' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (278, NULL, N'Maddock,Debbie', NULL, N'0', CAST(N'2018-07-24 11:07:47.893' AS DateTime), CAST(N'2018-07-24 11:07:47.893' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (279, 1016203, N'Mahantesh, Mirji', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:47.897' AS DateTime), CAST(N'2018-07-24 11:07:47.897' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (280, NULL, N'Mahesh, Ashok', NULL, N'0', CAST(N'2018-07-24 11:07:47.900' AS DateTime), CAST(N'2018-07-24 11:07:47.900' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (281, NULL, N'Manj,Nagaraj', NULL, N'0', CAST(N'2018-07-24 11:07:47.907' AS DateTime), CAST(N'2018-07-24 11:07:47.907' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (282, NULL, N'Manjunatha H', NULL, N'0', CAST(N'2018-07-24 11:07:47.910' AS DateTime), CAST(N'2018-07-24 11:07:47.910' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (283, NULL, N'Manning,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:47.913' AS DateTime), CAST(N'2018-07-24 11:07:47.913' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (284, NULL, N'Manoranjan,R', NULL, N'0', CAST(N'2018-07-24 11:07:47.917' AS DateTime), CAST(N'2018-07-24 11:07:47.917' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (285, NULL, N'Margaret,Lumina', NULL, N'0', CAST(N'2018-07-24 11:07:47.920' AS DateTime), CAST(N'2018-07-24 11:07:47.920' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (286, NULL, N'Marshall,Richie', NULL, N'0', CAST(N'2018-07-24 11:07:47.927' AS DateTime), CAST(N'2018-07-24 11:07:47.927' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (287, NULL, N'Martin, Paul (N3EOS)', NULL, N'0', CAST(N'2018-07-24 11:07:47.930' AS DateTime), CAST(N'2018-07-24 11:07:47.930' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (288, NULL, N'Martin,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:47.933' AS DateTime), CAST(N'2018-07-24 11:07:47.933' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (289, NULL, N'Martin,Trevor', NULL, N'0', CAST(N'2018-07-24 11:07:47.937' AS DateTime), CAST(N'2018-07-24 11:07:47.937' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (290, NULL, N'Martindate,Graham', NULL, N'0', CAST(N'2018-07-24 11:07:47.940' AS DateTime), CAST(N'2018-07-24 11:07:47.940' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (291, NULL, N'Maruche, Sunil', NULL, N'0', CAST(N'2018-07-24 11:07:47.947' AS DateTime), CAST(N'2018-07-24 11:07:47.947' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (292, NULL, N'Marx, Thomas', NULL, N'0', CAST(N'2018-07-24 11:07:47.950' AS DateTime), CAST(N'2018-07-24 11:07:47.950' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (293, NULL, N'Mawbey,Chris', NULL, N'0', CAST(N'2018-07-24 11:07:47.953' AS DateTime), CAST(N'2018-07-24 11:07:47.953' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (294, NULL, N'McCulloch, Matt', NULL, N'0', CAST(N'2018-07-24 11:07:47.957' AS DateTime), CAST(N'2018-07-24 11:07:47.957' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (295, NULL, N'McEwan,Stewart', NULL, N'0', CAST(N'2018-07-24 11:07:47.960' AS DateTime), CAST(N'2018-07-24 11:07:47.960' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (296, NULL, N'McGrath,Damien', NULL, N'0', CAST(N'2018-07-24 11:07:47.967' AS DateTime), CAST(N'2018-07-24 11:07:47.967' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (297, NULL, N'McGuinness,Rachel', NULL, N'0', CAST(N'2018-07-24 11:07:47.970' AS DateTime), CAST(N'2018-07-24 11:07:47.970' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (298, NULL, N'McIntyre,Connor', NULL, N'0', CAST(N'2018-07-24 11:07:47.973' AS DateTime), CAST(N'2018-07-24 11:07:47.973' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (299, NULL, N'Meeke,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:47.977' AS DateTime), CAST(N'2018-07-24 11:07:47.977' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (300, NULL, N'Meeniga,Bharath', NULL, N'0', CAST(N'2018-07-24 11:07:47.980' AS DateTime), CAST(N'2018-07-24 11:07:47.980' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (301, NULL, N'Meletlidis, Polichronis', NULL, N'0', CAST(N'2018-07-24 11:07:47.987' AS DateTime), CAST(N'2018-07-24 11:07:47.987' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (302, NULL, N'Merchant, Asiya', NULL, N'0', CAST(N'2018-07-24 11:07:47.990' AS DateTime), CAST(N'2018-07-24 11:07:47.990' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (303, NULL, N'Merriman,Nick', NULL, N'0', CAST(N'2018-07-24 11:07:47.993' AS DateTime), CAST(N'2018-07-24 11:07:47.993' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (304, NULL, N'Milburn,Gordon', NULL, N'0', CAST(N'2018-07-24 11:07:47.997' AS DateTime), CAST(N'2018-07-24 11:07:47.997' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (305, NULL, N'Misra,Santanu', NULL, N'0', CAST(N'2018-07-24 11:07:48.000' AS DateTime), CAST(N'2018-07-24 11:07:48.000' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (306, NULL, N'Mistry,Hitesh', NULL, N'0', CAST(N'2018-07-24 11:07:48.007' AS DateTime), CAST(N'2018-07-24 11:07:48.007' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (307, NULL, N'MM,Goutham', NULL, N'0', CAST(N'2018-07-24 11:07:48.010' AS DateTime), CAST(N'2018-07-24 11:07:48.010' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (308, NULL, N'Mohamed Salleh,Najib', NULL, N'0', CAST(N'2018-07-24 11:07:48.013' AS DateTime), CAST(N'2018-07-24 11:07:48.013' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (309, 1012030, N'Mohan,Murali', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.017' AS DateTime), CAST(N'2018-07-24 11:07:48.017' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (310, 1013867, N'Mohan,Murali P', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.037' AS DateTime), CAST(N'2018-07-24 11:07:48.037' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (311, NULL, N'Mohite,Sumit', NULL, N'0', CAST(N'2018-07-24 11:07:48.040' AS DateTime), CAST(N'2018-07-24 11:07:48.040' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (312, NULL, N'Moig,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:48.047' AS DateTime), CAST(N'2018-07-24 11:07:48.047' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (313, NULL, N'Morris,Bill', NULL, N'0', CAST(N'2018-07-24 11:07:48.050' AS DateTime), CAST(N'2018-07-24 11:07:48.050' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (314, NULL, N'Moseley,Jason', NULL, N'0', CAST(N'2018-07-24 11:07:48.053' AS DateTime), CAST(N'2018-07-24 11:07:48.053' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (315, NULL, N'Moss,Nigel', NULL, N'0', CAST(N'2018-07-24 11:07:48.057' AS DateTime), CAST(N'2018-07-24 11:07:48.057' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (316, NULL, N'Mougenot,Robin', NULL, N'0', CAST(N'2018-07-24 11:07:48.060' AS DateTime), CAST(N'2018-07-24 11:07:48.060' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (317, NULL, N'Muhammad,Hanif', NULL, N'0', CAST(N'2018-07-24 11:07:48.067' AS DateTime), CAST(N'2018-07-24 11:07:48.067' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (318, NULL, N'Muir,Jonathon', NULL, N'0', CAST(N'2018-07-24 11:07:48.070' AS DateTime), CAST(N'2018-07-24 11:07:48.070' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (319, NULL, N'Mukherjee,Anupam', NULL, N'0', CAST(N'2018-07-24 11:07:48.073' AS DateTime), CAST(N'2018-07-24 11:07:48.073' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (320, NULL, N'Mukherjee,Payal', NULL, N'0', CAST(N'2018-07-24 11:07:48.090' AS DateTime), CAST(N'2018-07-24 11:07:48.090' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (321, 1002440, N'Munisamy,Sampath', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.093' AS DateTime), CAST(N'2018-07-24 11:07:48.093' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (322, NULL, N'Munton,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:48.097' AS DateTime), CAST(N'2018-07-24 11:07:48.097' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (323, 1011173, N'Murugesan,Manikandan', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.100' AS DateTime), CAST(N'2018-07-24 11:07:48.100' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (324, NULL, N'Muthumala,Gayan', NULL, N'0', CAST(N'2018-07-24 11:07:48.107' AS DateTime), CAST(N'2018-07-24 11:07:48.107' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (325, 1009749, N'N, Balaji', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.110' AS DateTime), CAST(N'2018-07-24 11:07:48.110' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (326, 1018484, N'Nad,Sagar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.113' AS DateTime), CAST(N'2018-07-24 11:07:48.113' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (327, NULL, N'Naessens,Christophe', NULL, N'0', CAST(N'2018-07-24 11:07:48.117' AS DateTime), CAST(N'2018-07-24 11:07:48.117' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (328, 1017051, N'Nagraj, Pawar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.120' AS DateTime), CAST(N'2018-07-24 11:07:48.120' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (329, 1003093, N'Nagunaik, A', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.127' AS DateTime), CAST(N'2018-07-24 11:07:48.127' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (330, NULL, N'Naik, Raghavendra', NULL, N'0', CAST(N'2018-07-24 11:07:48.130' AS DateTime), CAST(N'2018-07-24 11:07:48.130' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (331, 1003724, N'Naik,Kamalakar', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.133' AS DateTime), CAST(N'2018-07-24 11:07:48.133' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (332, NULL, N'Naik,Prasad', NULL, N'0', CAST(N'2018-07-24 11:07:48.137' AS DateTime), CAST(N'2018-07-24 11:07:48.137' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (333, 1008097, N'Nandy,Monalisa', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.140' AS DateTime), CAST(N'2018-07-24 11:07:48.140' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (334, NULL, N'Nannetti,Jeff', NULL, N'0', CAST(N'2018-07-24 11:07:48.147' AS DateTime), CAST(N'2018-07-24 11:07:48.147' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (335, 1016567, N'Naveen, Pujar', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.150' AS DateTime), CAST(N'2018-07-24 11:07:48.150' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (336, NULL, N'Nayak, Arvind', NULL, N'0', CAST(N'2018-07-24 11:07:48.153' AS DateTime), CAST(N'2018-07-24 11:07:48.153' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (337, NULL, N'Nayak, Prithvi', NULL, N'0', CAST(N'2018-07-24 11:07:48.157' AS DateTime), CAST(N'2018-07-24 11:07:48.157' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (338, 1002477, N'Nayak,Ashok', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.160' AS DateTime), CAST(N'2018-07-24 11:07:48.160' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (339, 2004716, N'Neelakanthayya,H', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.167' AS DateTime), CAST(N'2018-07-24 11:07:48.167' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (340, NULL, N'Ng,Simon', NULL, N'0', CAST(N'2018-07-24 11:07:48.170' AS DateTime), CAST(N'2018-07-24 11:07:48.170' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (341, NULL, N'Nikhil, Ashwin', NULL, N'0', CAST(N'2018-07-24 11:07:48.173' AS DateTime), CAST(N'2018-07-24 11:07:48.173' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (342, NULL, N'Nikhil, Kolhapuri', NULL, N'0', CAST(N'2018-07-24 11:07:48.177' AS DateTime), CAST(N'2018-07-24 11:07:48.177' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (343, 1020410, N'Nishant,Potadar', NULL, N'1', CAST(N'2018-07-24 11:07:48.180' AS DateTime), CAST(N'2018-07-24 11:07:48.180' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (344, NULL, N'Nithin UB', NULL, N'0', CAST(N'2018-07-24 11:07:48.187' AS DateTime), CAST(N'2018-07-24 11:07:48.187' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (345, 1014083, N'Nithiyanantham,Ganesh', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.190' AS DateTime), CAST(N'2018-07-24 11:07:48.190' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (346, NULL, N'Norton,Adam', NULL, N'0', CAST(N'2018-07-24 11:07:48.193' AS DateTime), CAST(N'2018-07-24 11:07:48.193' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (347, NULL, N'NSK,Swamy', NULL, N'0', CAST(N'2018-07-24 11:07:48.197' AS DateTime), CAST(N'2018-07-24 11:07:48.197' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (348, NULL, N'Offord,Tom', NULL, N'0', CAST(N'2018-07-24 11:07:48.200' AS DateTime), CAST(N'2018-07-24 11:07:48.200' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (349, NULL, N'Ong,Tenghao', NULL, N'0', CAST(N'2018-07-24 11:07:48.207' AS DateTime), CAST(N'2018-07-24 11:07:48.207' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (350, NULL, N'Padmanabhan,Ananda', NULL, N'0', CAST(N'2018-07-24 11:07:48.210' AS DateTime), CAST(N'2018-07-24 11:07:48.210' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (351, NULL, N'Padmanabhan,Prakash', NULL, N'0', CAST(N'2018-07-24 11:07:48.213' AS DateTime), CAST(N'2018-07-24 11:07:48.213' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (352, 1004783, N'Palani,Kamal', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.217' AS DateTime), CAST(N'2018-07-24 11:07:48.217' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (353, NULL, N'Pandey,Sudhir', NULL, N'0', CAST(N'2018-07-24 11:07:48.220' AS DateTime), CAST(N'2018-07-24 11:07:48.220' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (354, NULL, N'Pandian,Ramachandran', NULL, N'0', CAST(N'2018-07-24 11:07:48.227' AS DateTime), CAST(N'2018-07-24 11:07:48.227' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (355, NULL, N'Papanikolaou,Dimitrios', NULL, N'0', CAST(N'2018-07-24 11:07:48.230' AS DateTime), CAST(N'2018-07-24 11:07:48.230' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (356, 1016257, N'Param, Jolly', NULL, N'1', CAST(N'2018-07-24 11:07:48.233' AS DateTime), CAST(N'2018-07-24 11:07:48.233' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (357, NULL, N'Parkin,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:48.237' AS DateTime), CAST(N'2018-07-24 11:07:48.237' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (358, NULL, N'Parthpan,Vignesh', NULL, N'0', CAST(N'2018-07-24 11:07:48.240' AS DateTime), CAST(N'2018-07-24 11:07:48.240' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (359, NULL, N'Patil,Basavaraj', NULL, N'0', CAST(N'2018-07-24 11:07:48.247' AS DateTime), CAST(N'2018-07-24 11:07:48.247' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (360, NULL, N'Patterson,Ian', NULL, N'0', CAST(N'2018-07-24 11:07:48.250' AS DateTime), CAST(N'2018-07-24 11:07:48.250' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (361, NULL, N'Peacock, Jonathan', NULL, N'0', CAST(N'2018-07-24 11:07:48.253' AS DateTime), CAST(N'2018-07-24 11:07:48.253' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (362, NULL, N'Peddireddi,Murali', NULL, N'0', CAST(N'2018-07-24 11:07:48.257' AS DateTime), CAST(N'2018-07-24 11:07:48.257' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (363, NULL, N'Pegrum,Alex', NULL, N'0', CAST(N'2018-07-24 11:07:48.260' AS DateTime), CAST(N'2018-07-24 11:07:48.260' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (364, NULL, N'Penney,Richard', NULL, N'0', CAST(N'2018-07-24 11:07:48.267' AS DateTime), CAST(N'2018-07-24 11:07:48.267' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (365, NULL, N'Pentland,Simon', NULL, N'0', CAST(N'2018-07-24 11:07:48.270' AS DateTime), CAST(N'2018-07-24 11:07:48.270' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (366, NULL, N'Petty-Fitzmaurice,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:48.273' AS DateTime), CAST(N'2018-07-24 11:07:48.273' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (367, NULL, N'Phillips,Andy', NULL, N'0', CAST(N'2018-07-24 11:07:48.277' AS DateTime), CAST(N'2018-07-24 11:07:48.277' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (368, NULL, N'Phillips,Iain', NULL, N'0', CAST(N'2018-07-24 11:07:48.280' AS DateTime), CAST(N'2018-07-24 11:07:48.280' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (369, NULL, N'Pon,Narayanan', NULL, N'0', CAST(N'2018-07-24 11:07:48.287' AS DateTime), CAST(N'2018-07-24 11:07:48.287' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (370, 1012091, N'Ponnusamy,Ashok', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.290' AS DateTime), CAST(N'2018-07-24 11:07:48.290' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (371, NULL, N'Porter,Nigel', NULL, N'0', CAST(N'2018-07-24 11:07:48.293' AS DateTime), CAST(N'2018-07-24 11:07:48.293' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (372, NULL, N'Pounder,Matt', NULL, N'0', CAST(N'2018-07-24 11:07:48.297' AS DateTime), CAST(N'2018-07-24 11:07:48.297' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (373, NULL, N'Prasad, Raghu', NULL, N'0', CAST(N'2018-07-24 11:07:48.300' AS DateTime), CAST(N'2018-07-24 11:07:48.300' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (374, NULL, N'Prasad,Jithin', NULL, N'0', CAST(N'2018-07-24 11:07:48.307' AS DateTime), CAST(N'2018-07-24 11:07:48.307' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (375, 1015860, N'Prasad,Pavan', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.310' AS DateTime), CAST(N'2018-07-24 11:07:48.310' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (376, 1011833, N'Prashant,Betageri', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.313' AS DateTime), CAST(N'2018-07-24 11:07:48.313' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (377, 1016565, N'Praveen, Aralikatti', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.317' AS DateTime), CAST(N'2018-07-24 11:07:48.317' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (378, NULL, N'Price,Ralph', NULL, N'0', CAST(N'2018-07-24 11:07:48.320' AS DateTime), CAST(N'2018-07-24 11:07:48.320' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (379, NULL, N'Prijil,Koyyodan', NULL, N'0', CAST(N'2018-07-24 11:07:48.327' AS DateTime), CAST(N'2018-07-24 11:07:48.327' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (380, NULL, N'Pritchard,Dave', NULL, N'0', CAST(N'2018-07-24 11:07:48.330' AS DateTime), CAST(N'2018-07-24 11:07:48.330' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (381, 1016933, N'Prudhvi Ram', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.333' AS DateTime), CAST(N'2018-07-24 11:07:48.333' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (382, NULL, N'Quirk,Paul', NULL, N'0', CAST(N'2018-07-24 11:07:48.337' AS DateTime), CAST(N'2018-07-24 11:07:48.337' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (383, 1004889, N'R, Gopinath', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.340' AS DateTime), CAST(N'2018-07-24 11:07:48.340' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (384, 1003726, N'R,Ranjith', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.347' AS DateTime), CAST(N'2018-07-24 11:07:48.347' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (385, 1003098, N'Raghavendra,Prabhu', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.350' AS DateTime), CAST(N'2018-07-24 11:07:48.350' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (386, NULL, N'Raghudas Puthiyadath', NULL, N'0', CAST(N'2018-07-24 11:07:48.353' AS DateTime), CAST(N'2018-07-24 11:07:48.353' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (387, NULL, N'Raghupathy,Raghavendra', NULL, N'0', CAST(N'2018-07-24 11:07:48.357' AS DateTime), CAST(N'2018-07-24 11:07:48.357' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (388, 1011169, N'Rahul,Gopal', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.360' AS DateTime), CAST(N'2018-07-24 11:07:48.360' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (389, 1003812, N'Rajendran, Balaji', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:48.367' AS DateTime), CAST(N'2018-07-24 11:07:48.367' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (390, NULL, N'Rajesh, Kuttan', NULL, N'0', CAST(N'2018-07-24 11:07:48.370' AS DateTime), CAST(N'2018-07-24 11:07:48.370' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (391, NULL, N'Rajmane, Shreyas', NULL, N'0', CAST(N'2018-07-24 11:07:48.373' AS DateTime), CAST(N'2018-07-24 11:07:48.373' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (392, NULL, N'Rakesh,Sahoo', NULL, N'0', CAST(N'2018-07-24 11:07:48.377' AS DateTime), CAST(N'2018-07-24 11:07:48.377' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (393, 1020405, N'Ramya,Pilla', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.380' AS DateTime), CAST(N'2018-07-24 11:07:48.380' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (394, 1016593, N'Rangaraj,Praveen', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.387' AS DateTime), CAST(N'2018-07-24 11:07:48.387' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (395, NULL, N'Rangaswamy,P Chikkappa', NULL, N'0', CAST(N'2018-07-24 11:07:48.390' AS DateTime), CAST(N'2018-07-24 11:07:48.390' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (396, NULL, N'Rao, Suman', NULL, N'0', CAST(N'2018-07-24 11:07:48.393' AS DateTime), CAST(N'2018-07-24 11:07:48.393' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (397, NULL, N'Rasnake,Jodie', NULL, N'0', CAST(N'2018-07-24 11:07:48.397' AS DateTime), CAST(N'2018-07-24 11:07:48.397' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (398, NULL, N'Rathbone,Nigel', NULL, N'0', CAST(N'2018-07-24 11:07:48.400' AS DateTime), CAST(N'2018-07-24 11:07:48.400' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (399, NULL, N'Raynor,David', NULL, N'0', CAST(N'2018-07-24 11:07:48.417' AS DateTime), CAST(N'2018-07-24 11:07:48.417' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (400, NULL, N'Redding,James', NULL, N'0', CAST(N'2018-07-24 11:07:48.420' AS DateTime), CAST(N'2018-07-24 11:07:48.420' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (401, NULL, N'Redfearn,Russell', NULL, N'0', CAST(N'2018-07-24 11:07:48.427' AS DateTime), CAST(N'2018-07-24 11:07:48.427' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (402, NULL, N'Ride,Sean', NULL, N'0', CAST(N'2018-07-24 11:07:48.430' AS DateTime), CAST(N'2018-07-24 11:07:48.430' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (403, NULL, N'Ridgway,Matt', NULL, N'0', CAST(N'2018-07-24 11:07:48.433' AS DateTime), CAST(N'2018-07-24 11:07:48.433' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (404, NULL, N'Riley,Richard', NULL, N'0', CAST(N'2018-07-24 11:07:48.437' AS DateTime), CAST(N'2018-07-24 11:07:48.437' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (405, 1016445, N'Rinku,Ranadheer', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.440' AS DateTime), CAST(N'2018-07-24 11:07:48.440' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (406, NULL, N'Riswan,Mohamed', NULL, N'0', CAST(N'2018-07-24 11:07:48.447' AS DateTime), CAST(N'2018-07-24 11:07:48.447' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (407, 1006103, N'Rizwan,Sheik', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.450' AS DateTime), CAST(N'2018-07-24 11:07:48.450' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (408, NULL, N'Robey,Michael', NULL, N'0', CAST(N'2018-07-24 11:07:48.453' AS DateTime), CAST(N'2018-07-24 11:07:48.453' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (409, NULL, N'Robinson,Andy', NULL, N'0', CAST(N'2018-07-24 11:07:48.457' AS DateTime), CAST(N'2018-07-24 11:07:48.457' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (410, NULL, N'Robinson,James', NULL, N'0', CAST(N'2018-07-24 11:07:48.460' AS DateTime), CAST(N'2018-07-24 11:07:48.460' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (411, NULL, N'Robinson,Keith', NULL, N'0', CAST(N'2018-07-24 11:07:48.467' AS DateTime), CAST(N'2018-07-24 11:07:48.467' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (412, NULL, N'Rogers,David', NULL, N'0', CAST(N'2018-07-24 11:07:48.470' AS DateTime), CAST(N'2018-07-24 11:07:48.470' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (413, NULL, N'Rohan, Ravindra', NULL, N'0', CAST(N'2018-07-24 11:07:48.473' AS DateTime), CAST(N'2018-07-24 11:07:48.473' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (414, NULL, N'Rohit, R', NULL, N'0', CAST(N'2018-07-24 11:07:48.477' AS DateTime), CAST(N'2018-07-24 11:07:48.477' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (415, NULL, N'Rohith, R', NULL, N'0', CAST(N'2018-07-24 11:07:48.480' AS DateTime), CAST(N'2018-07-24 11:07:48.480' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (416, NULL, N'Rollin, Stephen', NULL, N'0', CAST(N'2018-07-24 11:07:48.487' AS DateTime), CAST(N'2018-07-24 11:07:48.487' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (417, NULL, N'Rooth, Steve', NULL, N'0', CAST(N'2018-07-24 11:07:48.490' AS DateTime), CAST(N'2018-07-24 11:07:48.490' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (418, NULL, N'Roper,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:48.493' AS DateTime), CAST(N'2018-07-24 11:07:48.493' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (419, NULL, N'Rothkopf,Phillip', NULL, N'0', CAST(N'2018-07-24 11:07:48.497' AS DateTime), CAST(N'2018-07-24 11:07:48.497' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (420, NULL, N'RROIPL (Repair)', NULL, N'0', CAST(N'2018-07-24 11:07:48.500' AS DateTime), CAST(N'2018-07-24 11:07:48.500' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (421, NULL, N'RROIPL (Service)', NULL, N'0', CAST(N'2018-07-24 11:07:48.507' AS DateTime), CAST(N'2018-07-24 11:07:48.507' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (422, NULL, N'Rubio-Cubas,Adrian', NULL, N'0', CAST(N'2018-07-24 11:07:48.510' AS DateTime), CAST(N'2018-07-24 11:07:48.510' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (423, NULL, N'Ruggieri,Michele', NULL, N'0', CAST(N'2018-07-24 11:07:48.513' AS DateTime), CAST(N'2018-07-24 11:07:48.513' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (424, 1003035, N'S,Shivakiran', N'Current User at Onsite', N'0', CAST(N'2018-07-24 11:07:48.520' AS DateTime), CAST(N'2018-07-24 11:07:48.520' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (425, NULL, N'Sachin,Srikanth', NULL, N'0', CAST(N'2018-07-24 11:07:48.523' AS DateTime), CAST(N'2018-07-24 11:07:48.523' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (426, NULL, N'Safran Nacelles', NULL, N'0', CAST(N'2018-07-24 11:07:48.527' AS DateTime), CAST(N'2018-07-24 11:07:48.527' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (427, 1011760, N'Sagar,Venkatesha', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.530' AS DateTime), CAST(N'2018-07-24 11:07:48.530' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (428, NULL, N'Salam,Mohammed', NULL, N'0', CAST(N'2018-07-24 11:07:48.533' AS DateTime), CAST(N'2018-07-24 11:07:48.533' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (429, NULL, N'Salihin, Mohamad', NULL, N'0', CAST(N'2018-07-24 11:07:48.537' AS DateTime), CAST(N'2018-07-24 11:07:48.537' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (430, 1021024, N'Sanchita Sarkar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.540' AS DateTime), CAST(N'2018-07-24 11:07:48.540' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (431, NULL, N'Sandeep, Mule', NULL, N'0', CAST(N'2018-07-24 11:07:48.547' AS DateTime), CAST(N'2018-07-24 11:07:48.547' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (432, 2004492, N'Sandilya M', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.550' AS DateTime), CAST(N'2018-07-24 11:07:48.550' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (433, NULL, N'Sanjay,Dutta', NULL, N'0', CAST(N'2018-07-24 11:07:48.553' AS DateTime), CAST(N'2018-07-24 11:07:48.553' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (434, 1009597, N'Sanketh,R', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.560' AS DateTime), CAST(N'2018-07-24 11:07:48.560' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (435, 1017747, N'Sarabjeet Singh', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.590' AS DateTime), CAST(N'2018-07-24 11:07:48.590' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (436, 1019215, N'Satish, Subramanian', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:48.603' AS DateTime), CAST(N'2018-07-24 11:07:48.603' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (437, NULL, N'Scurr, Andy', NULL, N'0', CAST(N'2018-07-24 11:07:48.607' AS DateTime), CAST(N'2018-07-24 11:07:48.607' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (438, NULL, N'Sebastian,Nitin', NULL, N'0', CAST(N'2018-07-24 11:07:48.610' AS DateTime), CAST(N'2018-07-24 11:07:48.610' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (439, NULL, N'Seet,Airil', NULL, N'0', CAST(N'2018-07-24 11:07:48.613' AS DateTime), CAST(N'2018-07-24 11:07:48.613' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (440, NULL, N'Serementa,Mario', NULL, N'0', CAST(N'2018-07-24 11:07:48.620' AS DateTime), CAST(N'2018-07-24 11:07:48.620' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (441, NULL, N'Shah,Manan', NULL, N'0', CAST(N'2018-07-24 11:07:48.623' AS DateTime), CAST(N'2018-07-24 11:07:48.623' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (442, 1012131, N'Shankar,Mani', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.627' AS DateTime), CAST(N'2018-07-24 11:07:48.627' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (443, NULL, N'Shaw,Kevin', NULL, N'0', CAST(N'2018-07-24 11:07:48.630' AS DateTime), CAST(N'2018-07-24 11:07:48.630' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (444, 1018309, N'Shiyamsundar,V', NULL, N'1', CAST(N'2018-07-24 11:07:48.650' AS DateTime), CAST(N'2018-07-24 11:07:48.650' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (445, NULL, N'Shore,Adrian', NULL, N'0', CAST(N'2018-07-24 11:07:48.723' AS DateTime), CAST(N'2018-07-24 11:07:48.723' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (446, NULL, N'Shorts', NULL, N'0', CAST(N'2018-07-24 11:07:48.740' AS DateTime), CAST(N'2018-07-24 11:07:48.740' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (447, 1020477, N'Shweta,Patil', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.743' AS DateTime), CAST(N'2018-07-24 11:07:48.743' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (448, NULL, N'Siddaraju,Nagaraju', NULL, N'0', CAST(N'2018-07-24 11:07:48.747' AS DateTime), CAST(N'2018-07-24 11:07:48.747' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (449, NULL, N'Sievers,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:48.750' AS DateTime), CAST(N'2018-07-24 11:07:48.750' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (450, NULL, N'Silvester,Jenny', NULL, N'0', CAST(N'2018-07-24 11:07:48.753' AS DateTime), CAST(N'2018-07-24 11:07:48.753' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (451, 2004470, N'Singh,Vignesh', NULL, N'1', CAST(N'2018-07-24 11:07:48.760' AS DateTime), CAST(N'2018-07-24 11:07:48.760' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (452, NULL, N'Sisson,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:48.767' AS DateTime), CAST(N'2018-07-24 11:07:48.767' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (453, NULL, N'Siu,Sarah', NULL, N'0', CAST(N'2018-07-24 11:07:48.770' AS DateTime), CAST(N'2018-07-24 11:07:48.770' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (454, 1016754, N'Siva, Shunmugam', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:48.773' AS DateTime), CAST(N'2018-07-24 11:07:48.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (455, NULL, N'Sivadasan,Vayyattu', NULL, N'0', CAST(N'2018-07-24 11:07:48.780' AS DateTime), CAST(N'2018-07-24 11:07:48.780' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (456, NULL, N'Skaper,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:48.783' AS DateTime), CAST(N'2018-07-24 11:07:48.783' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (457, NULL, N'Skelton,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:48.787' AS DateTime), CAST(N'2018-07-24 11:07:48.787' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (458, NULL, N'Slater,Phil', NULL, N'0', CAST(N'2018-07-24 11:07:48.790' AS DateTime), CAST(N'2018-07-24 11:07:48.790' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (459, NULL, N'Smith, Paul W', NULL, N'0', CAST(N'2018-07-24 11:07:48.793' AS DateTime), CAST(N'2018-07-24 11:07:48.793' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (460, NULL, N'Smith,Jez', NULL, N'0', CAST(N'2018-07-24 11:07:48.800' AS DateTime), CAST(N'2018-07-24 11:07:48.800' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (461, NULL, N'Smith,Paul A', NULL, N'0', CAST(N'2018-07-24 11:07:48.803' AS DateTime), CAST(N'2018-07-24 11:07:48.803' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (462, NULL, N'Smith,Richard', NULL, N'0', CAST(N'2018-07-24 11:07:48.807' AS DateTime), CAST(N'2018-07-24 11:07:48.807' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (463, NULL, N'Srinivasan,M', NULL, N'0', CAST(N'2018-07-24 11:07:48.810' AS DateTime), CAST(N'2018-07-24 11:07:48.810' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (464, 1018308, N'Sruthi,OS', NULL, N'1', CAST(N'2018-07-24 11:07:48.813' AS DateTime), CAST(N'2018-07-24 11:07:48.813' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (465, NULL, N'Staunton,Godfrey', NULL, N'0', CAST(N'2018-07-24 11:07:48.820' AS DateTime), CAST(N'2018-07-24 11:07:48.820' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (466, NULL, N'Stilwell,Jonathan', NULL, N'0', CAST(N'2018-07-24 11:07:48.823' AS DateTime), CAST(N'2018-07-24 11:07:48.823' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (467, NULL, N'Stolworthy,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:48.827' AS DateTime), CAST(N'2018-07-24 11:07:48.827' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (468, NULL, N'Stone,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:48.830' AS DateTime), CAST(N'2018-07-24 11:07:48.830' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (469, NULL, N'Street,Dan', NULL, N'0', CAST(N'2018-07-24 11:07:48.833' AS DateTime), CAST(N'2018-07-24 11:07:48.833' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (470, 1011975, N'Subin,Pothen', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:48.840' AS DateTime), CAST(N'2018-07-24 11:07:48.840' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (471, 1009753, N'Sudhir,Surag', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.843' AS DateTime), CAST(N'2018-07-24 11:07:48.843' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (472, NULL, N'Sugali, Hanuman Naik', NULL, N'0', CAST(N'2018-07-24 11:07:48.847' AS DateTime), CAST(N'2018-07-24 11:07:48.847' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (473, 1001086, N'Suhas H', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.850' AS DateTime), CAST(N'2018-07-24 11:07:48.850' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (474, 1017185, N'Sukesan,Sujay', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.853' AS DateTime), CAST(N'2018-07-24 11:07:48.853' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (475, NULL, N'Sukumaran,Manikandan', NULL, N'0', CAST(N'2018-07-24 11:07:48.860' AS DateTime), CAST(N'2018-07-24 11:07:48.860' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (476, NULL, N'Sundraraj,Surithra', NULL, N'0', CAST(N'2018-07-24 11:07:48.860' AS DateTime), CAST(N'2018-07-24 11:07:48.860' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (477, 1016207, N'Suneet, Kajjidoni', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.867' AS DateTime), CAST(N'2018-07-24 11:07:48.867' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (478, 1011624, N'Sunil,Venkatesan', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.870' AS DateTime), CAST(N'2018-07-24 11:07:48.870' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (479, 1012038, N'SunilKumar', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.873' AS DateTime), CAST(N'2018-07-24 11:07:48.873' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (480, NULL, N'Suresh,Subhash', NULL, N'0', CAST(N'2018-07-24 11:07:48.880' AS DateTime), CAST(N'2018-07-24 11:07:48.880' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (481, NULL, N'Suresh,Vignesh', NULL, N'0', CAST(N'2018-07-24 11:07:48.887' AS DateTime), CAST(N'2018-07-24 11:07:48.887' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (482, NULL, N'SV,Sunderji', NULL, N'0', CAST(N'2018-07-24 11:07:48.890' AS DateTime), CAST(N'2018-07-24 11:07:48.890' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (483, NULL, N'Swain,Jonathan', NULL, N'0', CAST(N'2018-07-24 11:07:48.900' AS DateTime), CAST(N'2018-07-24 11:07:48.900' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (484, NULL, N'Swamy,Gonisetti', NULL, N'0', CAST(N'2018-07-24 11:07:48.907' AS DateTime), CAST(N'2018-07-24 11:07:48.907' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (485, NULL, N'Swift,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:48.910' AS DateTime), CAST(N'2018-07-24 11:07:48.910' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (486, NULL, N'Swinburn,Tim', NULL, N'0', CAST(N'2018-07-24 11:07:48.913' AS DateTime), CAST(N'2018-07-24 11:07:48.913' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (487, NULL, N'Swingler,Andrew', NULL, N'0', CAST(N'2018-07-24 11:07:48.917' AS DateTime), CAST(N'2018-07-24 11:07:48.917' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (488, NULL, N'Synodinos, Panayis', NULL, N'0', CAST(N'2018-07-24 11:07:48.920' AS DateTime), CAST(N'2018-07-24 11:07:48.920' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (489, NULL, N'Tan Eng Seng', NULL, N'0', CAST(N'2018-07-24 11:07:48.927' AS DateTime), CAST(N'2018-07-24 11:07:48.927' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (490, NULL, N'Tan, Travis', NULL, N'0', CAST(N'2018-07-24 11:07:48.930' AS DateTime), CAST(N'2018-07-24 11:07:48.930' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (491, NULL, N'Tankasali,Abhilash', NULL, N'0', CAST(N'2018-07-24 11:07:48.933' AS DateTime), CAST(N'2018-07-24 11:07:48.933' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (492, NULL, N'Taroni,Jim', NULL, N'0', CAST(N'2018-07-24 11:07:48.937' AS DateTime), CAST(N'2018-07-24 11:07:48.937' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (493, NULL, N'Teale,Matt', NULL, N'0', CAST(N'2018-07-24 11:07:48.940' AS DateTime), CAST(N'2018-07-24 11:07:48.940' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (494, 1016185, N'Tejaswini, D', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.947' AS DateTime), CAST(N'2018-07-24 11:07:48.947' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (495, NULL, N'Telford,Simon', NULL, N'0', CAST(N'2018-07-24 11:07:48.950' AS DateTime), CAST(N'2018-07-24 11:07:48.950' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (496, NULL, N'Thangaraj,Settu', NULL, N'0', CAST(N'2018-07-24 11:07:48.953' AS DateTime), CAST(N'2018-07-24 11:07:48.953' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (497, NULL, N'Thendihalli, Rajesh', NULL, N'0', CAST(N'2018-07-24 11:07:48.957' AS DateTime), CAST(N'2018-07-24 11:07:48.957' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (498, 1004784, N'Thinsin,Prince', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:48.960' AS DateTime), CAST(N'2018-07-24 11:07:48.960' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (499, NULL, N'Thiruvengadum,Balachandran', NULL, N'0', CAST(N'2018-07-24 11:07:48.967' AS DateTime), CAST(N'2018-07-24 11:07:48.967' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (500, NULL, N'Thompson,Ewan', NULL, N'0', CAST(N'2018-07-24 11:07:48.970' AS DateTime), CAST(N'2018-07-24 11:07:48.970' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (501, NULL, N'Thonduvelil,Benny', NULL, N'0', CAST(N'2018-07-24 11:07:48.973' AS DateTime), CAST(N'2018-07-24 11:07:48.973' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (502, NULL, N'Thorat,Rohit', NULL, N'0', CAST(N'2018-07-24 11:07:48.977' AS DateTime), CAST(N'2018-07-24 11:07:48.977' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (503, NULL, N'Thorne,Mark', NULL, N'0', CAST(N'2018-07-24 11:07:48.980' AS DateTime), CAST(N'2018-07-24 11:07:48.980' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (504, NULL, N'Tiruvidi,Balachandar', NULL, N'0', CAST(N'2018-07-24 11:07:48.987' AS DateTime), CAST(N'2018-07-24 11:07:48.987' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (505, NULL, N'To,Ivan', NULL, N'0', CAST(N'2018-07-24 11:07:48.997' AS DateTime), CAST(N'2018-07-24 11:07:48.997' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (506, NULL, N'Tomlinson,Pete', NULL, N'0', CAST(N'2018-07-24 11:07:49.000' AS DateTime), CAST(N'2018-07-24 11:07:49.000' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (507, NULL, N'Towe, James', NULL, N'0', CAST(N'2018-07-24 11:07:49.007' AS DateTime), CAST(N'2018-07-24 11:07:49.007' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (508, NULL, N'Tripathi,Vibha', NULL, N'0', CAST(N'2018-07-24 11:07:49.010' AS DateTime), CAST(N'2018-07-24 11:07:49.010' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (509, NULL, N'Trivett,Ivan', NULL, N'0', CAST(N'2018-07-24 11:07:49.013' AS DateTime), CAST(N'2018-07-24 11:07:49.013' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (510, NULL, N'Tucker, D L', NULL, N'0', CAST(N'2018-07-24 11:07:49.017' AS DateTime), CAST(N'2018-07-24 11:07:49.017' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (511, NULL, N'Tucker,Dave J', NULL, N'0', CAST(N'2018-07-24 11:07:49.020' AS DateTime), CAST(N'2018-07-24 11:07:49.020' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (512, NULL, N'Tudbury,Gary', NULL, N'0', CAST(N'2018-07-24 11:07:49.027' AS DateTime), CAST(N'2018-07-24 11:07:49.027' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (513, NULL, N'Tulluri, Venkateswarlu', NULL, N'0', CAST(N'2018-07-24 11:07:49.030' AS DateTime), CAST(N'2018-07-24 11:07:49.030' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (514, NULL, N'Tungate,Darren', NULL, N'0', CAST(N'2018-07-24 11:07:49.033' AS DateTime), CAST(N'2018-07-24 11:07:49.033' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (515, NULL, N'Turnbull,Dan', NULL, N'0', CAST(N'2018-07-24 11:07:49.037' AS DateTime), CAST(N'2018-07-24 11:07:49.037' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (516, NULL, N'Turrill,John', NULL, N'0', CAST(N'2018-07-24 11:07:49.040' AS DateTime), CAST(N'2018-07-24 11:07:49.040' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (517, 1003176, N'Tushar, Chavan', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:49.047' AS DateTime), CAST(N'2018-07-24 11:07:49.047' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (518, NULL, N'Tyrrell,Glen', NULL, N'0', CAST(N'2018-07-24 11:07:49.050' AS DateTime), CAST(N'2018-07-24 11:07:49.050' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (519, NULL, N'Unnikrishnan,Chithran', NULL, N'0', CAST(N'2018-07-24 11:07:49.053' AS DateTime), CAST(N'2018-07-24 11:07:49.053' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (520, NULL, N'UTAS', NULL, N'0', CAST(N'2018-07-24 11:07:49.057' AS DateTime), CAST(N'2018-07-24 11:07:49.057' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (521, 1002664, N'Utsav,Agrawal', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:49.060' AS DateTime), CAST(N'2018-07-24 11:07:49.060' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (522, 1018503, N'V,Devaraj', NULL, N'1', CAST(N'2018-07-24 11:07:49.067' AS DateTime), CAST(N'2018-07-24 11:07:49.067' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (523, NULL, N'Van Ingen, Caroline', NULL, N'0', CAST(N'2018-07-24 11:07:49.070' AS DateTime), CAST(N'2018-07-24 11:07:49.070' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (524, 1014056, N'Vasudev, Bhise', N'Current User at offshore', N'1', CAST(N'2018-07-24 11:07:49.073' AS DateTime), CAST(N'2018-07-24 11:07:49.073' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (525, NULL, N'Vemappa,Rakesh', NULL, N'0', CAST(N'2018-07-24 11:07:49.077' AS DateTime), CAST(N'2018-07-24 11:07:49.077' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (526, 1011168, N'Venkatesan,Durai', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:49.080' AS DateTime), CAST(N'2018-07-24 11:07:49.080' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (527, NULL, N'Venugopal,Raghavan', NULL, N'0', CAST(N'2018-07-24 11:07:49.087' AS DateTime), CAST(N'2018-07-24 11:07:49.087' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (528, 1018473, N'Verma,Bhaskar', NULL, N'1', CAST(N'2018-07-24 11:07:49.090' AS DateTime), CAST(N'2018-07-24 11:07:49.090' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (529, 1005071, N'Vijay,K', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:49.093' AS DateTime), CAST(N'2018-07-24 11:07:49.093' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (530, 1011829, N'Vijayan,Vimal', N'Current User at offshore', N'0', CAST(N'2018-07-24 11:07:49.097' AS DateTime), CAST(N'2018-07-24 11:07:49.097' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (531, NULL, N'Vikhyath Kumar ', NULL, N'0', CAST(N'2018-07-24 11:07:49.100' AS DateTime), CAST(N'2018-07-24 11:07:49.100' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (532, 1011205, N'Vinayak, Mogalishettar', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:49.107' AS DateTime), CAST(N'2018-07-24 11:07:49.107' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (533, 1005038, N'VinodKumar, S', N'Current User at Onsite', N'1', CAST(N'2018-07-24 11:07:49.110' AS DateTime), CAST(N'2018-07-24 11:07:49.110' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (534, NULL, N'Vinothkumar Palani', NULL, N'0', CAST(N'2018-07-24 11:07:49.113' AS DateTime), CAST(N'2018-07-24 11:07:49.113' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (535, NULL, N'Waldron,Brendan', NULL, N'0', CAST(N'2018-07-24 11:07:49.117' AS DateTime), CAST(N'2018-07-24 11:07:49.117' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (536, NULL, N'Warrener,John', NULL, N'0', CAST(N'2018-07-24 11:07:49.120' AS DateTime), CAST(N'2018-07-24 11:07:49.120' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (537, NULL, N'Waterman, Jo', NULL, N'0', CAST(N'2018-07-24 11:07:49.127' AS DateTime), CAST(N'2018-07-24 11:07:49.127' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (538, NULL, N'Watson,Andy', NULL, N'0', CAST(N'2018-07-24 11:07:49.130' AS DateTime), CAST(N'2018-07-24 11:07:49.130' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (539, NULL, N'Webb,Richard', NULL, N'0', CAST(N'2018-07-24 11:07:49.133' AS DateTime), CAST(N'2018-07-24 11:07:49.133' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (540, NULL, N'Wheawall,Gary', NULL, N'0', CAST(N'2018-07-24 11:07:49.137' AS DateTime), CAST(N'2018-07-24 11:07:49.137' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (541, NULL, N'White,Stephen', NULL, N'0', CAST(N'2018-07-24 11:07:49.140' AS DateTime), CAST(N'2018-07-24 11:07:49.140' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (542, NULL, N'Wightman,David', NULL, N'0', CAST(N'2018-07-24 11:07:49.157' AS DateTime), CAST(N'2018-07-24 11:07:49.157' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (543, NULL, N'Williams,Chris', NULL, N'0', CAST(N'2018-07-24 11:07:49.160' AS DateTime), CAST(N'2018-07-24 11:07:49.160' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (544, NULL, N'Wise,Mike', NULL, N'0', CAST(N'2018-07-24 11:07:49.167' AS DateTime), CAST(N'2018-07-24 11:07:49.167' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (545, NULL, N'Wodeyar,Madhukeshwar', NULL, N'0', CAST(N'2018-07-24 11:07:49.170' AS DateTime), CAST(N'2018-07-24 11:07:49.170' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (546, NULL, N'Wong, James', NULL, N'0', CAST(N'2018-07-24 11:07:49.173' AS DateTime), CAST(N'2018-07-24 11:07:49.173' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (547, NULL, N'Wong,Adrian', NULL, N'0', CAST(N'2018-07-24 11:07:49.177' AS DateTime), CAST(N'2018-07-24 11:07:49.177' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (548, NULL, N'Wong,Benson', NULL, N'0', CAST(N'2018-07-24 11:07:49.180' AS DateTime), CAST(N'2018-07-24 11:07:49.180' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (549, NULL, N'Woodward,Keith', NULL, N'0', CAST(N'2018-07-24 11:07:49.187' AS DateTime), CAST(N'2018-07-24 11:07:49.187' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (550, NULL, N'Wright,Steve', NULL, N'0', CAST(N'2018-07-24 11:07:49.190' AS DateTime), CAST(N'2018-07-24 11:07:49.190' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (551, NULL, N'Xianyao,Gooi', NULL, N'0', CAST(N'2018-07-24 11:07:49.193' AS DateTime), CAST(N'2018-07-24 11:07:49.193' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (552, NULL, N'Yadav,Manoj', NULL, N'0', CAST(N'2018-07-24 11:07:49.197' AS DateTime), CAST(N'2018-07-24 11:07:49.197' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (553, NULL, N'Yamani,Sesank', NULL, N'0', CAST(N'2018-07-24 11:07:49.200' AS DateTime), CAST(N'2018-07-24 11:07:49.200' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (554, NULL, N'Yazid,Muhammad', NULL, N'0', CAST(N'2018-07-24 11:07:49.207' AS DateTime), CAST(N'2018-07-24 11:07:49.207' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (555, NULL, N'Youngman,Josh', NULL, N'0', CAST(N'2018-07-24 11:07:49.210' AS DateTime), CAST(N'2018-07-24 11:07:49.210' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (556, NULL, N'Yuen,Lesley', NULL, N'0', CAST(N'2018-07-24 11:07:49.213' AS DateTime), CAST(N'2018-07-24 11:07:49.213' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (557, NULL, N'Zhang,Roger', NULL, N'0', CAST(N'2018-07-24 11:07:49.217' AS DateTime), CAST(N'2018-07-24 11:07:49.217' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (558, 1019174, N'Ganesh Purushothaman', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (559, 1004783, N'PALANI,KAMAL', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (560, 1020482, N'BALARAMSHEKHAR,P', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (561, 1020477, N'SHWETA,PATIL', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (562, 1010033, N'BAGALWADI,AJAY', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (563, 1014867, N'KARTHIK A', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (564, 1021375, N'TUSHAR, CHAVAN', NULL, N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (565, 1022223, N'AKASH, TUKKAR', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (566, 1022222, N'PRASHANT, PATIL', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (567, 1022221, N'VIKAS, ANANDAPATIL', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (568, 1015862, N'NOORASABA,BUDANSAB', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (569, 1022226, N'VIKAS, DADASAHEBPATIL', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
 GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (570, 2004712, N'SYED,HUSSAINI', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (571, 2004707, N'DHANASEKAR,S', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (572, 1010999, N'BHASKAR,JOSHI', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (573, 1021790, N'AKSHAY, KUMAR', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (574, 2005461, N'BARANI,M', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (575, 2005454, N'DUSHYANTH, MR', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (576, 2005458, N'ARCHANA, E', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (577, 2005456, N'MANJUNATH,M', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (578, 2005455, N'DINESHKUMAR, R', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (579, 2005492, N'ILAMATHI,P', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (580, 1021766, N'VENKATA,REDDY', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (581, 2005453, N'YAMINI,V', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (582, 2005490, N'UMAMAGESHWARI, ALAGU', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (583, 1021751, N'MOHANRAJ, M', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (584, 1016213, N'ABHIJITH,CS', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (585, 1022397, N'ABHISHEK, R', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (586, 2005457, N'KARTHIK,R', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (587, 2005456, N'MANJUNATH, M', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (588, 2005457, N'Gururaj,PN', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))
GO
INSERT [Edc].[ST_TV_Owner_Details] ([Id], [OracleId], [OwnerName], [Location], [Active], [CreateDate], [ModifiedDate]) VALUES (589, 2005456, N'Sanjay KV', N'Current User at offshore', N'1', CAST(N'2018-08-23 13:07:37.773' AS DateTime), CAST(N'2018-08-23 13:07:37.773' AS DateTime))

SET IDENTITY_INSERT [Edc].[ST_TV_Owner_Details] OFF
GO

/* [Edc].[ST_TV_Wide_Body_EngType_Certification] */

SET IDENTITY_INSERT [Edc].[ST_TV_Wide_Body_EngType_Certification] ON


INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (1,'TRENT','TRENT1000','TRENT1000','CS-E','CS-E original issue, dated 24 October 2003',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (2,'TRENT','TRENTXWB','TRENTXWB-84K','CS-E','CS-E amendment 2, effective 18 December 2009',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (3,'TRENT','TRENTXWB','TRENTXWB-97K','CS-E','CS-E amendment 3, effective 23 December 2010 ',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (4,'RB211','TRENT700','TRENT700','JAR-E','JAR-E, change 8, dated 4 May 1990 plus Orange Paper E/91/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (5,'RB211','TRENT500','TRENT500','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (6,'RB211','TRENT900','Trent970-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (7,'RB211','TRENT900','Trent970B-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (8,'RB211','TRENT900','Trent977-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (9,'RB211','TRENT900','Trent980-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (10,'RB211','TRENT900','Trent977B-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (11,'RB211','TRENT900','Trent 972-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (12,'RB211','TRENT900','Trent972B-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (13,'RB211','TRENT900','Trent972E-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (14,'RB211','RB211-22B','RB211-22B-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (15,'RB211','RB211-524','RB211-524-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (16,'RB211','RB211-524','RB211-524B-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (17,'RB211','RB211-524','RB211-524B-B-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (18,'RB211','RB211-524','RB211-524B2-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (19,'RB211','RB211-524','RB211-524B2-B-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (20,'RB211','RB211-524','RB211-524B2-39','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (21,'RB211','RB211-524','RB211-524B3-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (22,'RB211','RB211-524','RB211-524B4-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (23,'RB211','RB211-524','RB211-524B4-D-02','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (24,'RB211','RB211-524','RB211-524C2-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (25,'RB211','RB211-524','RB211-524C2-B-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (26,'RB211','RB211-524','RB211-524D4-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (27,'RB211','RB211-524','RB211-524D4-B-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (28,'RB211','RB211-524','RB211-524D4X-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (29,'RB211','RB211-524','RB211-524D4X-B-19','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (30,'RB211','RB211-524','RB211-524D4-39','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (31,'RB211','RB211-524','RB211-524D4-B-39','BCAR Section C','BCAR Section C, Issue 6, dated 15 June 1966 together with Blue Papers 415, 435, 436, 464, 468,
474, 476, 480, 481, 482, 499, 506, 544, 551 (para 3.2.2 only) and 554',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (32,'RB211','RB211-524','RB211-524G2-19','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (33,'RB211','RB211-524','RB211-524G2-T-19','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (34,'RB211','RB211-524','RB211-524G3-19','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (35,'RB211','RB211-524','RB211-524G3-T-19','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (36,'RB211','RB211-524','RB211-524H2-19','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (37,'RB211','RB211-524','RB211-524H2-T-19','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (38,'RB211','RB211-524','RB211-524H-36','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (39,'RB211','RB211-524','RB211-524H-T-36','JAR-E','JAR-E Change 6 dated 28 August 1981 (BCAR Section C iss 13), plus Blue Papers 792 and 831,
Airworthiness Notice 45A Issue 1 (Level 1 software). Exemption from Blue Paper 552.
Assumption Reports MDR 69417 Issue 2/ MDR 69507 Issue 1 and MDR 69563 issue 2 refer.',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (40,'RB211','TRENT800','TRENT800','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (41,'RB211','RB211-524','RB211-524D4','BCAR SECTION C','',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (42,'RB211','RB211-535','RB211-535C-37','BCAR SECTION C','',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (43,'RB211','RB211-535','RB211-535E4-37','JAR-E','',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (44,'RB211','RB211-535','RB211-535E4-B-37','JAR-E','',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (45,'RB211','RB211-535','RB211-535E4-B-75','JAR-E','',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (46,'RB211','RB211-535','RB211-535E4-C-37','JAR-E','',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (47,'RB211','TRENT500','TRENT553-61','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (48,'RB211','TRENT500','TRENT553A2-61','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (49,'RB211','TRENT500','TRENT556-61','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (50,'RB211','TRENT500','TRENT556A2-61','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (51,'RB211','TRENT500','TRENT556B-61','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (52,'RB211','TRENT500','TRENT560-61','JAR-E','JAR-E, change 9 plus Orange Papers E/96/1 and E/97/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (53,'RB211','TRENT700','TRENT768-60','JAR-E','JAR-E, change 8, dated 4 May 1990 plus Orange Paper E/91/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (54,'RB211','TRENT700','TRENT772-60','JAR-E','JAR-E, change 8, dated 4 May 1990 plus Orange Paper E/91/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (55,'RB211','TRENT700','TRENT772B-60','JAR-E','JAR-E, change 8, dated 4 May 1990 plus Orange Paper E/91/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (56,'RB211','TRENT700','TRENT772C-60','JAR-E','JAR-E, change 8, dated 4 May 1990 plus Orange Paper E/91/1',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (57,'RB211','TRENT800','TRENT875-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (58,'RB211','TRENT800','TRENT877-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (59,'RB211','TRENT800','TRENT884-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (60,'RB211','TRENT800','TRENT884B-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (61,'RB211','TRENT800','TRENT892-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (62,'RB211','TRENT800','TRENT892B-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (63,'RB211','TRENT800','TRENT895-17','JAR-E','JAR-E Change 8, dated 4 May 1990
Orange Paper E/91/1
',1,GETDATE(),GETDATE())

INSERT INTO [Edc].[ST_TV_Wide_Body_EngType_Certification](Id ,EngineType ,EngineSeries,Enginemark ,TvCertification ,CertificationBasis,Active,CreatedDate,ModifiedDate )
VALUES (64,'RB211','TRENT900','TRENT972-84','JAR-E','JAR-E, Amendment 11, dated 1 November 2001.
CS-E 800 (c) of CS-E Initial Issue, dated 24 October 2003, for Large
Flocking Bird Ingestion.
CS-E 580 (b) of CS-E Initial Issue, dated 24 October 2003, for Failure of
External Air Ducts.',1,GETDATE(),GETDATE())

SET IDENTITY_INSERT [Edc].[ST_TV_Wide_Body_EngType_Certification] Off


/*  [Edc].[ST_TV_Wide_Body_Manual_Ref]   */
GO
SET IDENTITY_INSERT [Edc].[ST_TV_Wide_Body_Manual_Ref] ON

 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (1,'TRENT','TRENT900','CHECK AND RECTIFY','CHECK & RECTIFY DATA','CR-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (2,'TRENT','TRENT900','CLEANING, INSPECTION AND REPAIR','CLEANING/INSPECTION & REPAIR DATA','CIR-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (3,'TRENT','TRENT900','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE - ELECTRICAL HARNESSES & CABLES','CM-EHC-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (4,'TRENT','TRENT900','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE - MISCELLANEOUS MECHANICAL','CM-MECH-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (5,'TRENT','TRENT900','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE - TUBES, HOSES & DUCTS','CM-THD-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (6,'TRENT','TRENT900','ENGINE','ENGINE DATA','E-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (7,'TRENT','TRENT900','ENGINE ILLUSTRATED PARTS CATELOGUE','ENGINE ILLUSTRATED PARTS DATA','S-T900-9RRA',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (8,'TRENT','TRENT900','ENGINE OVERHAUL PROCESS','ENGINE OVERHAUL PROCESSES','TSD-594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (9,'TRENT','TRENT900','OVERHAUL MATERIALS','OVERHAUL MATERIALS DATA','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (10,'TRENT','TRENT900','SERVICE BULLETIN','SERVICE BULLETIN INDEX FOR THE RB211-TRENT SERIES ENGINES','SER-IND-TRENT',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (11,'TRENT','TRENT900','STANDARD PRACTICES','STANDARD PRACTICES DATA','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (12,'TRENT','TRENT900','TIME LIMITS','TIME LIMITS DATA','T-TRENT-9RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (13,'TRENT','TRENT1000','CHECK AND RECTIFY','CHECK & RECTIFY MANUAL','CR-TRENT-10RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (14,'TRENT','TRENT1000','CLEANING, INSPECTION AND REPAIR','CLEANING/INSPECTION & REPAIR MANUAL','CIR-TRENT-10RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (15,'TRENT','TRENT1000','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE - ELECTRICAL HARNESSES & CABLES','EHC-TRENT-10RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (16,'TRENT','TRENT1000','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE - MISCELLANEOUS MECHANICAL','MECH-TRENT-10RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (17,'TRENT','TRENT1000','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE - TUBES, HOSES & DUCTS','THD-TRENT-10RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (18,'TRENT','TRENT1000','ENGINE','ENGINE MANUAL','E-TRENT-10RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (19,'TRENT','TRENT1000','ENGINE OVERHAUL PROCESS','ENGINE OVERHAUL PROCESSES','TSD-594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (20,'TRENT','TRENT1000','ENGINE ILLUSTRATED PARTS CATELOGUE','ILLUSTRATED PARTS DATA','S-T1000-10RRC',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (21,'TRENT','TRENT1000','OVERHAUL MATERIALS','OVERHAUL MATERIALS MANUAL','OMAT-OMAT-RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (22,'TRENT','TRENT1000','SERVICE BULLETIN','SERVICE BULLETIN INDEX FOR THE TRENT 1000 SERIES ENGINES','SER-IND-TRENT',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (23,'TRENT','TRENT1000','STANDARD PRACTICES','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (24,'TRENT','TRENT1000','TIME LIMITS','TIME LIMITS MANUAL','T-TRENT-10RRB',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (25,'TRENT','TRENT800','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES AND CABLES','CMM-EHC-TRENT-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (26,'TRENT','TRENT800','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','CMM-MECH-TRENT-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (27,'TRENT','TRENT800','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL TUBES, HOSES AND DUCTS','CMM-THD-TRENT-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (28,'TRENT','TRENT800','ENGINE ILLUSTRATED PARTS CATELOGUE','ENGINE ILLUSTRATED PARTS CATALOG','S-TRENT-B777',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (29,'TRENT','TRENT800','ENGINE','ENGINE MANUAL','E-TRENT-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (30,'TRENT','TRENT800','OVERHAUL MATERIALS','OVERHAUL MATERIALS MANUAL','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (31,'TRENT','TRENT800','ENGINE OVERHAUL PROCESS','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (32,'TRENT','TRENT800','SERVICE BULLETIN','SERVICE BULLETIN INDEX FOR THE RB211-TRENT SERIES ENGINES','SER-IND-TRENT',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (33,'TRENT','TRENT800','STANDARD PRACTICES','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (34,'TRENT','TRENT800','TIME LIMITS','TIME LIMITS MANUAL','T-TRENT-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (35,'TRENT','TRENT800','TIME LIMITS','TIME LIMITS MANUAL (TRENT 800)','T-TRENT-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (36,'TRENT','TRENT500','CHECK AND RECTIFY','CHECK AND RECTIFY','CR-TRENT-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (37,'TRENT','TRENT500','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES AND CABLES','CMM-EHC-TRENT-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (38,'TRENT','TRENT500','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','CMM-MECH-TRENT-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (39,'TRENT','TRENT500','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL TUBES, HOSES AND DUCTS','CMM-THD-TRENT-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (40,'TRENT','TRENT500','ENGINE ILLUSTRATED PARTS CATELOGUE','ENGINE ILLUSTRATED PARTS CATALOG','S-T500-5RRB',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (41,'TRENT','TRENT500','ENGINE','ENGINE MANUAL','E-TRENT-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (42,'TRENT','TRENT500','OVERHAUL MATERIALS','OVERHAUL MATERIALS MANUAL','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (43,'TRENT','TRENT500','ENGINE OVERHAUL PROCESS','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (44,'TRENT','TRENT500','SERVICE BULLETIN','SERVICE BULLETIN INDEX FOR THE RB211-TRENT SERIES ENGINES','SER-IND-TRENT',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (45,'TRENT','TRENT500','STANDARD PRACTICES','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (46,'TRENT','TRENT500','TIME LIMITS','TIME LIMITS MANUAL','T-TRENT-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (47,'TRENT','TRENT700','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES AND CABLES','CMM-EHC-TRENT-1RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (48,'TRENT','TRENT700','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','CMM-MECH-TRENT-1RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (49,'TRENT','TRENT700','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL TUBES, HOSES AND DUCTS','CMM-THD-TRENT-1RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (50,'TRENT','TRENT700','ENGINE ILLUSTRATED PARTS CATELOGUE','ENGINE ILLUSTRATED PARTS CATALOG','S-TRENT-AI',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (51,'TRENT','TRENT700','ENGINE','ENGINE MANUAL','E-TRENT-1RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (52,'TRENT','TRENT700','OVERHAUL MATERIALS','OVERHAUL MATERIALS MANUAL','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (53,'TRENT','TRENT700','ENGINE OVERHAUL PROCESS','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (54,'TRENT','TRENT700','SERVICE BULLETIN','SERVICE BULLETIN INDEX FOR THE RB211-TRENT SERIES ENGINES','SER-IND-TRENT',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (55,'TRENT','TRENT700','STANDARD PRACTICES','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (56,'TRENT','TRENT700','TIME LIMITS','TIME LIMITS MANUAL','T-TRENT-1RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (57,'RB211','RB211-22B','TIME LIMITS','TIME LIMITS MANUAL - LOCKHEED L1011 TRISTAR (RB211-22B)','T-211(22B)-1RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (58,'RB211','RB211-524','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','CMM-EH211(524)-3RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (59,'RB211','RB211-524','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL FUEL SPRAY NOZZLES','CMM-SN211(524)-3RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (60,'RB211','RB211-524','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL MISC. MECH.','CMM-MISC211(524)-3RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (61,'RB211','RB211-524','COMPONENT MAINTENANCE','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','CMM-TH211(524)-3RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (62,'RB211','RB211-524','ENGINE ILLUSTRATED PARTS CATELOGUE','ENGINE ILLUSTRATED PARTS CATALOG','S-211(524B4)-3RX',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (63,'RB211','RB211-524','ENGINE','ENGINE MANUAL','E-211(524)-3RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (64,'RB211','RB211-524','OVERHAUL MATERIALS','OVERHAUL MATERIALS MANUAL','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (65,'RB211','RB211-524','ENGINE OVERHAUL PROCESS','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (66,'RB211','RB211-524','SERVICE BULLETIN','SERVICE BULLETIN INDEX FOR THE RB211-22B/524 SERIES ENGINES','SER-IND-211(-22B/-524)',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (67,'RB211','RB211-524','STANDARD PRACTICES','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (68,'RB211','RB211-524','TIME LIMITS','TIME LIMITS MANUAL','T-211(524)-3RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (69,'RB211','RB211-524','TIME LIMITS','TIME LIMITS MANUAL - B747 CLASSIC','T-211(524)-2RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (70,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','CMM-EH211(535)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (71,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL FUEL SPRAY NOZZLES','COMPONENT MAINTENANCE MANUAL FUEL SPRAY NOZZLES','CMM-SN211(535)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (72,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL MISC. MECH. COMPONENTS','COMPONENT MAINTENANCE MANUAL MISC. MECH. COMPONENTS','CMM-MISC211(535)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (73,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','CMM-TH211(535)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (74,'RB211','RB211-535','ENGINE ILLUSTRATED PARTS CATALOG','ENGINE ILLUSTRATED PARTS CATALOG','S-211(535C)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (75,'RB211','RB211-535','ENGINE MANUAL','ENGINE MANUAL','E-211(535)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (76,'RB211','RB211-535','OVERHAUL MATERIALS MANUAL','OVERHAUL MATERIALS MANUAL','Omat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (77,'RB211','RB211-535','OVERHAUL PROCESSES MANUAL','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (78,'RB211','RB211-535','SERVICE BULLETIN INDEX FOR THE RB211-535 SERIES ENGINES','SERVICE BULLETIN INDEX FOR THE RB211-535 SERIES ENGINES','SER-IND-211(535)',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (79,'RB211','RB211-535','STANDARD PRACTICES MANUAL','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (80,'RB211','RB211-535','TIME LIMITS MANUAL','TIME LIMITS MANUAL','T-211(535)-5RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (81,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','CMM-EH211(535)-6RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (82,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','CMM-MISC211(535)-6RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (83,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','CMM-TH211(535)-6RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (84,'RB211','RB211-535','ENGINE ILLUSTRATED PARTS CATALOG','ENGINE ILLUSTRATED PARTS CATALOG','S-211(E410)-6US',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (85,'RB211','RB211-535','ENGINE MANUAL','ENGINE MANUAL','E-211(535)-6RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (86,'RB211','RB211-535','OVERHAUL MATERIALS MANUAL','OVERHAUL MATERIALS MANUAL','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (87,'RB211','RB211-535','OVERHAUL PROCESSES MANUAL','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (88,'RB211','RB211-535','SERVICE BULLETIN INDEX FOR THE RB211-535 SERIES ENGINES','SERVICE BULLETIN INDEX FOR THE RB211-535 SERIES ENGINES','SER-IND-211(535)',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (89,'RB211','RB211-535','STANDARD PRACTICES MANUAL','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (90,'RB211','RB211-535','TIME LIMITS MANUAL','TIME LIMITS MANUAL','T-211(535)-6RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (91,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','COMPONENT MAINTENANCE MANUAL ELECTRICAL HARNESSES','CMM-EH211(535)-4RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (92,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','COMPONENT MAINTENANCE MANUAL MISCELLANEOUS MECHANICAL','CMM-MISC211(535)-4RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (93,'RB211','RB211-535','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','COMPONENT MAINTENANCE MANUAL TUBES AND HOSES','CMM-TH211(535)-4RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (94,'RB211','RB211-535','ENGINE ILLUSTRATED PARTS CATALOG','ENGINE ILLUSTRATED PARTS CATALOG','S-211(E4B75)-4RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (95,'RB211','RB211-535','ENGINE MANUAL','ENGINE MANUAL','E-211(535)-4RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (96,'RB211','RB211-535','OVERHAUL MATERIALS MANUAL','OVERHAUL MATERIALS MANUAL','OMat',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (97,'RB211','RB211-535','OVERHAUL PROCESSES MANUAL','OVERHAUL PROCESSES MANUAL','TSD594-J',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (98,'RB211','RB211-535','SERVICE BULLETIN INDEX FOR THE RB211-535 SERIES ENGINES','SERVICE BULLETIN INDEX FOR THE RB211-535 SERIES ENGINES','SER-IND-211(535)',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (99,'RB211','RB211-535','STANDARD PRACTICES MANUAL','STANDARD PRACTICES MANUAL','RR-CAEL-SPM',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (100,'RB211','RB211-535','TIME LIMITS MANUAL','TIME LIMITS MANUAL','T-211(535)-4RR',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (101,'TRENT','TRENTWXB','ENGINE MANUAL','ENGINE MANUAL',' PMC-TRENTXWB-K0680-EMAN0-01',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (102,'TRENT','TRENTWXB','CLEANING, INSPECTION AND REPAIR MANUAL','CLEANING, INSPECTION AND REPAIR MANUAL',' PMC-TRENTXWB-K0680-CIRM0-01',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (103,'TRENT','TRENTWXB','CHECK AND RECTIFY MANUAL','CHECK AND RECTIFY MANUAL',' PMC-TRENTXWB-K0680-CREP0-01',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (104,'TRENT','TRENTWXB','TIME LIMITS MANUAL','TIME LIMITS MANUAL',' PMC-TRENTXWB-K0680-TIME0-01',1,GETDATE(),GETDATE())
 INSERT INTO [Edc].[ST_TV_Wide_Body_Manual_Ref] ([Id],[EngineType],[EngineSeries],[ManualTitle] ,[Publication] ,[PublicationReference] ,[Active],[CreatedDate] ,[ModifiedDate]) VALUES (105,'TRENT','TRENTWXB','SPLIT ENGINE TRANSPORTATION MANUAL','SPLIT ENGINE TRANSPORTATION MANUAL','PMC-TRENTXWB-K0680-SETM0-01',1,GETDATE(),GETDATE())

 SET IDENTITY_INSERT [Edc].[ST_TV_Wide_Body_Manual_Ref] OFF

 SET IDENTITY_INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ON 

GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (1, 1, N'WideBodyTV', N'WideBodyTV', N'OT_TV_Wide_Body_Data_Center', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2018-07-09 15:49:19.453' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (2, 2, N'RegionalBodyTV', N'RegionalBodyTV', N'OT_TV_Regional_Body_Data_Center', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2018-07-09 15:49:19.453' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (3, 3, N'Drawing', N'Drawing PartNumberSearch', N'OT_Hit_Log_Details', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2018-07-09 15:49:19.453' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (4, 4, N'Drawing Hit', N'Drawing', N'OT_Hit_Count_Utilisation', 1, CAST(N'2018-07-09 15:49:19.453' AS DateTime), CAST(N'2019-04-25 16:31:17.013' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (5, 5, N'ForumPassDelivery', N'ForumPassDelivery', N'OT_Hit_Log_Details', 1, CAST(N'2019-04-25 16:32:58.770' AS DateTime), CAST(N'2019-04-25 16:32:58.770' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (6, 6, N'CAReview', N'CAReview', N'OT_Hit_Log_Details', 1, CAST(N'2019-04-26 13:09:57.550' AS DateTime), CAST(N'2019-04-26 13:09:57.550' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (7, 7, N'SAR Search', N'SAR Search', N'OT_Hit_Log_Details', 1, CAST(N'2019-04-29 11:14:41.110' AS DateTime), CAST(N'2019-04-29 11:14:41.110' AS DateTime))
GO
INSERT [dbo].[ST_Hit_Count_Table_Name_Details] ([Id], [ObjectCode], [ObjectName], [ObjectPageName], [ObjectTableName], [Active], [CreatedDate], [ModifiedDate]) VALUES (8, 8, N'EDC Search', N'EDC Search', N'OT_Hit_Count_Utilisation', 1, CAST(N'2019-04-29 14:41:49.723' AS DateTime), CAST(N'2019-04-29 14:41:49.723' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[ST_Hit_Count_Table_Name_Details] OFF


/*****************************ST_Template_Section_Details *************************************/
GO
INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (1,'Leading edge erosion on IPC Stage 1 Blades','Existing Requirement',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (2,'Leading edge erosion on IPC Stage 1 Blades','Requested Variance',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (3,'Leading edge erosion on IPC Stage 1 Blades','Summary of Investigation',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (4,'Leading edge erosion on IPC Stage 1 Blades','Specialist Concurrence',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (5,'Undersize/oversize seal fins on HPT Disc air seal fins','Existing Requirement',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (6,'Undersize/oversize seal fins on HPT Disc air seal fins','Requested Variance',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (7,'Undersize/oversize seal fins on HPT Disc air seal fins','Summary of Investigation',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (8,'Undersize/oversize seal fins on HPT Disc air seal fins','Specialist Concurrence',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (9,'IPC Blades tip grinding','Existing Requirement',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (10,'IPC Blades tip grinding','Requested Variance',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (11,'IPC Blades tip grinding','Summary of Investigation',1,GETDATE())

INSERT [TSection].[ST_Template_Section_Details] ([Id], [TemplateName], [SectionName], [Active],[CreatedDate]) 
VALUES (12,'IPC Blades tip grinding','Specialist Concurrence',1,GETDATE())






