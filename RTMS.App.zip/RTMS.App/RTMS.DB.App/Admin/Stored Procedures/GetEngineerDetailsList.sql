﻿
-- =============================================
-- Author:		<Neethu>
-- Create date: <12/6/2018>
-- Description:	<Engineer List>
-- ============================================= 

CREATE PROCEDURE [Admin].[GetEngineerDetailsList] 
       -- Add the parameters for the stored procedure here
@flag nvarchar(50)
AS
BEGIN
       -- SET NOCOUNT ON added to prevent extra result sets from
       -- interfering with SELECT statements.
       SET NOCOUNT ON;
 
    -- Insert statements for procedure here
       IF(@flag='Engineer')
       BEGIN
              SELECT 
                           ow.Id        AS Id,
                           ow.OwnerName AS UserName                 
                     FROM [Edc].[ST_TV_Owner_Details] ow 
					 INNER JOIN [Admin].[ST_Users] u             ON ow.OracleId=u.UserId
                     INNER JOIN [Admin].[ST_User_Role_Module] ur ON ur.UserId=u.Id
                     WHERE  ow.Active=1  
					 AND     u.Active=1 
					 AND    ur.RoleId=31 
					 OR     ur.RoleId=26 
					 OR     ur.RoleId=21 
					 ORDER BY OwnerName ASC
       END
 
       ELSE IF(@flag='CompetentAuthor')
       BEGIN
              SELECT 
                           ow.Id        AS Id,
                           ow.OwnerName AS UserName                 
                     FROM [Edc].[ST_TV_Owner_Details] ow 
					 INNER JOIN [Admin].[ST_Users] u             ON ow.OracleId=u.UserId
                     INNER JOIN [Admin].[ST_User_Role_Module] ur ON ur.UserId=u.Id
                     WHERE  ow.Active=1  
					 AND     u.Active=1 
					 AND    ur.RoleId=26 
					 OR     ur.RoleId=21  
					 ORDER BY OwnerName ASC
       END
       
END
