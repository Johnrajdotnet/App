﻿/****** Object:  Synonym [Admin].[Syn_ST_Task_Details]    Script Date: 3/7/2019 10:38:58 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Task_Details] FOR [RTMS.Core].[Admin].[ST_Task_Details]
GO

