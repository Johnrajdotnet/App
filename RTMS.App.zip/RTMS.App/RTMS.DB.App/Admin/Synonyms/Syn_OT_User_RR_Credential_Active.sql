﻿
/****** Object:  Synonym [Admin].[Syn_OT_User_RR_Credential_Active]    Script Date: 3/7/2019 10:34:38 AM ******/
CREATE SYNONYM [Admin].[Syn_OT_User_RR_Credential_Active] FOR [RTMS.Core].[Admin].[OT_User_RR_Credential_Active]
GO


