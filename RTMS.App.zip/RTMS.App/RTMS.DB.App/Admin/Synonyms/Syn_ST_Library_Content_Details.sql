﻿/****** Object:  Synonym [Admin].[Syn_ST_Library_Content_Details]    Script Date: 3/7/2019 10:36:30 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Library_Content_Details] FOR [RTMS.Core].[Admin].[ST_Library_Content_Details]
GO
