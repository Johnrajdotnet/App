﻿/****** Object:  Synonym [Admin].[Syn_ST_Users]    Script Date: 3/7/2019 10:40:59 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Users] FOR [RTMS.Core].[Admin].[ST_Users]