﻿/****** Object:  Synonym [Admin].[Syn_ST_User_Role_Module]    Script Date: 3/7/2019 10:39:35 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_User_Role_Module] FOR [RTMS.Core].[Admin].[ST_User_Role_Module]
GO
