﻿/****** Object:  Synonym [Admin].[Syn_ST_Business_Module]    Script Date: 3/7/2019 10:35:47 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Business_Module] FOR [RTMS.Core].[Admin].[ST_Business_Module]
GO


