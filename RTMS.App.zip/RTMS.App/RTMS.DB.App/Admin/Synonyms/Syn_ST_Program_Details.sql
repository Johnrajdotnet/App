﻿/****** Object:  Synonym [Admin].[Syn_ST_Program_Details]    Script Date: 3/7/2019 10:37:07 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Program_Details] FOR [RTMS.Core].[Admin].[ST_Program_Details]
GO


