﻿/****** Object:  Synonym [Admin].[Syn_ST_Roles]    Script Date: 3/7/2019 10:38:13 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Roles] FOR [RTMS.Core].[Admin].[ST_Roles]
GO

