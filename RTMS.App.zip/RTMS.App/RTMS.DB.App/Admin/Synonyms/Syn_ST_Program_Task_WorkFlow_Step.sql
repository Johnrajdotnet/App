﻿/****** Object:  Synonym [Admin].[Syn_ST_Program_Task_WorkFlow_Step]    Script Date: 3/7/2019 10:37:37 AM ******/
CREATE SYNONYM [Admin].[Syn_ST_Program_Task_WorkFlow_Step] FOR [RTMS.Core].[Admin].[ST_Program_Task_WorkFlow_Step]
GO


