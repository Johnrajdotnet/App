﻿
	-- =============================================
	-- Author:           <Mira Kumari>
	-- Create date:		 <19/09/2018>
	-- Description:      < Is Headsup Decision Available>
	-- exec [dbo].[IsHeadsupDecisionAvailable] ''
	-- =============================================
	CREATE FUNCTION [dbo].[IsHeadsupDecisionAvailable](@TVNumber bigint)
	RETURNS bit   
	AS   
	BEGIN  
		DECLARE      @IsHeadsupDecision bit=0
		SELECT  
					 @IsHeadsupDecision = 1
		FROM         [Edc].[OT_TV_Wide_Body_Data_Center] dc
		INNER JOIN   [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON ac.TVDataCenterId=dc.Id   
		WHERE        dc.TVNumber=@TVNumber
					 AND dc.HeadsupDate is not null 
					 AND dc.HeadsupDecision is not null
		RETURN       @IsHeadsupDecision;  
	END
