﻿-- =============================================
-- Author:           ARATHY
-- Create date: 25/10/2017
-- Description:      Get Engineer id by USERID
--print [dbo].[GetOwnerIdByUserId](56)
-- =============================================
CREATE FUNCTION [dbo].[GetOwnerIdByUserId] 
(
       -- Add the parameters for the function here
       @id int
)
RETURNS int
AS
BEGIN
       -- Declare the return variable here
       DECLARE @OwnerId INT

       -- Add the T-SQL statements to compute the return value here
      
						SELECT @OwnerId= ow.Id                             
						FROM [Edc].[ST_TV_Owner_Details] ow  
						INNER JOIN [Admin].[Syn_ST_Users] u ON u.UserId=ow.OracleId
						WHERE u.Id=@id
						AND u.Active=1
						AND ow.Active=1
						

       -- Return the result of the function
       RETURN @OwnerId

END



