﻿
-- =============================================
--FUNCTION: [[Edc].[GetCountOfDownloadTVDocuments]
--PURPOSE: return new Folder Version
--CREATED: Blessy Babu 4/01/2019
-- ============================================= 
-- select * from [Edc].[GetCountOfDownloadTVDocuments] (4)

CREATE FUNCTION  [Edc].[GetCountOfDownloadTVDocuments]
(
	-- Add the parameters for the function here
	@machineIndex int
)
 RETURNS @edcTVDownload TABLE
		(
			Id INT IDENTITY(1, 1)PRIMARY KEY,
			ActionName nvarchar(max),
			DownloadYesterday INT,
			TotalCount int,
			TotalDownload int,
			DownloadToday int,
			AvgDownload   int,
			FaultCount int
		 
		)
AS
BEGIN
	-- Declare the return variable here
	 

        DECLARE @count INT,@totalCountOfRecords INT,@completedDownload int,@downloadYesterday int,@avrgDownload int,@faultCount int
-----------------------------------------------download today----------------------------------
        SET  @count = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] do
		INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
	    WHERE Active=1 
		and machineIndex=@machineIndex
		and CONVERT(nvarchar(10),do.ModifiedDate,112)=CONVERT(nvarchar(10),GETDATE(),112) 
		AND  (dc.EngineMark  LIKE '%'+'t10'+'%'  OR  dc.EngineMark  LIKE '%'+'t9'+'%' ))
-------------------------------------------------Total Count--------------------------------------
		SET  @totalCountOfRecords = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details]  do
		INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
		WHERE machineIndex=@machineIndex
		AND  (dc.EngineMark  LIKE '%'+'t10'+'%'  OR  dc.EngineMark  LIKE '%'+'t9'+'%' ) )
---------------------------------------------------Completed download as of now-------------------
		SET  @completedDownload = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] do
		INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
		 WHERE machineIndex=@machineIndex
		 and active=1 
		 AND  (dc.EngineMark  LIKE '%'+'t10'+'%'  OR  dc.EngineMark  LIKE '%'+'t9'+'%' ) )
---------------------------------------------------Download yesterday-----------------------------
		SET @downloadYesterday= (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] do
		INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
		WHERE Active=1 
		and machineIndex=@machineIndex
		and CONVERT(nvarchar(10),do.ModifiedDate,112) =CONVERT(nvarchar(10),GETDATE()-1,112) 
		AND  (dc.EngineMark  LIKE '%'+'t10'+'%'  OR  dc.EngineMark  LIKE '%'+'t9'+'%' )  )
		
		---------------------------------------------------Average download-----------------------------
	--	SET @avrgDownload= (@totalCountOfRecords-@completedDownload)/(@downloadYesterday-@count)
		
		--------------------------------------------------Fault TV Number Count-------------------------

		SET @faultCount =(SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] do
		INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
		WHERE Active=0
		and machineIndex=@machineIndex
		AND IterationCount < 3
		AND  (dc.EngineMark  LIKE '%'+'t10'+'%'  OR  dc.EngineMark  LIKE '%'+'t9'+'%' )  )
-------------------------------------------------------------------------------------------------------
		
		INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount)--,AvgDownload)
		SELECT  'Machine'+''+CONVERT(nvarchar(50),@machineIndex),@downloadYesterday,@totalCountOfRecords,@completedDownload,@count,@faultCount--,@avrgDownload
		
	-- Return the result of the function
	RETURN   

END

