﻿-- =============================================
-- Author:		<Blessy Babu>
-- Create date: <17-10-18>
-- Description:	<Get concatenated EngineMarks by RedTopReference>
-- =============================================
CREATE FUNCTION [dbo].[GetRedTopConcatenateEngineMark] 
(
	-- Add the parameters for the function here
	@RedTopReference nvarchar(20)
)
RETURNS NVARCHAR(200)
AS
BEGIN
	  DECLARE @EngineMarks VARCHAR(500)
	 
	  SELECT 
			@EngineMarks = COALESCE(@EngineMarks + ',', '') + CAST(EngineMark AS VARCHAR(MAX))
      FROM 
			[Edc].[OT_TV_Wide_Body_RedTop_Applicable_Center]
	  WHERE 
			RedTopReference=@RedTopReference AND IsApplicable=1
	
	 RETURN @EngineMarks

END

