﻿
-- =============================================
-- Author:           <Neethu Rose Peter>
-- Create date: 31 October 2018
-- Description: Return TV Status from flag
-- [dbo].[GetTVStatusByFlag]  's2||gsdfd','StatusId'
-- =============================================
CREATE FUNCTION [dbo].[GetTVStatusByFlag] 
(
       -- Add the parameters for the function here       
	   @RCIComment nvarchar(MAX),
       @flag   nvarchar(50)   
)
RETURNS VARCHAR(250)
AS
BEGIN
  DECLARE @tvSTatus nvarchar(100)
  DECLARE @statusCode nvarchar(10)
   
		SET @statusCode=(SELECT top 1 Item from  [dbo].[StringToTableValue](@RCIComment,'|')  WHERE UPPER(Item) LIKE 'S[0-9][0-9]')

		IF(@statusCode IS NULL)
			begin
			SET @statusCode=(SELECT top 1 Item from  [dbo].[StringToTableValue](@RCIComment,'|')  WHERE UPPER(Item) LIKE 'S[0-9]')
			end

		IF(@flag='StatusId')
		BEGIN 
			SET @tvSTatus=(SELECT Id FROM [Report].[ST_Edc_Wip_Status_Details] WHERE StatusCode=ISNULL(@statusCode,'S100'))
		END
		ELSE IF(@flag='StatusCategory')
		BEGIN 
			SET @tvSTatus=(SELECT StatusCategory FROM [Report].[ST_Edc_Wip_Status_Details] WHERE StatusCode=ISNULL(@statusCode,'S100'))
		END
		ELSE IF(@flag='StatusTitle')
		BEGIN
			SET @tvSTatus=(SELECT StatusTitle FROM [Report].[ST_Edc_Wip_Status_Details] WHERE StatusCode=ISNULL(@statusCode,'S100'))
		END
		ELSE IF(@flag='StatusDescription')
		BEGIN
			SET @tvSTatus=(SELECT StatusDescription FROM [Report].[ST_Edc_Wip_Status_Details] WHERE StatusCode=ISNULL(@statusCode,'S100'))
		END 
		ELSE IF(@flag='Status')
		BEGIN
			SET @tvSTatus=(SELECT Status FROM [Report].[ST_Edc_Wip_Status_Details] WHERE StatusCode=ISNULL(@statusCode,'S100'))
		END 
		ELSE IF(@flag='Location')
		BEGIN
			SET @tvSTatus=(SELECT Location FROM [Report].[ST_Edc_Wip_Status_Details] WHERE StatusCode=ISNULL(@statusCode,'S100'))
		END
  
  RETURN @tvSTatus   
END






