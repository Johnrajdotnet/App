﻿-- =============================================
-- Author:		John Raj
-- Create date: 24/07/2018
-- 
--select [dbo].[GetTotalAgeInDays] (GETDATE())
-- =============================================
CREATE FUNCTION [dbo].[GetTotalAgeInDays]
(
	-- Add the parameters for the function here
	@StartDate Datetime
)
RETURNS VARCHAR(250)
AS
BEGIN
	-- Total seconds in a day

DECLARE @TotalSec int
DECLARE @DiffSecs int
SET @TotalSec = 24*60*60; 

-- Convert DateDiff into seconds

SET @DiffSecs = DATEDIFF(SECOND, @StartDate, GETDATE()) 

--Declare @days int,@Hours int,@minutes int,@difference nvarchar(200)
Declare @days nvarchar(20),@Hours nvarchar(20),@minutes nvarchar(20),@difference nvarchar(200)
Set @days = CONVERT(char(10), (@DiffSecs/@TotalSec))
Set @Hours =CONVERT(char(2), ((@DiffSecs%@TotalSec)/3600))
Set @minutes =CONVERT(char(2), (((@DiffSecs%@TotalSec)%3600)/60))


--Set @difference= CONCAT ( @days,'Days',' ',@Hours,'Hrs',' ',@minutes,'Min')  
Set @difference= @days + 'Days' 
    RETURN @difference

END
