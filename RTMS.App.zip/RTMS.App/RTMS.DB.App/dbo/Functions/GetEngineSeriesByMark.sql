﻿
-- =============================================
-- Author:           ARATHY
-- Create date: 25/10/2017
-- Description:      Get Engineer full name by role Guid
--print [dbo].[GetEngineSeriesByMark] ('TRENT 882B-60')
-- =============================================
CREATE FUNCTION [dbo].[GetEngineSeriesByMark] 
(
       -- Add the parameters for the function here
       @engineMark NVARCHAR(10)
)
RETURNS NVARCHAR(10)
AS
BEGIN
       -- Declare the return variable here
       DECLARE @engineSeries NVARCHAR(10)

       -- Add the T-SQL statements to compute the return value here

	   IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%t5%')
	   BEGIN
		SET	@engineSeries='TRENT500'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%t7%' )
	   BEGIN
		SET	@engineSeries='TRENT700'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%t8%' )
	   BEGIN
		SET	@engineSeries='TRENT800'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%t9%' )
	   BEGIN
		SET	@engineSeries='TRENT900'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%t1%' )
	   BEGIN
		SET	@engineSeries='TRENT1000'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%xwb%' )
	   BEGIN
		SET	@engineSeries='TRENTXWB'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%524%' )
	   BEGIN
		SET	@engineSeries='RB211-524'
	   END
	   ELSE IF(LOWER(REPLACE(@engineMark,' ','')) LIKE '%535%' )
	   BEGIN
		SET	@engineSeries='RB211-535'
	   END
	   
       -- Return the result of the function
       RETURN @engineSeries

END




