

-- =============================================
-- Author:           John Raj
-- Create date: 25/10/2017
-- Description:      Get Engineer full name by role Guid
-- =============================================
CREATE FUNCTION [dbo].[GetOwnerNameById] 
(
       -- Add the parameters for the function here
       @id int
)
RETURNS NVARCHAR(200)
AS
BEGIN
       -- Declare the return variable here
       DECLARE @OwnerName NVARCHAR(200)

       -- Add the T-SQL statements to compute the return value here
       SELECT @OwnerName = OwnerName FROM [Edc].[ST_TV_Owner_Details]
       WHERE Id=@id AND Active=1

       -- Return the result of the function
       RETURN @OwnerName

END



