﻿-- =============================================
-- Author:           <john raj>
-- Create date: <25/04/2018>
-- Description:      <Description, ,>
-- =============================================
CREATE FUNCTION dbo.GetTVRegisterAttribute
(
       -- Add the parameters for the function here
       @attributeValue nvarchar(50),
       @attributeGroupId INT

)
RETURNS VARCHAR(250)
AS
BEGIN
       -- Declare the return variable here
       DECLARE @attributeName nvarchar(50)='-'

       -- Add the T-SQL statements to compute the return value here
       SELECT 
              @attributeName= AttributeName 
       FROM 
              [Edc].[ST_TV_Register_Attribute]
       WHERE
              AttributeGroupId=@attributeGroupId
              AND AttributeValue=@attributeValue

       -- Return the result of the function
       RETURN @attributeName

END
GO
