﻿

-- =============================================
-- Author:           arathy
-- Create date: 25/10/2017
-- Description:      Get Engineer full name by role Guid
-- =============================================
CREATE FUNCTION [dbo].[GetOwnerNameByUserRoleId] 
(
       -- Add the parameters for the function here
       @userRoleId uniqueidentifier
)
RETURNS NVARCHAR(200)
AS
BEGIN
       -- Declare the return variable here
       DECLARE @OwnerName NVARCHAR(200)

       -- Add the T-SQL statements to compute the return value here
       SELECT @OwnerName =  u.[FirstName]+ ' ' +u.[LastName] 
	   FROM   [Admin].[Syn_ST_Users]	 u
	   INNER JOIN [Admin].[Syn_ST_User_Role_Module] rm on u.id=rm.userId
	   WHERE  rm.Id=@userRoleId

       -- Return the result of the function
       RETURN @OwnerName

END

