﻿-- =============================================
-- Author:           <neethu>
-- Create date: <25/04/2018>
-- Description:      <Description, ,>
-- ============================================= [dbo].[GetTVRegisterAttributeValue] 'Bangalore',26
CREATE FUNCTION [dbo].[GetTVRegisterAttributeValue]
(
       -- Add the parameters for the function here
       @attributeName nvarchar(50),
       @attributeGroupId INT

)
RETURNS VARCHAR(250)
AS
BEGIN
       -- Declare the return variable here
       DECLARE @attributeValue nvarchar(50)='-'

       -- Add the T-SQL statements to compute the return value here
       SELECT 
              @attributeValue= AttributeValue 
       FROM 
              [Edc].[ST_TV_Register_Attribute]
       WHERE
              AttributeGroupId=@attributeGroupId
              AND AttributeName=@attributeName

       -- Return the result of the function
       RETURN @attributeValue

END