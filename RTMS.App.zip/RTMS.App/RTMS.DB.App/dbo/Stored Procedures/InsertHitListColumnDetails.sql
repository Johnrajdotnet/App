﻿
  -- =============================================
--PURPOSE: update HitCount in  [dbo].[ST_Hit_Count_Column_Name_Details]
--CREATED: Neethu rose peter 
-- ============================================= EXEC [dbo].[InsertHitListColumnDetails] 3,'UserName,PartNumber,Description',',D57133404001, ','d227e7ad-5d46-47ae-9ca9-7560055207cb'
CREATE PROCEDURE [dbo].[InsertHitListColumnDetails]
@tableId        int,
@columnName     nvarchar(250),  
@columnValue    nvarchar(250),
@createdBy      uniqueidentifier 
AS

DECLARE @maxTransId int
DECLARE @currentTransactionId int

BEGIN TRY

SELECT @maxTransId=  isnull(max(CurrentTransactionId),0) FROM [dbo].OT_Hit_Count_Column_Name_Details WHERE TableId=@tableId

SET @currentTransactionId=@maxTransId+1


                  
              INSERT INTO [dbo].[OT_Hit_Count_Column_Name_Details]
                     (
                     TableId,
                     CurrentTransactionId,
                     ColumnName,
                     ColumnValue,
                     CreatedDate,
					 CreatedBy
                     )
              SELECT @tableId
					,@currentTransactionId
                    ,col.Item
					,val.Item
                    ,GETDATE()
					,@createdBy
              FROM dbo.StringToTableValueWithIdentity(@columnName, ',') col
              INNER JOIN dbo.StringToTableValueWithIdentity(@columnValue, ',') val
              ON val.Id =col.Id
         
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
