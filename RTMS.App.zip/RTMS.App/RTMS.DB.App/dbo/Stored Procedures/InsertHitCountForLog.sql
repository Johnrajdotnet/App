﻿
-- =============================================
-- Author:           <Arathy Jayakumar>
-- Create date:		 <04/25/2019>
-- Description:      <Insert hit count details for utilisation>
-- exec [dbo].[InsertHitCountForLog] 
-- =============================================
CREATE PROCEDURE [dbo].[InsertHitCountForLog]
@tableId        int,
@createdBy      uniqueidentifier ,
@attributeName  nvarchar(max),
@attributeValue nvarchar(50),
@comments		nvarchar(50)
AS

DECLARE @maxTransId int
DECLARE @currentTransactionId int

BEGIN TRY

SELECT @maxTransId=  isnull(max([TransactionGroupId]),0) FROM [dbo].[OT_TV_WBody_WFlow_Hit_Log_Details] WHERE [HitObjectId]=@tableId

SET @currentTransactionId=@maxTransId+1


                  
              INSERT INTO [dbo].[OT_TV_WBody_WFlow_Hit_Log_Details]
                     (
                     [HitObjectId],
                     [TransactionGroupId],
					 [AttributeName],
					 [AttributeValue],
					 [Comment],
                     CreatedDate,
					 CreatedBy
                     )
              VALUES
					(@tableId
					,@currentTransactionId
					,@attributeName
					,@attributeValue
					,@comments
                    ,GETDATE()
					,@createdBy
					)
             
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

