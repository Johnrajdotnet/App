﻿-- =============================================
-- Author:           <Blessy>
-- Create date:		 <17/06/2019>
-- Description:      <Get Service Details >
-- exec [dbo].[GetInitServiceDetails]
CREATE PROCEDURE [dbo].[GetInitServiceDetails]
@ServiceId INT
AS
BEGIN

     SELECT       
	           [Id]                   AS Id,
	           [ServiceName]          As ServiceName,
	           [OnStartTime]          AS OnStartTime,
	           [OnStopTime]           AS OnStopTime,
	           [OnStopStatus]         AS OnStopStatus,
	           [JobStartDate]         AS JobStartDate,
	           [JobEndDate]           AS JobEndDate,
	           [JobStatus]            AS JobStatus

	  FROM [dbo].[OT_Init_Service_Details]

	  WHERE Id=@ServiceId
END

