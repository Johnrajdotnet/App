﻿


-- =============================================
-- Author:    Arathy       
-- Create date:		 <04/25/2019>
-- Description:      <Insert hit count details for utilisation>
-- exec [dbo].[GetHitCountUtilisationDetails] 'ForumPassDelivery','2019-05-10','2019-05-20'
-- =============================================
CREATE PROCEDURE [dbo].[GetHitCountUtilisationDetails] 
@flag	  NVARCHAR(50),
@fromDate DATETIME,
@toDate   DATETIME
AS
BEGIN TRY
DECLARE @avgTimeforDrawing INT, @avgTimeforEdcSearch INT, @avgTimeforSARRedtop INT, @avgTimeforTvDelivery INT, @avgTimeforCAReject INT
SET @avgTimeforDrawing=5
SET @avgTimeforEdcSearch=5
SET @avgTimeforSARRedtop=5
SET @avgTimeforTvDelivery=30
SET @avgTimeforCAReject=10

IF(@flag='Drawing Hit')
      BEGIN
		
			SELECT hc.ObjectCode as ObjectCode,[dbo].[GetOwnerNameByUserRoleId](hu.CreatedBy) as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforDrawing as EffortSaved  FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId	
			WHERE 
			hc.ObjectName=@flag 
			AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
		--	AND (hu.CreatedDate>=@fromDate AND hu.CreatedDate<=@toDate)
			GROUP BY hc.ObjectCode,hu.CreatedBy 

			UNION
					
			SELECT hc.ObjectCode as ObjectCode,'ALL' as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforDrawing as EffortSaved  FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId			
			WHERE 
			hc.ObjectName=@flag
			AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
		    GROUP BY hc.ObjectCode
	  END
IF(@flag='EDC Search')
      BEGIN
		SELECT hc.ObjectCode as ObjectCode,[dbo].[GetOwnerNameByUserRoleId](hu.CreatedBy) as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforEdcSearch as EffortSaved  FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId	
			WHERE 
			hc.ObjectName=@flag 
			AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
		    GROUP BY hc.ObjectCode,hu.CreatedBy 

			UNION
					
			SELECT hc.ObjectCode as ObjectCode,'ALL' as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforEdcSearch as EffortSaved  FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId			
			WHERE 
			hc.ObjectName=@flag
			AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
		    GROUP BY hc.ObjectCode
	  END	  
IF(@flag='SAR Search')
      BEGIN
		SELECT hc.ObjectCode as ObjectCode,[dbo].[GetOwnerNameByUserRoleId](hu.CreatedBy) as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforSARRedtop as EffortSaved  FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId	
			WHERE 
			hc.ObjectName=@flag 
			AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
		    GROUP BY hc.ObjectCode,hu.CreatedBy 

			UNION
					
			SELECT hc.ObjectCode as ObjectCode,'ALL' as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforSARRedtop as EffortSaved  FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId			
			WHERE 
			hc.ObjectName=@flag
			AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
			GROUP BY hc.ObjectCode
	  END	  
IF(@flag='ForumPassDelivery')
      BEGIN
			SELECT hc.ObjectCode as ObjectCode,[dbo].[GetOwnerNameByUserRoleId](hu.CreatedBy) as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforTvDelivery as EffortSaved,hu.Comment as Comment
		
			FROM [dbo].OT_TV_WBody_WFlow_Hit_Log_Details hu
				INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId	
			WHERE 
				hc.ObjectName=@flag 
				AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
     			GROUP BY hc.ObjectCode,hu.CreatedBy,hu.Comment

			UNION
					
			SELECT hc.ObjectCode as ObjectCode,'ALL' as CreatedBy,COUNT(1) as HitCount,COUNT(1)*@avgTimeforTvDelivery as EffortSaved ,hu.Comment as Comment
		    FROM [dbo].OT_TV_WBody_WFlow_Hit_Log_Details hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId			
			WHERE 
				hc.ObjectName=@flag 
				AND (CONVERT(nvarchar(10),hu.CreatedDate,112)>= CONVERT(nvarchar(10),@fromDate,112) AND CONVERT(nvarchar(10),hu.CreatedDate,112)<=CONVERT(nvarchar(10),@toDate,112))
			    GROUP BY hc.ObjectCode,hu.Comment


	  END	  	
IF(@flag='CAReview')
      BEGIN
			SELECT hc.ObjectCode as ObjectCode,[dbo].[GetOwnerNameByUserRoleId](hu.CreatedBy) as CreatedBy,COUNT(1) as HitCount,COUNT(1)*5 as EffortSaved,hu.Comment,(hu.AttributeName+ '' + hu.AttributeValue) as AttributeValue
		
			FROM [dbo].OT_TV_WBody_WFlow_Hit_Log_Details hu
				INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId	
			WHERE 
				hc.ObjectName=@flag 
				AND (hu.CreatedDate>= CONVERT(nvarchar(10),@fromDate,112) AND hu.CreatedDate<=CONVERT(nvarchar(10),@toDate,112))
			GROUP BY hc.ObjectCode,hu.CreatedBy,hu.Comment,hu.AttributeName,hu.AttributeValue

			UNION
					
			SELECT hc.ObjectCode as ObjectCode,'ALL' as CreatedBy,COUNT(1) as HitCount,COUNT(1)*5 as EffortSaved,hu.Comment,(hu.AttributeName+ '' + hu.AttributeValue) as AttributeValue
			FROM [dbo].OT_TV_WBody_WFlow_Hit_Log_Details hu
			INNER JOIN  [dbo].[ST_Hit_Count_Table_Name_Details] hc ON hc.Id=hu.HitObjectId			
			WHERE 
			hc.ObjectName=@flag
			AND (hu.CreatedDate>= CONVERT(nvarchar(10),@fromDate,112) AND hu.CreatedDate<=CONVERT(nvarchar(10),@toDate,112))
			GROUP BY hc.ObjectCode,hu.CreatedBy,hu.Comment,hu.AttributeName,hu.AttributeValue
	  END	        
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH






