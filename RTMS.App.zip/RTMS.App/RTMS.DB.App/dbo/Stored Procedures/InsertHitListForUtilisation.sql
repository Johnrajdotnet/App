﻿
-- =============================================
-- Author:           <Arathy Jayakumar>
-- Create date:		 <04/25/2019>
-- Description:      <Insert hit count details for utilisation>
-- exec [dbo].[InsertHitListForUtilisation] 
-- =============================================
CREATE PROCEDURE [dbo].[InsertHitListForUtilisation]
@tableId        int,
@createdBy      uniqueidentifier ,
@flag			nvarchar
AS

DECLARE @maxTransId int
DECLARE @currentTransactionId int

BEGIN TRY

SELECT @maxTransId=  isnull(max([TransactionGroupId]),0) FROM [dbo].[OT_TV_WBody_Hit_Count_Utilisation] WHERE [HitObjectId]=@tableId

SET @currentTransactionId=@maxTransId+1


                  
              INSERT INTO [dbo].[OT_TV_WBody_Hit_Count_Utilisation]
                     (
                     [HitObjectId],
                     [TransactionGroupId],
                     CreatedDate,
					 CreatedBy
                     )
              VALUES
					(@tableId
					,@currentTransactionId
                    ,GETDATE()
					,@createdBy
					)
             
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

