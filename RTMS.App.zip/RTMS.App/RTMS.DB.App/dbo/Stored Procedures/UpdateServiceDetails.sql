﻿-- =============================================
--PROCEDURE: [dbo].[UpdateServiceDetails]
--PURPOSE: Update the service informations
--CREATED BY: Blessy 
--CREATED DATE :17/6/2019
-- ============================================= 
-- EXEC [dbo].[UpdateServiceDetails] 3,'OnStartTime','917614D4-E741-432D-BBF4-A3C6E4546129'

CREATE PROCEDURE [dbo].[UpdateServiceDetails]
	-- Add the parameters for the stored procedure here
	@serviceId           INT,
	@flag                NVARCHAR(100),
	@userId              UNIQUEIDENTIFIER
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY

	   IF(@flag ='OnStartTime') --OnStartTime
	   BEGIN
			UPDATE [dbo].[OT_Init_Service_Details]
			SET 
			[OnStartTime]            = GETDATE(),
			[OnStopTime]             = NULL,
			[JobStatus]              = 'Started',
			[ModifiedDate]           = GETDATE(),
	        [ModifiedBy]             = @userId

			WHERE Id=@serviceId
		END
	    ELSE IF(@flag ='OnStopTime') --OnStopTime
		BEGIN
			UPDATE [dbo].[OT_Init_Service_Details]
			SET 
			[OnStopTime]             = GETDATE(),
			[ModifiedDate]           = getdate()
	      -- [ModifiedBy]             = @userId
			WHERE Id=@serviceId
		END
		ELSE IF(@flag ='JobStartDate') 
		BEGIN
			UPDATE [dbo].[OT_Init_Service_Details]
			SET 
			[JobStartDate]           = GETDATE(),
			[JobStatus]              = 'In Progress',
			[ModifiedDate]           = getdate()
	      --  [ModifiedBy]             = @userId
			WHERE Id=@serviceId
		END
		ELSE IF(@flag ='JobEndDate') 
		BEGIN
			UPDATE [dbo].[OT_Init_Service_Details]
			SET 
			[JobEndDate]             = GETDATE(),
			[JobStatus]              = 'Completed',
			[ModifiedDate]           = getdate()
	      --  [ModifiedBy]             = @userId
			WHERE Id=@serviceId
		END
			
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END

