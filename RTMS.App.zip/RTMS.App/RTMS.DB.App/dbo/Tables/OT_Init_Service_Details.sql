﻿CREATE TABLE [dbo].[OT_Init_Service_Details](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ServiceName] [nvarchar](250) NOT NULL,
	[OnStartTime] [datetime] NULL,
	[OnStopTime] [datetime] NULL,
	[OnStopStatus] [nvarchar](50) NULL,
	[CycleIntervalInMin] [int] NULL,
	[JobStartDate] [datetime] NULL,
	[JobEndDate] [datetime] NULL,
	[JobStatus] [nvarchar](50) NULL,
	[CreatedDate] [datetime] NOT NULL CONSTRAINT [DF_OT_Init_Service_Details_CreateDate]  DEFAULT (getdate()),
	[CreatedBy] [uniqueidentifier] NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_OT_Init_Service_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
 CONSTRAINT [FK_OT_Init_Service_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
 CONSTRAINT [FK_OT_Init_Service_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
)