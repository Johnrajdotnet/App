﻿CREATE TABLE [dbo].[OT_TV_WBody_WFlow_Hit_Log_Details](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HitObjectId] [int] NOT NULL,
	[TransactionGroupId] [int] NOT NULL,
	[AttributeName] [nvarchar](50) NULL,
	[AttributeValue] [nvarchar](50) NULL,
	[Comment] [nvarchar](50) NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_OT_Hit_Log_Details] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[OT_TV_WBody_WFlow_Hit_Log_Details]  WITH CHECK ADD  CONSTRAINT [FK_OT_Hit_Log_Details_ST_Hit_Count_Table_Name_Details] FOREIGN KEY([HitObjectId])
REFERENCES [dbo].[ST_Hit_Count_Table_Name_Details] ([Id])
GO

ALTER TABLE [dbo].[OT_TV_WBody_WFlow_Hit_Log_Details] CHECK CONSTRAINT [FK_OT_Hit_Log_Details_ST_Hit_Count_Table_Name_Details]
GO