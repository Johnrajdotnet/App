

CREATE TABLE [dbo].[OT_Hit_Count_Column_Name_Details](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TableId] [int] NOT NULL,
	[CurrentTransactionId] [int] NOT NULL,
	[ColumnName] [nvarchar](250) NOT NULL,
	[ColumnValue] [nvarchar](250) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ST_Hit_Count_Column_Name_Details] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[OT_Hit_Count_Column_Name_Details]  WITH CHECK ADD  CONSTRAINT [FK_ST_Hit_Count_Column_Name_Details_ST_Hit_Count_Table_Name_Details] FOREIGN KEY([TableId])
REFERENCES [dbo].[ST_Hit_Count_Table_Name_Details] ([Id])
GO
ALTER TABLE [dbo].[OT_Hit_Count_Column_Name_Details] CHECK CONSTRAINT [FK_ST_Hit_Count_Column_Name_Details_ST_Hit_Count_Table_Name_Details]
GO
