
CREATE TABLE [dbo].[ST_Hit_Count_Table_Name_Details](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ObjectCode] [int] NOT NULL,
	[ObjectName] [nvarchar](250) NOT NULL,
	[ObjectPageName] [nvarchar](50) NOT NULL,
	[ObjectTableName] [nvarchar](50) NOT NULL,
	[Active] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL CONSTRAINT [DF_ST_Hit_Count_Table_Name_Details_CreatedDate]  DEFAULT (getdate()),
	[ModifiedDate] [datetime] NOT NULL CONSTRAINT [DF_ST_Hit_Count_Table_Name_Details_ModifiedDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_ST_Hit_Count_Table_Name_Details] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
