﻿/****** Object:  Synonym [Admin].[Syn_ST_Users]    Script Date: 3/7/2019 10:40:59 AM ******/
CREATE SYNONYM [Edc].[Syn_OT_TV_Drawing_Details] FOR [RTMS.Core].[Edc].[OT_TV_Drawing_Details]