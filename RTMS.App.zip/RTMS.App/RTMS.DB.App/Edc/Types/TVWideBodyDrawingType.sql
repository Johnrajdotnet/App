﻿GO
--drop procedure [Edc].[InsertOrUpdateDrawingDetailsUpload]
--drop type [Edc].[TVEngineDataCenterType]

CREATE TYPE [Edc].[TVWideBodyDrawingType] AS TABLE(
	[FileName] [nvarchar](250) NULL,
	[PartNumber] [nvarchar](250) NULL,
	[PartDescription] [nvarchar](250) NULL,
	[IssueDate] [nvarchar](250) NULL,
	[Revision] [nvarchar](250) NULL,
	[Series] [nvarchar](250) NULL,
	[FilePath] [nvarchar](250) NULL,
	[CpiritLink] [nvarchar](250) NULL
)
GO

