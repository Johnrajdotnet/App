﻿CREATE TYPE [Edc].[TVWideBodyRedTopCenterType] AS TABLE
(
--	[Id]							BIGINT				IDENTITY (1, 1) NOT NULL,
	RedTopReference					NVARCHAR(250)		NOT NULL,
	EngineType						NVARCHAR(250)		NULL,
	[Type]							NVARCHAR(250)		NULL,
	[Title]							NVARCHAR(250)		NULL,
	[DateRaised]					DATETIME			NULL,
	[DateClosed]					DATETIME			NULL,			
	[Mks]							NVARCHAR(250)		NULL,
	[Remark]					    NVARCHAR(500)		NULL,
	[FileName]					    NVARCHAR(100)		NULL,
	[CreatedBy]						UNIQUEIDENTIFIER	NOT NULL,
	[CreatedDate]					DATETIME			NULL,
	[ModifiedBy]					UNIQUEIDENTIFIER	NULL,
	[ModifiedDate]					DATETIME			NULL
)
