﻿CREATE TYPE [Edc].[TVWideBodyRedTopApplicableCenterType] AS TABLE
(
--	[Id]							BIGINT				IDENTITY (1, 1) NOT NULL,
	RedTopReference					NVARCHAR(250)		NOT NULL,
	EngineMark						NVARCHAR(250)		NULL,
	[IsApplicable]					BIT					NULL,	 
	[CreatedBy]						UNIQUEIDENTIFIER	NOT NULL,
    [CreatedDate]					DATETIME			NULL,
	[ModifiedBy]					UNIQUEIDENTIFIER	NULL,
	[ModifiedDate]					DATETIME			NULL
)
