﻿
GO
--drop procedure  [Edc].[GetRedTopUploadDetail]  
--drop type [Edc].[TVRedTopCenter]
CREATE TYPE [Edc].[TVRedTopCenter] AS TABLE(
	[RedTopReference] [nvarchar](250) NULL,
	[EngineType] [nvarchar](250) NULL
)

GO