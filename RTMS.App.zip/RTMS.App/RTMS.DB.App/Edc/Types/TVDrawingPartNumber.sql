﻿GO
--drop procedure [Edc].[GetDrawingUploadDetail]  
--drop type[Edc].[TVDrawingPartNumber]
CREATE TYPE [Edc].[TVDrawingPartNumber] AS TABLE(
	[PartNumber] [nvarchar](250) NULL,
	[EngineType] [nvarchar](250) NULL
)
GO



