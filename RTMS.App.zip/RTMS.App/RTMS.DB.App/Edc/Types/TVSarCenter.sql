﻿GO
--drop procedure [Edc].[GetSarTopUploadDetail]  
--drop type [Edc].[TVSarCenter]
CREATE TYPE [Edc].[TVSarCenter] AS TABLE
(
	[SARNumber] [nvarchar](250) NULL,
	[EngineType] [nvarchar](250) NULL
)
GO