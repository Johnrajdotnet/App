﻿CREATE TYPE [Edc].[TVWideBodySarCenterType] AS TABLE
(
	
	SARNumber						NVARCHAR(250)		NOT NULL,
	EngineType						NVARCHAR(250)		NULL,
	[Title]							NVARCHAR(250)		NULL,
	[Type]							NVARCHAR(250)		NULL,
	[Location]						NVARCHAR(250)		NULL,
	[DateRaised]					DATETIME			NULL,
	[DateClosed]					DATETIME			NULL,
	[ReasonForSAR]					NVARCHAR(250)		NULL,
	[AttributableSCU]				NVARCHAR(250)		NULL,				
	[GenericOwner]					NVARCHAR(250)		NULL,
	[RCINumber]						NVARCHAR(250)		NULL,				
	[SAROwner]						NVARCHAR(250)		NULL,
	[AccountableManager]			NVARCHAR(250)		NULL,				
	[OriginalTarget]				NVARCHAR(250)		NULL,
	[ReCommitment]					NVARCHAR(250)		NULL,
	[CurrentGate]					NVARCHAR(250)		NULL,				
	[Age]							NVARCHAR(250)		NULL,
	[Blocker]						NVARCHAR(250)		NULL,
	[NextReview]					NVARCHAR(250)		NULL,				
	[ClosureMethod]					NVARCHAR(250)		NULL,
	[RedTopNumber]					NVARCHAR(250)		NULL,
	[CreatedBy]						UNIQUEIDENTIFIER	NOT NULL,	
	CreatedDate						DATETIME			NOT NULL,
	[ModifiedBy]					UNIQUEIDENTIFIER	NULL,
	[ModifiedDate]					DATETIME			NULL
)
