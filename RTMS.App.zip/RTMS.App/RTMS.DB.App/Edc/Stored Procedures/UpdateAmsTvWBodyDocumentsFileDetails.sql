﻿
-- =============================================
--PROCEDURE: [Edc].[UpdateAmsTvWBodyDocumentsFileDetails]    
--PURPOSE: Update the Edc Document Table when uploading the signed document.
--CREATED: Blessy Babu 15/02/2019
-- ============================================= 
-- EXEC [Edc].[UpdateAmsTvWBodyDocumentsFileDetails]    

CREATE PROCEDURE [Edc].[UpdateAmsTvWBodyDocumentsFileDetails]    
	-- Add the parameters for the stored procedure here
	@tvNumber          BIGINT,
	@fileName          NVARCHAR(250),
	@projectNamePath   NVARCHAR(200),
	@contentPath       NVARCHAR(200),
	@processVersion    NVARCHAR(10),
	@userId            UNIQUEIDENTIFIER
    	   
AS
BEGIN	 
	SET NOCOUNT ON;
	BEGIN TRY
             IF EXISTS (SELECT Id FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE TVNumber=@tvNumber )
			 BEGIN
			 
				  UPDATE [Edc].[OT_TV_Wide_Body_Documents_Details]
				  SET
						  [Active]       = 1,
						  [ModifiedBy]   = @userId, 
						  [ModifiedDate] = GetDate()

				  WHERE   [TVNumber]= @tvNumber
			 END
			 ELSE
			 BEGIN
			       INSERT INTO [Edc].[OT_TV_Wide_Body_Documents_Details]
				   (
				   [TVNumber],
                   [FileName],
                   [ProjectNamePath],
                   [ContentPath],
                   [ProcessVersion],
                   [Active],
                   [CreatedBy],
                   [CreatedDate]
				   )
				   SELECT
				   @tvNumber,
				   @fileName,
				   @projectNamePath,
				   @contentPath,
				   @processVersion,
				   1,
				   @userId,
				   GETDATE()

			 END
	  
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END
