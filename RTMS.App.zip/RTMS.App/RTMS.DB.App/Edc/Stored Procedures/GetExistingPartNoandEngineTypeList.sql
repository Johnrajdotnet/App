﻿

-- =============================================
-- Author:           <Mira>
-- Create date: <07/03/2019>
-- Description:      <Check for Duplicate Part Number and EngineType Existence>
-- [Edc].[GetExistingSARandEngineTypeList] '100001,159915,182393,183503,162727,167475,170526,170669,176216,176217,176219,176308,183146,183993,178291,182948,178135,178922,181838,183532,180061,180118,180307,180669,180675,180704,180786,180792,180967,180978,181119,181292','3,3,1,1,3,1,1,2,1,2,2,2,2,1,1,1,1,2,3,1,1,1,2,1,1,1,1,4,1,1,3,1'
-- =============================================
CREATE PROCEDURE [Edc].[GetExistingPartNoandEngineTypeList]
       -- Add the parameters for the stored procedure here
       @PartNumberList nvarchar(max),
	   @engineTypeList nvarchar(max)
AS
BEGIN
		
       
		DECLARE @temptable TABLE
        (
            Id INT IDENTITY(1,1),
			PartNumber NVARCHAR(20),
			EngineType NVARCHAR(20),
			ActionFlag NVARCHAR(20)
        ) 
		INSERT  @temptable	
		SELECT 
				tvp.Item,i.Item, 'UPDATE' FROM  [Edc].[OT_TV_Drawing_Details] tv
		CROSS APPLY 
				dbo.StringToTableValueWithIdentity(@PartNumberList, ',') tvp 
		CROSS APPLY 
				 dbo.StringToTableValueWithIdentity(@engineTypeList, ',') i
		WHERE    tvp.Id=i.Id 
		AND	     PartNumber =tvp.Item 
		AND	     Series=i.Item
		AND      Revision='CP'
		GROUP BY tvp.Item,i.Item  

	
		
		INSERT  @temptable
		SELECT  tp.PartNumber,tp.EngineType,'ADD' FROM		
		(
		SELECT 
				tvp.Item as PartNumber,i.Item as EngineType
		FROM	dbo.StringToTableValueWithIdentity(@PartNumberList, ',') tvp
		INNER JOIN 
				dbo.StringToTableValueWithIdentity(@engineTypeList, ',') i ON tvp.Id=i.Id 
		)tp		
		LEFT JOIN @temptable tt ON tt.PartNumber=tp.PartNumber AND tt.EngineType=tp.EngineType
		WHERE     tt.EngineType is null 
		
		SELECT * FROM @temptable

END
