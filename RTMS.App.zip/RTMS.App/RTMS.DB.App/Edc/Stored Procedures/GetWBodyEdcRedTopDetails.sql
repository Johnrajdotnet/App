﻿
-- =============================================
-- Author:           <Blessy>
-- Create date:      <17/10/2018>
-- Description:      <Retrives RedTopDetails from [Edc].[OT_TV_Wide_Body_RedTop_Center]
-- exec [Edc].[GetWBodyEdcRedTopDetails] 'ALL','ALL','1',null,null
CREATE PROCEDURE [Edc].[GetWBodyEdcRedTopDetails] 

       @enginetype nvarchar(50),
	   @engineMark nvarchar(50),   
	   @Status int,
	   @RedTopReference nvarchar(100),
	   @Title nvarchar(1000)
AS
BEGIN TRY  
    		SELECT 
				r.[Id]                             AS Id,
				ROW_NUMBER()OVER(ORDER BY(r.[Id])) AS RowNumber,
				r.[RedTopReference]                AS RedTopReference,
				r.[EngineType]                     AS EngineType,
				r.[Type]                           AS Type,
				r.[Title]                          AS Title,
				r.[Remark]                         AS Remark,
				r.[FileName]                       AS FileName,
				r.[DateRaised]                     AS DateRaised,
				r.[DateClosed]                     AS DateClosed,
				r.[Mks]                            AS Mks,
				r.[CreatedBy]                      AS CreatedBy,
				r.[CreatedDate]                    AS CreatedDate,
				r.[ModifiedBy]                     AS ModifiedBy,
				r.[ModifiedDate]                   AS ModifiedDate,
				[dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)AS EngineMark
			   FROM [Edc].[OT_TV_Wide_Body_RedTop_Center] r 
			   WHERE r.[Active]=1 
			     AND (Isnull(r.[EngineType],-1) like ISNULL(@enginetype,Isnull(r.[EngineType],-1))
				 OR   	r.[EngineType] like '%'+@enginetype+'%'
				 OR     r.[EngineType] = CASE WHEN @enginetype ='ALL' THEN r.[EngineType]  ELSE  @enginetype END)
				 AND  (Isnull(([dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)),-1) like ISNULL(@engineMark,Isnull(([dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)),-1))
				 OR   	([dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)) like '%'+@engineMark+'%'
				 OR     ([dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)) = CASE WHEN @engineMark ='ALL' THEN ([dbo].[GetRedTopConcatenateEngineMark](r.RedTopReference)) ELSE  @engineMark END)
				 AND  (Isnull(r.RedTopReference,-1) like ISNULL(@RedTopReference ,Isnull(r.RedTopReference,-1))
				 OR      r.RedTopReference like'%'+@RedTopReference+'%')
				  AND  (Isnull(r.[Title],-1) like ISNULL(@Title,Isnull(r.[Title],-1))
				 OR      r.[Title] like'%'+@Title+'%')
				 AND  (CASE WHEN r.DateClosed is null THEN 1 ELSE 2 END)=@Status 
				ORDER BY [DateRaised] desc	

	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH


