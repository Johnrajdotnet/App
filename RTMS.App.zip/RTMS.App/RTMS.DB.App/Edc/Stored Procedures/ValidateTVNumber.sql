﻿	-- =============================================
	-- Author:           <Blessy Babu>
	-- Create date:		 <11/09/2018>
	-- Description:      <Validate TV number based on users>
	-- exec [Edc].[ValidateTVNumber] 1,'917614D4-E741-432D-BBF4-A3C6E4546129','199475'
	-- =============================================
	CREATE PROCEDURE [Edc].[ValidateTVNumber]
		@roleId     BIGINT,
		@roleUserId UNIQUEIDENTIFIER, 
		@TVNumber   BIGINT
	AS
	BEGIN 

		IF(@roleId<>1)
			BEGIN


				SELECT 	 
						   edc.TVNumber 
				FROM  
						   [Admin].[Syn_ST_User_Role_Module] rm 
				INNER JOIN [Admin].[Syn_ST_Users] u						    ON u.Id=rm.UserId
				INNER JOIN [Edc].[ST_TV_Owner_Details] od			    ON od.OracleId=u.UserId
				INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ad	ON (ad.Engineer1=od.Id OR ad.Engineer2=od.Id OR ad.CAEngineer=od.Id)
				INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] edc		ON edc.Id=ad.TVDataCenterId
				WHERE 
						    edc.DateCompleted is null 								    
							AND u.Active=1 AND od.Active=1		
							AND rm.Id=@roleUserId	
							AND edc.TVNumber=@TVNumber		   			     
			END
		ELSE
			BEGIN
				SELECT   
						   edc.TVNumber 
				FROM  
						   [Edc].[OT_TV_Wide_Body_Activity_Center] ad
				INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] edc     ON edc.Id=ad.TVDataCenterId
				WHERE 
						    edc.DateCompleted is null 
					    AND edc.TVNumber=@TVNumber		   
									
			END
	END
