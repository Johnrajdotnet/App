﻿
	-- =============================================
	-- Author:           <Neethu Rose>
	-- Create date:		 <11/09/2018>
	-- Description:      <Get All pending TV Details for CA Review >
	-- exec [Edc].[GetAllPendingTVdetails] 26,'8a2b88dd-6889-4169-a21d-3423038f8165',''
	-- =============================================
	CREATE PROCEDURE [Edc].[GetAllPendingTVdetailsForCAReview]
		@roleId BIGINT,
		@roleUserId UNIQUEIDENTIFIER, 
		@pgmId NVARCHAR(MAX)
	AS
	BEGIN

				SELECT 	  TOP 100
						   edc.TVNumber          AS TVNumber, 
						   edc.DateIn            AS DateIn,
						   edc.EngineMark        AS EngineMark,
						   ad.Id                 AS TVActivityId,
						   ad.DraftSubmittedDate AS DraftSubmittedDate,
						   edc.IssueNumber       AS IssueNumber,
						   edc.TVType            AS TVType
						   
				FROM  
						   [Admin].[Syn_ST_User_Role_Module] rm 
				INNER JOIN [Admin].[Syn_ST_Users] u						    ON u.Id=rm.UserId
				INNER JOIN [Edc].[ST_TV_Owner_Details] od			    ON od.OracleId=u.UserId
				INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ad	ON ad.CAEngineer=od.Id 
				INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] edc		ON edc.Id=ad.TVDataCenterId
				WHERE 
						    edc.DateCompleted is null 								    
							AND u.Active=1 AND od.Active=1		
							AND rm.Id=@roleUserId
							AND ad.DraftSubmittedBy is not null
							AND ad.DraftSubmittedDate is  not null
							AND (ad.CAStatus=0 OR ad.CAStatus is null)
				ORDER BY   edc.DateIn desc,edc.EngineMark asc			   			     
		
				
	END

	