﻿	-- =============================================
	-- Author:           Mira Kumari
	-- Create date:      17/10/2018
	-- Description:      Insert Red Top information from excel to Database 
	-- =============================================
	CREATE PROCEDURE [Edc].[InsertOrUpdateImportRedTopInformation] 
	@RedTopCenterTableType [Edc].[TVWideBodyRedTopCenterType] READONLY,
	@RedTopApplicableCenterTableType [Edc].[TVWideBodyRedTopApplicableCenterType] READONLY,
	@actionFlag NVARCHAR(20)
	as
	begin
		SET NOCOUNT ON;      
	    BEGIN TRY
			IF(UPPER(@actionFlag)='ADD')
			BEGIN
					INSERT INTO [Edc].[OT_TV_Wide_Body_RedTop_Center]
					            ( RedTopReference, EngineType,Type, Title, DateRaised, DateClosed, Mks,Remark,FileName, CreatedBy, CreatedDate )
					SELECT       RedTopReference, EngineType,Type, Title, DateRaised, DateClosed, Mks, Remark,FileName,CreatedBy, CreatedDate from @RedTopCenterTableType

					INSERT INTO [Edc].[OT_TV_Wide_Body_RedTop_Applicable_Center]
					            (RedTopReference, EngineMark, IsApplicable, CreatedBy, CreatedDate)
					SELECT      RedTopReference, EngineMark, IsApplicable, CreatedBy, CreatedDate from @RedTopApplicableCenterTableType

			END
			ELSE
			BEGIN
					Update [Edc].[OT_TV_Wide_Body_RedTop_Center]
					SET
							EngineType=red.EngineType,Type=red.Type, Title=red.Title, DateRaised=red.DateRaised, DateClosed=red.DateClosed, 
							Mks=red.Mks,Remark=red.Remark,FileName=red.FileName, ModifiedBy=red.ModifiedBy, ModifiedDate=red.ModifiedDate
					FROM
							@RedTopCenterTableType red
					WHERE	 [Edc].[OT_TV_Wide_Body_RedTop_Center].RedTopReference =Red.RedTopReference 

				    Update  [Edc].[OT_TV_Wide_Body_RedTop_Applicable_Center]
					SET
						   EngineMark=red.EngineMark, IsApplicable=red.IsApplicable, ModifiedBy=red.ModifiedBy, ModifiedDate=red.ModifiedDate
					FROM
							@RedTopApplicableCenterTableType red
					WHERE	[Edc].[OT_TV_Wide_Body_RedTop_Applicable_Center].RedTopReference =red.RedTopReference 
					and     [Edc].[OT_TV_Wide_Body_RedTop_Applicable_Center].EngineMark=red.EngineMark

			END

		END TRY
		BEGIN CATCH
			EXECUTE [dbo].[LogError]
	    END CATCH
     END

