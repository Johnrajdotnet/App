﻿-- =============================================
-- Author:           <Mira>
-- Create date:      <09/05/2019>
-- Description:      <Get Booked in TV]
-- exec [Edc].[GetPostTvBookedInActivityDetails] 
CREATE PROCEDURE [Edc].[GetPostTvBookedInActivityDetails] 
AS
BEGIN TRY
        SELECT    bd.TVNumber, edc.DateIn,edc.EngineMark,edc.TVType, ISNULL(bd.DownloadAllSuccess,0) AS DownloadAllSuccess, 
		ISNULL(bd.Active,0) AS Active,edc.PartDescription 
		FROM      [Edc].[OT_TV_Wide_Body_BookedIn_Documents_Details] AS bd
		LEFT JOIN [Edc].[OT_TV_Wide_Body_Data_Center] AS edc 
		ON        edc.TVNumber=bd.TVNumber
		WHERE      edc.TeamLeader='Booked,In' 
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH