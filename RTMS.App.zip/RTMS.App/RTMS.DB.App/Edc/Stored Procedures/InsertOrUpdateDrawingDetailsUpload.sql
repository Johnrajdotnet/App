﻿

-- =============================================
-- Author:           Mira
-- Create date: 07/03/2019
-- Description:      Insert SAR information from excel to Database 
-- =============================================
CREATE PROCEDURE [Edc].[InsertOrUpdateDrawingDetailsUpload]
@tVWideBodyDrawingType [Edc].[TVWideBodyDrawingType] READONLY,
@actionFlag NVARCHAR(20),
@UserId UNIQUEIDENTIFIER,
@tvNumberError NVARCHAR(MAX) OUTPUT

AS
BEGIN  
       
       SET NOCOUNT ON;      
BEGIN TRY
IF(UPPER(@actionFlag)='ADD')
BEGIN

		INSERT INTO  [Edc].[OT_TV_Drawing_Details]
			(
					FileName, 
					PartNumber, 
					PartDescription, 
					IssueDate, 
					Revision, 
					Series, 
					FilePath, 
					CpiritLink, 
					Active, 
					CreatedBy, 
					CreatedDate
								 
			)

			SELECT 
					FileName, 
					PartNumber, 
					PartDescription, 
					IssueDate, 
					Revision, 
					Series, 
					FilePath, 
					CpiritLink, 
					1, 
					@UserId, 
					GETDATE() 
                                         
			FROM @tVWideBodyDrawingType

                                  
END
ELSE
BEGIN
		   UPDATE [Edc].[OT_TV_Drawing_Details]
		   SET
                     
					FileName=t.FileName, 
					PartNumber=t.PartNumber, 
					PartDescription=t.PartDescription, 
					IssueDate=t.IssueDate,
					Revision=t.Revision, 
					Series=t.Series, 
					FilePath=t.FilePath, 
					CpiritLink=t.CpiritLink, 
					Active=1, 
					ModifiedBy=@UserId, 
					ModifiedDate=GETDATE()
       
		   FROM
				   @tVWideBodyDrawingType t
		   WHERE   [Edc].[OT_TV_Drawing_Details].PartNumber =t.PartNumber   
		   AND     [Edc].[OT_TV_Drawing_Details].Series =t.Series
		   AND     [Edc].[OT_TV_Drawing_Details].Revision =t.Revision    
       
		   SET @tvNumberError=NULL


END

END TRY
BEGIN CATCH
       SET @tvNumberError='File Upload Failed'
   EXECUTE [dbo].[LogError]
END CATCH
END

