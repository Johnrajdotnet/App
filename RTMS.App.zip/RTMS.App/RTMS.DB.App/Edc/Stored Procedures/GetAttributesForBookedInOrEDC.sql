﻿
-- =============================================
-- Author:		<Neethu Rose Peter>
-- Create date: <15/02/2018,,>
-- Description:	<Get Unallocated Tv Data>
-- =============================================
CREATE PROCEDURE [Edc].[GetAttributesForBookedInOrEDC]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
			[AttributeGroupId] AS GroupId,
			[AttributeName]    AS AttributeName,
			[AttributeValue]   AS AttributeValue
			
		FROM  [Edc].[ST_TV_Register_Attribute]
		WHERE Active=1


		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END
