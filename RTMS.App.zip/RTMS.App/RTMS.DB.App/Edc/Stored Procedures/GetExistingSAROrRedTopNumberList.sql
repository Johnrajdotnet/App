﻿
-- =============================================
-- Author:           <Arathy>
-- Create date:      <16/02/2018>
-- Description:      <Check for Duplicate TVNumber Existence>
--exec [Edc].[GetExistingSAROrRedTopNumberList] '100000,159915,182393,183503,162727,167475,170526,170669,176216,176217,176219','null','REDTOP'
 
-- =============================================
CREATE PROCEDURE [Edc].[GetExistingSAROrRedTopNumberList]
       -- Add the parameters for the stored procedure here
                     @redTopNumberList nvarchar(max),
                     @sarNumberList nvarchar(max),
                     @flag nvarchar(max)
          
AS
BEGIN 
       
       SET NOCOUNT ON;     
BEGIN TRY
              IF(UPPER(@flag)='SAR')
              BEGIN
                           DECLARE @temptable TABLE
                           (
                                  Id INT IDENTITY(1,1),
                                  SARNumber nvarchar(max),
                                  ActionFlag NVARCHAR(20)
                           )
                           INSERT @temptable   
 
                           SELECT
                           tvp.Item, 'UPDATE'  FROM  [Edc].[OT_TV_Wide_Body_Sar_Center] tv
 
                           CROSS APPLY
                                         dbo.StringToTableValueWithIdentity(@sarNumberList, ',') tvp
                           WHERE [SARNumber] = tvp.Item
 
 
                           INSERT @temptable
 
                           SELECT tp.[SARNumber],'ADD' FROM        
                           (
                                  SELECT
                                  tvp.Item as SARNumber
                                  FROM   dbo.StringToTableValueWithIdentity(@sarNumberList, ',') tvp
                           )tp          
                           LEFT JOIN @temptable tt ON tt.SARNumber=tp.SARNumber
                           WHERE tt.[SARNumber] is null
 
                           SELECT * FROM @temptable
              END
              IF(UPPER(@flag)='REDTOP')
              BEGIN
              DECLARE @temptable1 TABLE
                           (
                                  Id INT IDENTITY(1,1),
                                  RedTopReference nvarchar(max),
                                  ActionFlag NVARCHAR(20)
                           )
                           INSERT @temptable1  
 
                           SELECT
                           tvp.Item, 'UPDATE' FROM  [Edc].[OT_TV_Wide_Body_RedTop_Center] tv
 
                           CROSS APPLY
                                         dbo.StringToTableValueWithIdentity(@redTopNumberList, ',') tvp
                           WHERE [RedTopReference] = tvp.Item
 
                           
                           INSERT @temptable1
 
                           SELECT tp.[RedTopReference],'ADD' FROM         
                           (
                                  SELECT
                                  tvp.Item as RedTopReference
                                  FROM   dbo.StringToTableValueWithIdentity(@redTopNumberList, ',') tvp
                           )tp          
                           LEFT JOIN @temptable1 tt ON tt.RedTopReference=tp.RedTopReference
                           WHERE tt.RedTopReference is null
 
                           SELECT * FROM @temptable1
              END
          
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
END