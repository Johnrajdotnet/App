﻿
-- =============================================
-- Author:           Arathy
-- Create date: 5/8/2018
-- Description:      Insert SAR information from excel to Database 
-- =============================================
CREATE PROCEDURE [Edc].[InsertOrUpdateSarDetailsUpload]
       -- Add the parameters for the stored procedure here
@tVWideBodySarCenterType [Edc].[TVWideBodySarCenterType] READONLY,
@actionFlag NVARCHAR(20),
@tvNumberError NVARCHAR(MAX) OUTPUT

AS
BEGIN  
       
       SET NOCOUNT ON;      
BEGIN TRY
IF(UPPER(@actionFlag)='ADD')
BEGIN

                     INSERT INTO [Edc].[OT_TV_Wide_Body_Sar_Center]
                           (
                                         
										SARNumber,						
										EngineType,					
										[Title],						
										[Type],
										[Location],
										[DateRaised],
										[DateClosed],
										[ReasonForSAR],
										[AttributableSCU],				
										[GenericOwner],
										[RCINumber],				
										[SAROwner],
										[AccountableManager],				
										[OriginalTarget],
										[ReCommitment],
										[CurrentGate],				
										[Age],
										[Blocker],
										[NextReview],				
										[ClosureMethod]	,
										[RedTopNumber]	,
										[CreatedBy]	,
										CreatedDate
                                         
                           )

                           SELECT 
                                        SARNumber,						
										EngineType,					
										[Title],						
										[Type],
										[Location],
										[DateRaised],
										[DateClosed],
										[ReasonForSAR],
										[AttributableSCU],				
										[GenericOwner],
										[RCINumber],				
										[SAROwner],
										[AccountableManager],				
										[OriginalTarget],
										[ReCommitment],
										[CurrentGate],				
										[Age],
										[Blocker],
										[NextReview],				
										[ClosureMethod],
										[RedTopNumber],
										[CreatedBy]	,
										CreatedDate
                                         
                           FROM @tVWideBodySarCenterType

                                  
END
ELSE
BEGIN
       UPDATE [Edc].[OT_TV_Wide_Body_Sar_Center]
       SET
                     
                     SARNumber=t.SARNumber,			
					 EngineType=t.EngineType,
					 Title = t.Title,
					 [Type] = t.[Type],
					 [Location]=t.[Location],
					 [DateRaised]=t.[DateRaised],
					 [DateClosed]=t.[DateClosed],
					 [ReasonForSAR]=t.[ReasonForSAR],
					 [AttributableSCU]=t.[AttributableSCU],
					 [GenericOwner]=t.[GenericOwner],
					 [RCINumber] = t.[RCINumber],
					 [SAROwner]=t.[SAROwner],
					 [AccountableManager]=t.[AccountableManager],
					 [OriginalTarget]=t.[OriginalTarget],
					 [ReCommitment]=t.[ReCommitment],
					 [CurrentGate]=t.[CurrentGate],
					 [Age]=t.[Age],
					 [Blocker]=t.[Blocker],
					 [NextReview]=t.[NextReview],
					 [ClosureMethod]=t.[ClosureMethod],
					 [RedTopNumber]=t.[RedTopNumber],
                     ModifiedBy=t.ModifiedBy,
                     ModifiedDate=t.ModifiedDate
       
       FROM
       @tVWideBodySarCenterType t
       WHERE [Edc].[OT_TV_Wide_Body_Sar_Center].SARNumber =t.SARNumber 
       
       SET @tvNumberError=null


END

END TRY
BEGIN CATCH
       SET @tvNumberError='File Upload Failed'
   EXECUTE [dbo].[LogError]
END CATCH
END