﻿
-- =============================================
-- Author:           <Anupa C S>
-- Create date: <16/02/2018>
-- Description:      <Check for Duplicate TVNumber Existence>
-- =============================================
CREATE PROCEDURE [Edc].[CheckDuplicateExistsForTVNumber]
       -- Add the parameters for the stored procedure here
       @TvNumberList nvarchar(max)
AS
BEGIN
       -- SET NOCOUNT ON added to prevent extra result sets from
       -- interfering with SELECT statements.
       SET NOCOUNT ON;

    -- Insert statements for procedure here
       SELECT Distinct TVNumber FROM  [Edc].[OT_TV_Data_Center_Information]
           WHERE TVNumber IN(
              SELECT CAST(Item AS INT)
              FROM  dbo.StringToTableValue(@TvNumberList, ',')  )
END
