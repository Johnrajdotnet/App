﻿
-- =============================================
-- Author:           <Arathy>
-- Create date:		 <07/05/2018>
-- Description:      <Retrives TV Content Details>
-- exec [Edc].[GetEdcDetailsbyEngineMarkOrATA] null,null
CREATE PROCEDURE [Edc].[RBodyGetEdcDetailsbyEngineMarkOrATA] 

       @ata nvarchar(50),
	   @engineMark nvarchar(50)      
AS
BEGIN TRY
		
		SELECT TOP 2000 [TVNumber] AS TVNumber,
			   [TVNumberExtension] AS TVNumberExtension,
			   [ATA]               AS ATA,
			   [PartNumber]        AS PartNumber,
			   [PartDescription]   AS PartDescription,
			   [Problem]           AS Problem,
			   [Remarks]           AS Remarks,
			   [Applicant]         AS Applicant,
			   [EngineMark]        AS EngineMark,
			   [Disposition]       AS Disposition,
			   [PartSerialNumber]  AS PartSerialNumber,
			   [DateCompleted]     AS DateCompleted,
			   [TeamLeader]        AS TeamLeader,
			   [Owner]             AS Owner,
			   [FRSNumber]         AS FRSNumber,
			   [RMROrRPRNumber]    AS RMROrRPRNumber,
			   [ESN]               AS ESN,
			   [InitialPSEOrPREOrCVEActual] AS InitialPSEOrPREOrCVEActual,
			   [IssueNumber]       AS IssueNumber,
			   [KittingDate]       AS KittingDate,
			   [RREngineeringGap]  AS RREngineeringGap,
			   [RREngineeringIn]   AS RREngineeringIn,
			   [RRPromisedDate]    AS RRPromisedDate

		FROM   [Edc].[OT_TV_Regional_Body_Data_Center] hd
				
		--WHERE
		--		Isnull(hd.[ATA],-1)=ISNULL(@ata,Isnull(hd.[ATA],-1))
		-- AND	(ISnull(hd.[EngineMark],-1) = ISNULL(@engineMark,Isnull(hd.[EngineMark],-1))
		-- OR     hd.[EngineMark] like '%'+@engineMark+'%')
		WHERE
				 (Isnull(hd.[ATA],-1) like ISNULL(@ata,Isnull(hd.[ATA],-1))
		 OR   	hd.[ATA] like '%'+@ata+'%')
		 AND	(ISnull(hd.[EngineMark],-1) = ISNULL(@engineMark,Isnull(hd.[EngineMark],-1))
		 OR     hd.[EngineMark] like '%'+@engineMark+'%')
	    ORDER BY [DateCompleted] desc
	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH




	

