﻿
-- =============================================
-- Author:           <arathy>
-- Create date:            <08/05/2018>
-- Description:      <Retrives TV Drawing Details from [Edc].[OT_TV_Drawing_Details]>
-- [Edc].[GetTVDetailsForService] 132790 
CREATE PROCEDURE [Edc].[GetTVDetailsForService] 
@tvNumber bigint
AS
BEGIN TRY
              
              SELECT  [TVNumber] as TVNumber,
					  [IssueNumber] as IssueNumber,
					  [TVType]   as TVType
                         
              FROM  [Edc].[OT_TV_Wide_Body_Data_Center]
			  WHERE TVNumber=@tvNumber
             
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

