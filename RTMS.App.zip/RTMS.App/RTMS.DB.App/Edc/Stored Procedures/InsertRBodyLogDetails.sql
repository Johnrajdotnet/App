﻿

-- =============================================
--PROCEDURE: [Edc].[InsertRBodyLogDetails]
--PURPOSE: Insert RBOdy status log
--CREATED: Neethu 07/04/2017
-- ============================================= 

CREATE PROCEDURE [Edc].[InsertRBodyLogDetails]

@TVDataCenterActivityId bigint,
@FieldName nvarchar(250),
@FieldValue nvarchar(250),
@userId uniqueidentifier

AS


BEGIN TRY

	INSERT INTO [Edc].[OT_TV_Regional_Body_Log_Center] 
	(
	[TVDataCenterActivityId],
	[FieldName],
	[FieldValue],
	[FieldBy],
	[FieldDate],
	[CreatedBy],
	[CreatedDate]
	) 
	VALUES
	(
	@TVDataCenterActivityId,
	@FieldName,
	@FieldValue,
	@userId,
	GETDATE(),
	@userId,
	GETDATE()
	)


	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

GO


