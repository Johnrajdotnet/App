﻿	-- =============================================
	-- Author:           <Mira>
	-- Create date:		 <26/02/2019>
	-- Description:      <check PartNumber Existance >
	-- exec [Edc].[CheckHitCountPartNumber] 3,'PartNumber','123'
	-- =============================================
	CREATE PROCEDURE [Edc].[CheckHitCountPartNumber]
	@TableId INT,
	@ColumnName NVARCHAR(250),
	@ColumnValue  NVARCHAR(250)
	AS
	BEGIN
		  SELECT  ColumnValue AS PartNumber 
		  FROM    [dbo].[OT_Hit_Count_Column_Name_Details] 
		  WHERE   TableId=@TableId AND ColumnName=@ColumnName AND ColumnValue=@ColumnValue 
		          AND CONVERT(date, CreatedDate, 101)=CONVERT(date,GETDATE(),101)
	END
