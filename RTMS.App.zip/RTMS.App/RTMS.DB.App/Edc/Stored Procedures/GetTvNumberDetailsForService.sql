﻿
-- =============================================
-- Author:           <arathy>
-- Create date:            <08/05/2018>
-- Description:      <Retrives TV Drawing Details from [Edc].[OT_TV_Drawing_Details]>
-- [Edc].[GetTvNumberDetailsForService] 4
CREATE PROCEDURE [Edc].[GetTvNumberDetailsForService] 
@machineIndex int
AS
BEGIN TRY
              DECLARE @DateRequried DATETIME ='Jan 01 2010 0:00:00:000'

              SELECT top 10 do.[TVNumber]  AS TVNumber,
			                dc.IssueNumber AS IssueNumber,
							dc.TVType      AS TVType
					                        
              FROM  [Edc].[OT_TV_Wide_Body_Documents_Details] do
			  INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON 
			  (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
			  			  
			  WHERE do.Active=0
			  AND   do.[IterationCount] < 3
			  AND   dc.DateIn > CAST(FLOOR(CAST(@DateRequried as float)) as datetime)
			  AND  (dc.EngineMark  LIKE '%'+'t10'+'%'  OR  dc.EngineMark  LIKE '%'+'t9'+'%' )
			  AND   do.[MachineIndex]=@machineIndex
             
END TRY  
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

