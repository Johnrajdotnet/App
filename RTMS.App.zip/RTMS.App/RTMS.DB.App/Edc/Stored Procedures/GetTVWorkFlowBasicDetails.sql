﻿
-- =============================================
-- Author:		<Neethu Rose Peter>
-- Create date: <15/02/2018,,>
-- Description:	<Get Unallocated Tv Data>
--EXEC  [Edc].[GetTVWorkFlowBasicDetails]
-- =============================================
create PROCEDURE [Edc].[GetTVWorkFlowBasicDetails]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
					tvbasic.Id          AS [Id],
					tvbasic.TVNumber    AS [TvNumber],
					tvbasic.IssueNumber AS IssueNumber,
					dbo.GetTVRegisterAttribute(tvbasic.[Owner],28)              AS [Owner],
					dbo.GetTVRegisterAttribute(tvbasic.Team,26)                 AS [Team],
					dbo.GetTVRegisterAttribute(tvbasic.Certification,23 )       AS [Certification],
					dbo.GetTVRegisterAttribute(tvbasic.Classification ,24)      AS [Classification],
					dbo.GetTVRegisterAttribute(tvbasic.TVType,25)               AS [TVType],
					dbo.GetTVRegisterAttribute(tvbasic.ServiceLevelCategory,34) AS [ServiceLevelCategory],
					dbo.GetTVRegisterAttribute(tvbasic.Complexity,35)           AS [Complexity],
					CAST(tvbasic.RRPromisedDate as date)                        AS [RRPromisedDate],
					dbo.GetTVRegisterAttribute(tvbasic.StreamerCategory,43 )    AS [StreamerCategory],
					dbo.GetTVRegisterAttribute(tvbasic.TeamLeader,27)           AS [TeamLeader],
					tvbasic.CreatedDate  AS [CreatedDate],
					tvbasic.ModifiedDate AS [ModifiedDate]			
							 
		 FROM		 [Edc].[OT_TV_Wide_Body_Data_Center] tvbasic  

		 WHERE		tvbasic.IsCollected=0
		
		 		
	END TRY
		BEGIN CATCH
		EXECUTE [dbo].[LogError]
		END CATCH
END
