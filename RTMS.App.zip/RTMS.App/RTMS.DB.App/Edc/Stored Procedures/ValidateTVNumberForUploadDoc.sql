﻿

CREATE PROCEDURE [Edc].[ValidateTVNumberForUploadDoc]
@fileName  VARCHAR(50)
AS
BEGIN

       SET NOCOUNT ON;
       BEGIN TRY
              BEGIN

			   SELECT 
			          TVNumber     AS TVNumber,
			          TVType       AS TVType,
					  IssueNumber  AS IssueNumber

			   FROM [Edc].[OT_TV_Wide_Body_Data_Center] 

			   WHERE CAST(TVNumber AS NVARCHAR(50))= @fileName 
			     AND DateCompleted IS NOT NULL 
			      OR DateCompleted=''						 
              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END
