﻿-- =============================================
--PROCEDURE: [Edc].[GetWBodyEdcHistorySearchResult]
--PURPOSE: Get Edc Search Result from dynamic query
--CREATED:Neethu Rose Peter 12/10/2018
 --EXEC [Edc].[GetWBodyEdcHistorySearchResult] ' (((IssueNumber=''1'') AND (CustomerRequiredDate>02/01/2000)) AND (BriefProblem LIKE ''during%'')) '
-- ============================================= 

CREATE PROCEDURE [Edc].[GetWBodyEdcHistorySearchResult]
	   @dynamicQuery nvarchar(max)    
AS
BEGIN TRY
		

		DECLARE @query NVARCHAR(MAX)

		SET @query='SELECT top 2000 hd.[TVNumber] AS TVNumber,	
			   hd.[TVNumberExtension]             AS TVNumberExtension,
			   hd.[ATA]                           AS ATA,
			   hd.[PartNumber]                    AS PartNumber,
			   hd.[PartDescription]               AS PartDescription,
			   hd.[Problem]                       AS Problem,
			   hd.[Remarks]                       AS Remarks,
			   hd.[Applicant]                     AS Applicant,
			   hd.[EngineMark]                    AS EngineMark,
			   hd.[Disposition]                   AS Disposition,
			   hd.[PartSerialNumber]              AS PartSerialNumber,
			   hd.[DateCompleted]                 AS DateCompleted,
			   hd.[TeamLeader]                    AS TeamLeader,
			   hd.[Owner]                         AS Owner,
			   hd.[FRSNumber]                     AS FRSNumber,
			   hd.[RMROrRPRNumber]                AS RMROrRPRNumber,
			   hd.[ESN]                           AS ESN,
			   hd.[InitialPSEOrPREOrCVEActual]    AS InitialPSEOrPREOrCVEActual,
			   hd.[IssueNumber]                   AS IssueNumber,
			   hd.[KittingDate]                   AS KittingDate,
			   hd.[RREngineeringGap]              AS RREngineeringGap,
			   hd.[RREngineeringIn]               AS RREngineeringIn,
			   hd.[RRPromisedDate]                AS RRPromisedDate,
			   hd.[DateIn]                        AS [DateIn],
			   hd.[TVType]                        AS TVType,
			   ISNULL(dd.[ExpectedFileCount],0)	  AS ExpectedFileCount

		 FROM   [Edc].[OT_TV_Wide_Body_Data_Center] hd
		 LEFT JOIN [Edc].[OT_TV_Wide_Body_Documents_Details]  dd on dd.TVNumber=hd.TVNumber
		 WHERE
				 '+@dynamicQuery+' ORDER BY [DateCompleted] desc'

	  --print @query
		 
		EXEC(@query)

		
	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH



		 


