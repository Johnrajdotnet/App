
-- =============================================
-- Author:           <Anupa C S>
-- Create date: <16/02/2018>
-- Description:      <Check for Duplicate TVNumber Existence>
-- [Edc].[GetExistingTVNumberListForRBody] '100001,159915,182393,183503,162727,167475,170526,170669,176216,176217,176219,176308,183146,183993,178291,182948,178135,178922,181838,183532,180061,180118,180307,180669,180675,180704,180786,180792,180967,180978,181119,181292','3,3,1,1,3,1,1,2,1,2,2,2,2,1,1,1,1,2,3,1,1,1,2,1,1,1,1,4,1,1,3,1'
-- =============================================
CREATE PROCEDURE [Edc].[GetExistingTVNumberListForRBody]
       -- Add the parameters for the stored procedure here
       @tvNumberList nvarchar(max),
	   @issueNumberList nvarchar(max)
AS
BEGIN
		
       
		DECLARE @temptable TABLE
        (
            Id INT IDENTITY(1,1),
            TVNumber INT,
			IssueNumber INT,
			ActionFlag NVARCHAR(20)
        ) 
		INSERT @temptable	
		SELECT 
				tvp.Item,i.Item, 'UPDATE' FROM  [Edc].[OT_TV_Regional_Body_Data_Center] tv
		CROSS APPLY 
				dbo.StringToTableValueWithIdentity(@tvNumberList, ',') tvp 
		CROSS APPLY 
				dbo.StringToTableValueWithIdentity(@issueNumberList, ',') i
		WHERE  tvp.Id=i.Id 
		AND	TVNumber =tvp.Item 
		AND	IssueNumber=i.Item
		GROUP BY tvp.Item,i.Item  

	
		
		INSERT @temptable
		SELECT tp.TvNumber,tp.issueNumber,'ADD' FROM		
		(
		SELECT 
				tvp.Item as TvNumber,i.Item as issueNumber
		FROM	dbo.StringToTableValueWithIdentity(@tvNumberList, ',') tvp
		INNER JOIN 
				dbo.StringToTableValueWithIdentity(@issueNumberList, ',') i ON tvp.Id=i.Id 
		)tp		
		LEFT JOIN @temptable tt ON tt.TVNumber=tp.TvNumber AND tt.IssueNumber=tp.IssueNumber
		WHERE tt.IssueNumber is null
		
		SELECT * FROM @temptable

END

