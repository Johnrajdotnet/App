﻿
-- =============================================
-- Author:		<Mira Kumari>
-- Create date: <03/05/2019> ChecklistValue
-- Description:	<Get CA Checklist Details>
--[Edc].[GetDraftCheckListDetails]79228
-- =============================================
CREATE  PROCEDURE [Edc].[GetDraftCheckListDetails]
	-- Add the parameters for the stored procedure here
		@WBodyWFlowSeqId bigint,
		@WBodyActivityId bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
		
			BEGIN
				 SELECT cd.Id , chklist.CheckListGroupId as GroupId, chklist.CheckListGroupDescription, chklist.Category, 
				            chklist.CheckpointDescription AS CheckListName, chklist.SequenceNumber AS ChecklistId, cd.ChecklistValue
				 FROM       [Edc].[ST_TV_CheckList_Details] AS chklist
				 LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details] cd  
				 ON         cd.ChecklistGroupId=chklist.CheckListGroupId AND chklist.SequenceNumber=cd.ChecklistId 
				 AND        cd.WBodyActivityId=@WBodyActivityId AND cd.WBodyWFlowSequenceId=@WBodyWFlowSeqId 
				 AND        cd.Active=1 and cd.GroupChecklistOwner='Self'
				 WHERE   chklist.Active=1  AND chklist.CheckListGroupId In (51,54,55,56)
				 ORDER BY   CONVERT( INT, chklist.SequenceNumber)  ASC  
			END 
			     
        END TRY
        BEGIN CATCH
            EXECUTE [dbo].[LogError]
        END CATCH


END