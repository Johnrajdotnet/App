
-- =============================================
-- Author:           Arathy
-- Create date: 5/8/2018
-- Description:      Insert TV information from excel to Database 
-- =============================================
CREATE PROCEDURE [Edc].[InsertOrUpdateImportTVInformationForRBody] 
       -- Add the parameters for the stored procedure here
@tvHistoryTableType [Edc].[TVEngineDataCenterType] READONLY,
@actionFlag NVARCHAR(20),
@tvNumberError NVARCHAR(MAX) OUTPUT

AS
BEGIN  
       DECLARE @tempTVDetails TABLE (Id INT IDENTITY (1,1), TVNumber INT, OwnerName NVARCHAR(200))
       SET NOCOUNT ON;      
BEGIN TRY
IF(UPPER(@actionFlag)='ADD')
BEGIN

                     INSERT INTO [Edc].[OT_TV_Regional_Body_Data_Center]
                           (
                                         TVNumber,                                                     
                                         IssueNumber,               
                                         [TVNumberExtension],                     
                                         [Owner],                                                      
                                         Certification,                                                
                                         Classification,                                        
                                         TVType,
                                         Team,                                             
                                         TeamLeader,                                              
                                         Complexity,                                              
                                         RRPromisedDate,                                                      
                                         StreamerCategory,                                             
                                         ServiceLevelCategory,      
                                         AircraftNumber,
                                         Applicant,
                                         ApplicantsReference,
                                         ATA,
                                         BriefProblem,
                                         ClockStopDate,
                                         CompetentAuthorActual,
                                         CompetentAuthorFaultCode,
                                         CompetentAuthorGap,
                                         CompetentAuthorIn,
                                         CompetentAuthorOut,
                                         CompetentAuthorTarget,
                                         CSN,
                                         CSR,
                                         CustomerRequiredDate,
                                         DateCompleted,
                                         DateIn,
                                         DateInfoRequested,
                                         DateInfoSupplied,
                                         Disposition,
                                         EmpLevel,
                                         EngineMark,
                                         EnginePosition,
                                         ESN,
                                         ESNPlanned,
                                         FinalPSEOrPREOrCVEActual,
                                         FinalPSEOrPREOrCVEFaultCode,
                                         FinalPSEOrPREOrCVEGap,
                                         FinalPSEOrPREOrCVEIn,
                                         FinalPSEOrPREOrCVEOut,
                                         FinalPSEOrPREOrCVETarget,
                                         FRSNumber,
                                         HeadsupDate,
                                         HeadsupDecision,
                                         HeadsupDecisionActual,
                                         HeadsupDecisionFaultCode,
                                         HeadsupDecisionGap,
                                         HeadsupDecisionTarget,
                                         HeadsWupNonDeliveryFaultCode,
                                         HSN,
                                         HSR,
                                         InductionDate,
                                         InfoRequestedDetails,
                                         InitialPSEOrPREOrCVEActual,
                                         InitialPSEOrPREOrCVEFaultCode,
                                         InitialPSEOrPREOrCVEGap,
                                         InitialPSEOrPREOrCVEIn,
                                         InitialPSEOrPREOrCVEOut,
                                         InitialPSEOrPREOrCVETarget,
                                         KittingDate,
                                         LifingAndIntegrityIn,
                                         LifingAndIntegrityOut,
                                         MainOverhaulBase,
                                         ModuleNumber,
                                         NSP,
                                         Operator,
                                         OrganisationsOutsideRRIn,
                                         OrganisationsOutsideRROut,
                                         OriginalHeadsupDecision,
                                         OriginalPromisedDate,
                                         PartDescription,
                                         PartNumber,
                                         PartSerialNumber,
                                         PlannedReBuild,
                                         Problem,
                                         QualityScore,
                                         RCIComments,
                                         RCIDecision,
                                         RCIPriority,
                                         ReasonForRequest,
                                         Remarks,
                                         Repeater,
                                         ReworkIterations,
                                         RMROrRPRNumber,
                                         RREngineeringActual,
                                         RREngineeringFaultCode,
                                         RREngineeringGap,
                                         RREngineeringIn,
                                         RREngineeringOut,
                                         RREngineeringTarget,
                                         RRPubNumber,
                                         Satellite,
                                         Stock,
                                         TimeTvClosed,
                                         TimeTvRaised,
                                         TVRequestActual,
                                         TVRequestFaultCode,
                                         TVRequestGap,
                                         TVRequestTarget,
                                         TVTurnTimeActual,
                                         TVTurnTimeGap,
                                         TVTurnTimeTarget,
                                         PartQuantity,
                                         PreviousEngineNumber,
                                         PlannedEngineNumber,
                                         IsCollected,                                                         
                                         IsUploaded,                                                   
                                         CreatedBy,
                                         CreatedDate
                                         
                           )

                           SELECT 
                                         TVNumber,                                                     
                                         IssueNumber,  
                                         TVNumberExtension,                                     
                                         [Owner],                                                      
                                         Certification,                                                
                                         Classification,                                        
                                         TVType,
                                         Team,                                             
                                         TeamLeader,                                              
                                         Complexity,                                              
                                         RRPromisedDate,                                                      
                                         StreamerCategory,                                             
                                         ServiceLevelCategory,      
                                         AircraftNumber,
                                         Applicant,
                                         ApplicantsReference,
                                         ATA,
                                         BriefProblem,
                                         ClockStopDate,
                                         CompetentAuthorActual,
                                         CompetentAuthorFaultCode,
                                         CompetentAuthorGap,
                                         CompetentAuthorIn,
                                         CompetentAuthorOut,
                                         CompetentAuthorTarget,
                                         CSN,
                                         CSR,
                                         CustomerRequiredDate,
                                         DateCompleted,
                                         DateIn,
                                         DateInfoRequested,
                                         DateInfoSupplied,
                                         Disposition,
                                         EmpLevel,
                                         EngineMark,
                                         EnginePosition,
                                         ESN,
                                         ESNPlanned,
                                         FinalPSEOrPREOrCVEActual,
                                         FinalPSEOrPREOrCVEFaultCode,
                                         FinalPSEOrPREOrCVEGap,
                                         FinalPSEOrPREOrCVEIn,
                                         FinalPSEOrPREOrCVEOut,
                                         FinalPSEOrPREOrCVETarget,
                                         FRSNumber,
                                         HeadsupDate,
                                         HeadsupDecision,
                                         HeadsupDecisionActual,
                                         HeadsupDecisionFaultCode,
                                         HeadsupDecisionGap,
                                         HeadsupDecisionTarget,
                                         HeadsWupNonDeliveryFaultCode,
                                         HSN,
                                         HSR,
                                         InductionDate,
                                         InfoRequestedDetails,
                                         InitialPSEOrPREOrCVEActual,
                                         InitialPSEOrPREOrCVEFaultCode,
                                         InitialPSEOrPREOrCVEGap,
                                         InitialPSEOrPREOrCVEIn,
                                         InitialPSEOrPREOrCVEOut,
                                         InitialPSEOrPREOrCVETarget,
                                         KittingDate,
                                         LifingAndIntegrityIn,
                                         LifingAndIntegrityOut,
                                         MainOverhaulBase,
                                         ModuleNumber,
                                         NSP,
                                         Operator,
                                         OrganisationsOutsideRRIn,
                                         OrganisationsOutsideRROut,
                                         OriginalHeadsupDecision,
                                         OriginalPromisedDate,
                                         PartDescription,
                                         PartNumber,
                                         PartSerialNumber,
                                         PlannedReBuild,
                                         Problem,
                                         QualityScore,
                                         RCIComments,
                                         RCIDecision,
                                         RCIPriority,
                                         ReasonForRequest,
                                         Remarks,
                                         Repeater,
                                         ReworkIterations,
                                         RMROrRPRNumber,
                                         RREngineeringActual,
                                         RREngineeringFaultCode,
                                         RREngineeringGap,
                                         RREngineeringIn,
                                         RREngineeringOut,
                                         RREngineeringTarget,
                                         RRPubNumber,
                                         Satellite,
                                         Stock,
                                         TimeTvClosed,
                                         TimeTvRaised,
                                         TVRequestActual,
                                         TVRequestFaultCode,
                                         TVRequestGap,
                                         TVRequestTarget,
                                         TVTurnTimeActual,
                                         TVTurnTimeGap,
                                         TVTurnTimeTarget,
                                         PartQuantity,
                                         PreviousEngineNumber,
                                         PlannedEngineNumber,
                                         IsCollected,                                                         
                                         IsUploaded,                                                   
                                         CreatedBy,
                                         CreatedDate
                                         
                           FROM @tvHistoryTableType


                     INSERT INTO [Edc].[OT_TV_Regional_Body_Activity_Center] 
                                  (
                                  [TVDataCenterId],
                                  [Engineer1],
                                  [Status],     
                                  [CreatedBy],
                                  [CreatedDate]
                                  --[ModifiedBy],
                                  --[ModifiedDate]
                                  )      

                     SELECT 
                                  ed.Id ,
                                  ow.Id,
                                  [dbo].[GetWipStatus]('WBody',t.HeadsupDate,t.InitialPSEOrPREOrCVEIn,t.DateCompleted,t.[Owner]),
								   -- [dbo].[GetTVStatusByFlag](t.RCIComments,'StatusId'),
                                  t.CreatedBy,
                                  t.CreatedDate
                                  --t.ModifiedBy,
                                  --t.ModifiedDate
                     FROM [Edc].[OT_TV_Regional_Body_Data_Center] ed
                     INNER JOIN @tvHistoryTableType t ON t.TVNumber=ed.TVNumber
                     INNER JOIN [Edc].[ST_TV_Owner_Details] ow ON  UPPER(LTRIM(RTRIM(ow.[OwnerName])))=UPPER(LTRIM(RTRIM(t.[Owner])))
                     AND t.IssueNumber = ed.IssueNumber 



                     ------------------------------- Return the tv numbers not inserted in to database -----------------------------

                     INSERT INTO @tempTVDetails

                     SELECT TVNumber, OwnerName FROM (
                     SELECT t.TVNumber AS [TVNumber], t.[Owner] as OwnerName, ed.Id as [Id]   FROM @tvHistoryTableType t
                     LEFT JOIN [Edc].[OT_TV_Regional_Body_Data_Center] ed ON t.TVNumber=ed.TVNumber  AND t.IssueNumber = ed.IssueNumber                                   
                     )p
                     LEFT JOIN [Edc].[OT_TV_Regional_Body_Activity_Center] ac ON ac.TVDataCenterId=p.Id
                     WHERE    ac.Id is null            


                     SELECT @tvNumberError=COALESCE(@tvNumberError+ ',','')+CAST(TVNumber as nvarchar(20)) FROM @tempTVDetails
                     
                     SET @tvNumberError=@tvNumberError+'|||'

                     SELECT @tvNumberError=COALESCE(@tvNumberError+ ',','')+ISNULL(OwnerName,'') FROM  @tempTVDetails
                                  GROUP BY OwnerName
                                  

                     --SELECT      @tvNumberError=COALESCE(@tvNumberError+ ',','')+CAST(p.TVNumber as nvarchar(20)) FROM (
                     --SELECT t.TVNumber AS [TVNumber], ed.Id as [Id]   FROM @tvHistoryTableType t
                     --LEFT JOIN [Edc].[OT_TV_Wide_Body_Data_Center] ed ON t.TVNumber=ed.TVNumber  AND t.IssueNumber = ed.IssueNumber                                   
                     --)p
                     --LEFT JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON ac.TVDataCenterId=p.Id
                     --WHERE         ac.Id is null            


                                  
END
ELSE
BEGIN
       UPDATE [Edc].[OT_TV_Regional_Body_Data_Center]  
       SET
                     
                     DateIn=t.DateIn,
                     TVType=t.TVType,
                     OriginalPromisedDate=t.OriginalPromisedDate,
                     RRPromisedDate=t.RRPromisedDate,
                     HeadsupDate=t.HeadsupDate,
                     HeadsupDecision=t.HeadsupDecision,
                     CompetentAuthorIn=t.CompetentAuthorIn,
                     InitialPSEOrPREOrCVEIn=t.InitialPSEOrPREOrCVEIn,
					 DateCompleted=t.DateCompleted,
                     CompetentAuthorOut=t.CompetentAuthorOut,
                     InitialPSEOrPREOrCVEOut=t.InitialPSEOrPREOrCVEOut,
                     RREngineeringIn=t.RREngineeringIn,
                     RREngineeringOut=t.RREngineeringOut,
                     FinalPSEOrPREOrCVEIn=t.FinalPSEOrPREOrCVEIn,
                     InfoRequestedDetails=t.InfoRequestedDetails,
                     Remarks=t.Remarks,
                     CustomerRequiredDate=t.CustomerRequiredDate,
                     RCIComments=t.RCIComments,
                     Team=t.Team,
					 TeamLeader=t.TeamLeader,
                     IsCollected=t.IsCollected,                                                        
                     IsUploaded=t.IsUploaded,                               
                     ModifiedBy=t.ModifiedBy,
                     ModifiedDate=t.ModifiedDate
       

       FROM
       @tvHistoryTableType t
       WHERE [Edc].[OT_TV_Regional_Body_Data_Center].TVNumber =t.TVNumber and [Edc].[OT_TV_Regional_Body_Data_Center].IssueNumber=t.IssueNumber  
       
       SET @tvNumberError=null
	   --TV Close Activity status is updated--19--closed
	   UPDATE [Edc].OT_TV_Regional_Body_Activity_Center SET [Status]= 19 FROM [Edc].OT_TV_Regional_Body_Activity_Center ac
		INNER JOIN [Edc].[OT_TV_Regional_Body_Data_Center] ed ON ed.Id=ac.TVDataCenterId
		INNER JOIN @tvHistoryTableType t ON ed.TVNumber=t.TVNumber
		AND ed.DateCompleted is not null

		--TV Reopened Activity status is updated--3--Under Investigation
		UPDATE [Edc].OT_TV_Regional_Body_Activity_Center SET [Status]= 3 FROM [Edc].OT_TV_Regional_Body_Activity_Center ac
		INNER JOIN [Edc].[OT_TV_Regional_Body_Data_Center] ed ON ed.Id=ac.TVDataCenterId
		INNER JOIN @tvHistoryTableType t ON ed.TVNumber=t.TVNumber
		AND ed.DateCompleted is null
END

END TRY
BEGIN CATCH
       SET @tvNumberError='File Upload Failed'
   EXECUTE [dbo].[LogError]
END CATCH
END



