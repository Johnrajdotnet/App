﻿-- =============================================
--PROCEDURE: [Edc].[GetCACheckListDetails] 
--PURPOSE: Get CA checklistvalues
--CREATED: Mira 03/05/2019
-- ============================================= 
-- EXEC [Edc].[GetCACheckListDetails] 
CREATE  PROCEDURE [Edc].[GetCACheckListDetails] 
	-- Add the parameters for the stored procedure here
		@WBodyActivityId bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
	BEGIN
					SELECT cd.Id , chklist.CheckListGroupId as GroupId, chklist.CheckListGroupDescription, chklist.Category, 
					chklist.CheckpointDescription AS CheckListName, chklist.SequenceNumber AS ChecklistId, cd.ChecklistValue
					FROM       [Edc].[ST_TV_CheckList_Details] AS chklist
					LEFT JOIN  [WFlow].[OT_TV_WBody_WFlow_Checklist_Details] cd  
					ON         cd.ChecklistGroupId=chklist.CheckListGroupId AND chklist.SequenceNumber=cd.ChecklistId 
					AND    cd.WBodyActivityId=@WBodyActivityId  
					AND cd.Active=1 and cd.GroupChecklistOwner='CA'
					WHERE   chklist.Active=1  AND chklist.CheckListGroupId In (51,54,55,56)
					ORDER BY   CONVERT( INT, chklist.SequenceNumber)  ASC  
			END                       
        END TRY
        BEGIN CATCH
            EXECUTE [dbo].[LogError]
        END CATCH


END