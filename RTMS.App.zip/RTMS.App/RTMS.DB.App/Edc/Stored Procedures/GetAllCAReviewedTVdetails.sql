﻿

	-- =============================================
	-- Author:           <Neethu>
	-- Create date: <19/12/2018>
	-- Description:      <Get All TV Details - after CA Review>
    -- exec [Edc].[GetAllCAReviewedTVdetails] 26,'56b9bff0-be87-4256-bc34-9078e6d2f181','18,20,22,24,26,28,30,32,34,'
	-- =============================================
	CREATE PROCEDURE [Edc].[GetAllCAReviewedTVdetails]
		@roleId BIGINT,
		@roleUserId UNIQUEIDENTIFIER, 
		@pgmId NVARCHAR(MAX)
	AS
	BEGIN


				SELECT 	  
						   TOP 50 edc.TVNumber    as TVNumber ,
						          edc.DateIn      as DateIn,
								  edc.EngineMark  as EngineMark,
								  ad.CAStatus     as CAStatus,
								  edc.IssueNumber as IssueNumber,
								  edc.TVType      as TVType
				FROM  
						   [Admin].[Syn_ST_User_Role_Module] rm 
				INNER JOIN [Admin].[Syn_ST_Users] u					    ON u.Id=rm.UserId
				INNER JOIN [Edc].[ST_TV_Owner_Details] od			    ON od.OracleId=u.UserId
				INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ad	ON ad.CAEngineer=od.Id 
				INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] edc		ON edc.Id=ad.TVDataCenterId
				WHERE 
						    ad.CAStatus is not null
							AND ad.CASubmittedDate is not null
							AND ad.CASubmittedBy is not null 								    
							AND u.Active=1 AND od.Active=1		
							AND rm.Id=@roleUserId	
							
				ORDER BY edc.EngineMark,	edc.DateCompleted DESC						   			     
				
	END



	         