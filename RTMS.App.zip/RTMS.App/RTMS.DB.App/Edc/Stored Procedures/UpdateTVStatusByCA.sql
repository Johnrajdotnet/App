﻿
-- =============================================
--PROCEDURE: [Edc].[UpdateTVStatusByCA]
--PURPOSE: Update tv statusby competent author
--CREATED: Neethu 14/12/2018
-- ============================================= 
-- EXEC [Edc].[UpdateTVStatusByCA]

CREATE PROCEDURE [Edc].[UpdateTVStatusByCA]
	-- Add the parameters for the stored procedure here
	@tvStatus           BIT,
	@tvActivityDetailId BIGINT,
	@userId             UNIQUEIDENTIFIER
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY

	IF(@tvStatus=1) --SUccess :TV Draft sumbitted is OK :Hence Approve TV
		 BEGIN
			UPDATE Edc.[OT_TV_Wide_Body_Activity_Center]
			SET 
			CASubmittedBy   = @userId,
			CASubmittedDate = getdate(),
			CAStatus        = @tvStatus
			WHERE Id=@tvActivityDetailId
		END
	ELSE IF(@tvStatus=0) --SUccess :TV Draft sumbitted is OK :Hence Demote TV
		BEGIN
			UPDATE Edc.[OT_TV_Wide_Body_Activity_Center]
			SET 
			CASubmittedBy      = @userId,
			CASubmittedDate    = getdate(),
			CAStatus           = @tvStatus,
			DraftSubmittedBy   = null,
			DraftSubmittedDate = null
			WHERE Id=@tvActivityDetailId
		END
			
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END