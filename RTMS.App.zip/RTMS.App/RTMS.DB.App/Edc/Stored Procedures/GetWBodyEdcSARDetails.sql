﻿-- =============================================
-- Author:           <Blessy>
-- Create date:      <17/10/2018>
-- Description:      <Retrives RedTopDetails from [Edc].[OT_TV_Wide_Body_RedTop_Center]
-- exec [Edc].[GetWBodyEdcSARDetails] '500,700,800,900,1000,XWB-84,XWB-97','1','','',''
CREATE PROCEDURE [Edc].[GetWBodyEdcSARDetails] 

       @enginetype nvarchar(50),  
	   @Status int,
	   @keyword nvarchar(100)
AS
BEGIN TRY
   
				SELECT 
				[Id]                AS Id,
				ROW_NUMBER()OVER(ORDER BY([Id])) AS RowNumber,
				[SARNumber]         AS SARNumber,
				[EngineType]        AS EngineType,
				[Title]             AS Title,
				[Type]              AS Type,
				[Location]          AS Location,
				[DateRaised]        AS DateRaised,
				[DateClosed]        AS DateClosed,
				[ReasonForSAR]      AS ReasonForSAR,
				[AttributableSCU]   AS AttributableSCU,
				[GenericOwner]      AS GenericOwner,
				[RCINumber]         AS RCINumber,
				[SAROwner]          AS SAROwner,
				[AccountableManager]AS AccountableManager,
				[OriginalTarget]    AS OriginalTarget,
				[ReCommitment]      AS ReCommitment,
				[CurrentGate]       AS CurrentGate,
				[Age]               AS Age,
				[Blocker]           AS Blocker,
				[NextReview]        AS NextReview,
				[ClosureMethod]     AS ClosureMethod,
				[RedTopNumber]      AS RedTopNumber,
				[CreatedBy]         AS CreatedBy,
				[CreatedDate]       AS CreatedDate,
				[ModifiedBy]        AS ModifiedBy,
				[ModifiedDate]      AS ModifiedDate

				FROM   [Edc].[OT_TV_Wide_Body_Sar_Center]
				WHERE ([EngineType] IN (SELECT * FROM [dbo].[StringToTableValue](@enginetype,','))
				 OR    [EngineType] like '%'+@enginetype+'%'
				 OR    [EngineType] = CASE WHEN @enginetype<>'ALL' THEN @enginetype ELSE [EngineType] END)
				 AND  (Isnull([Title],-1) like ISNULL(@keyword,Isnull([Title],-1))
				 OR    [Title] like'%'+@keyword+'%'
				 OR    Isnull([ReasonForSAR],-1) like ISNULL(@keyword,Isnull([ReasonForSAR],-1))
				 OR    [ReasonForSAR] like'%'+@keyword+'%')
				 AND   (CASE WHEN DateClosed is null THEN 1 ELSE 2 END)=@Status
				ORDER BY [DateRaised] desc
			
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

