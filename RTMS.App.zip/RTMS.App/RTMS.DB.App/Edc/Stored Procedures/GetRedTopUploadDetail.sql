﻿
-- =============================================
-- Author:           <Mira>
-- Create date:      <26/02/2019>
-- Description:      <Retrives SarTopDetails from [Edc].[OT_TV_Wide_Body_Sar_Center]
-- exec [Edc].[GetSarTopUploadDetail] 
CREATE PROCEDURE [Edc].[GetSarTopUploadDetail] 
@TVSarCenter [Edc].[TVSarCenter] READONLY
AS
BEGIN TRY
   
				SELECT 
							otsc.[Id]                AS Id,
							ROW_NUMBER()OVER(ORDER BY(otsc.[Id])) AS RowNumber,
							otsc.[SARNumber]         AS SARNumber,
							otsc.[EngineType]        AS EngineType,
							otsc.[Title]             AS Title,
							otsc.[Type]              AS Type,
							otsc.[Location]          AS Location,
							otsc.[DateRaised]        AS DateRaised,
							otsc.[DateClosed]        AS DateClosed,
							otsc.[ReasonForSAR]      AS ReasonForSAR,
							otsc.[AttributableSCU]   AS AttributableSCU,
							otsc.[GenericOwner]      AS GenericOwner,
							otsc.[RCINumber]         AS RCINumber,
							otsc.[SAROwner]          AS SAROwner,
							otsc.[AccountableManager]AS AccountableManager,
							otsc.[OriginalTarget]    AS OriginalTarget,
							otsc.[ReCommitment]      AS ReCommitment,
							otsc.[CurrentGate]       AS CurrentGate,
							otsc.[Age]               AS Age,
							otsc.[Blocker]           AS Blocker,
							otsc.[NextReview]        AS NextReview,
							otsc.[ClosureMethod]     AS ClosureMethod,
							otsc.[RedTopNumber]      AS RedTopNumber,
							otsc.[CreatedBy]         AS CreatedBy,
							otsc.[CreatedDate]       AS CreatedDate,
							otsc.[ModifiedBy]        AS ModifiedBy,
							otsc.[ModifiedDate]      AS ModifiedDate
				FROM        [Edc].[OT_TV_Wide_Body_Sar_Center] otsc
				INNER JOIN  @TVSarCenter stn ON  stn.SARNumber= otsc.SARNumber AND stn.EngineType=otsc.EngineType     
			
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH


