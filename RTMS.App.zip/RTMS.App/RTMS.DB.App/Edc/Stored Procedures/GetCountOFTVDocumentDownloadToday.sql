﻿
CREATE PROCEDURE [Edc].[GetCountOFTVDocumentDownloadToday]
       
AS
BEGIN TRY
	 DECLARE @totalCount int, @totalCompletedCount int,@totalDownloadYester int,@totalDownloadToday int,@faultCount int
     DECLARE @edcTVDownload TABLE
		(
			Id INT IDENTITY(1, 1)PRIMARY KEY,
			ActionName nvarchar(max),
			DownloadYesterday INT,
			TotalCount int,
			TotalDownload int,
			DownloadToday int,
			AvgDownload   int,
			FaultCount int
		)  

---------------------------Count of tvs downloaded today machine 1--------------------------
        INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount)
		SELECT ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount FROM [Edc].[GetCountOfDownloadTVDocuments] (1)
              
-------------------------Count of tvs downloaded today machine 2----------------------
       INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount)
	   SELECT ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount FROM [Edc].[GetCountOfDownloadTVDocuments] (2)
--------------------------Count of tvs downloaded today machine 3----------------- 
       INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount)
	   SELECT ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount FROM [Edc].[GetCountOfDownloadTVDocuments] (3)                                                                                                                                    
      
----------------------------Count of tvs downloaded today machine 4----------------- 
       INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount)
	   SELECT ActionName,DownloadYesterday,TotalCount,TotalDownload,DownloadToday,FaultCount FROM [Edc].[GetCountOfDownloadTVDocuments] (4)
----------------------------------------------------------------------------------------------
               
		SELECT @totalCount= SUM(TotalCount)  FROM @edcTVDownload
		SELECT @totalCompletedCount= SUM(TotalDownload)  FROM @edcTVDownload
		SELECT @totalDownloadYester= SUM(DownloadYesterday)  FROM @edcTVDownload
		SELECT @totalDownloadToday= SUM(DownloadToday)  FROM @edcTVDownload
		SELECT @faultCount=SUM(FaultCount) FROM @edcTVDownload
			                                                                 
        SELECT Id AS Id, ActionName AS MachineName,  DownloadYesterday AS DownloadYesterday,DownloadToday AS DownloadToday,TotalCount AS TotalCountOfRecords,TotalDownload AS CompletedDownload,FaultCount AS FaultTVCount --,AvgDownload as AverageDownload
		FROM @edcTVDownload
		 
		SELECT @totalCount AS TotalSumOfRecords,@totalCompletedCount AS TotalSumOfDownloadCompleted,@totalDownloadYester as SumOfDwonloadYesterday,@totalDownloadToday as SumDownloadToday,@faultCount AS SumOfFaultTVCount

		 
  

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

