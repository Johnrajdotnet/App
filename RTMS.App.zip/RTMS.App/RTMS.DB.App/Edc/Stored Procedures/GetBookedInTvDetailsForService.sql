﻿-- =============================================
-- Author:           <Blessy>
-- Create date:            <25/04/2019>
-- Description:      <Retrives TV Drawing Details from [Edc].[OT_TV_Drawing_Details]>
-- [Edc].[GetBookedInTvDetailsForService] 4
CREATE PROCEDURE [Edc].[GetBookedInTvDetailsForService] 
@machineIndex int
AS
BEGIN TRY
            
              SELECT top 10 do.[TVNumber]  AS TVNumber,
			                dc.IssueNumber AS IssueNumber,
							dc.TVType      AS TVType
					                        
              FROM  [Edc].[OT_TV_Wide_Body_BookedIn_Documents_Details] do
			  INNER JOIN  [Edc].[OT_TV_Wide_Body_Data_Center] dc ON 
			  (dc.TVNumber=do.TVNumber AND do.ProcessVersion=[Edc].[GetProcessVersion](dc.IssueNumber))
			  			  
			  WHERE do.Active=0
			  AND   do.[IterationCount] < 3
			 -- AND   do.[MachineIndex]=@machineIndex
             
END TRY  
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH