﻿-- =============================================
-- Author:           <Mira>
-- Create date:            <07/03/2019>
-- Description:      <Retrives TV Drawing Details from [Edc].[OT_TV_Drawing_Details]>
-- [Edc].[GetTvDrawingDetails] 
CREATE PROCEDURE [Edc].[GetTvDrawingDetails] 

AS
BEGIN TRY
              
               SELECT   [FileName]                AS FileName,
                        [PartNumber]              AS PartNumber,
                        [PartDescription]         AS PartDescription,
                        CONVERT(date,[IssueDate]) AS IssueDate,
                        [Revision]                AS Revision,
                        [Series]                  AS Series,
                        [FilePath]                AS FilePath,
						[CpiritLink]			  AS CpiritLink
                         
              FROM   [Edc].[OT_TV_Drawing_Details]
                           
              WHERE  [Active]=1 ORDER BY CreatedDate DESC
                           

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH