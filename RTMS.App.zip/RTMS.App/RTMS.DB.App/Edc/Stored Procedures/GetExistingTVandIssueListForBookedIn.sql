﻿-- =============================================
-- Author:           <Blessy>
-- Create date: <16/02/2018>
-- Description:      <Check for Duplicate TVNumber Existence>
-- [Edc].[GetExistingTVandIssueListForBookedIn] '100001,159915,182393,183503,162727,167475,170526,170669,176216,176217,176219,176308,183146,183993,178291,182948,178135,178922,181838,183532,180061,180118,180307,180669,180675,180704,180786,180792,180967,180978,181119,181292','3,3,1,1,3,1,1,2,1,2,2,2,2,1,1,1,1,2,3,1,1,1,2,1,1,1,1,4,1,1,3,1'
-- =============================================
CREATE PROCEDURE [Edc].[GetExistingTVandIssueListForBookedIn]
       -- Add the parameters for the stored procedure here
       @TvNumberList nvarchar(max),
	   @issueNumberList nvarchar(max)
AS
BEGIN
		
       
		DECLARE @temptable TABLE
        (
            Id INT IDENTITY(1,1),
            TVNumber INT,
			ProcessVersion nVarchar(20),
			ActionFlag NVARCHAR(20)
        ) 
		INSERT @temptable	
		SELECT 
				tvp.Item,i.Item, 'UPDATE' FROM  [Edc].[OT_TV_Wide_Body_BookedIn_Documents_Details] tv
		CROSS APPLY 
				dbo.StringToTableValueWithIdentity(@TvNumberList, ',') tvp 
		CROSS APPLY 
				dbo.StringToTableValueWithIdentity(@issueNumberList, ',') i
		WHERE  tvp.Id=i.Id 
		AND	TVNumber =tvp.Item 
		AND	ProcessVersion= [Edc].[GetProcessVersion](i.item)
		GROUP BY tvp.Item,i.Item  

	
		
		INSERT @temptable
		SELECT tp.TVNumber,tp.ProcessVersion,'ADD' FROM		
		(
		SELECT 
				tvp.Item as TVNumber,i.Item as ProcessVersion
		FROM	dbo.StringToTableValueWithIdentity(@TvNumberList, ',') tvp
		INNER JOIN 
				dbo.StringToTableValueWithIdentity(@issueNumberList, ',') i ON tvp.Id=i.Id 
		)tp		
		LEFT JOIN @temptable tt ON tt.TVNumber=tp.TVNumber AND tt.ProcessVersion=tp.ProcessVersion
		WHERE tt.ProcessVersion is null
		
		SELECT * FROM @temptable

END

