﻿-- =============================================
--PROCEDURE: [Edc].[UpdateTVDetailsForService]
--PURPOSE: Update tv statusby competent author
--CREATED: Blessy 25/04/2019
-- ============================================= 
-- EXEC [Edc].[UpdateBookedInTVDocumentDetails]
CREATE PROCEDURE [Edc].[UpdateBookedInTVIterationCount]
	-- Add the parameters for the stored procedure here
	@tvNumber  BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRY
	BEGIN
		
			UPDATE [Edc].[OT_TV_Wide_Body_BookedIn_Documents_Details]
			SET 
			[IterationCount]+=1,
			[ModifiedDate]=GETDATE()
			WHERE [TVNumber]=@tvNumber
		END
			
	END TRY
		BEGIN CATCH
		    EXECUTE [dbo].[LogError]
		END CATCH
END