﻿-- =============================================
-- Author:           Arathy
-- Create date: 5/8/2018
-- Description:      Insert TV information from excel to Database 
-- =============================================
CREATE PROCEDURE [Edc].[InsertNewTVInfoForBookedInDoc] 
       -- Add the parameters for the stored procedure here
@tvHistoryTableType [Edc].[TVEngineDataCenterType] READONLY

AS
BEGIN  
       DECLARE @tempTVDetails TABLE (Id INT IDENTITY (1,1), TVNumber INT, OwnerName NVARCHAR(200))
	   
       SET NOCOUNT ON;      
BEGIN TRY

                     INSERT INTO [Edc].[OT_TV_Wide_Body_BookedIn_Documents_Details]
                           (
                                         TVNumber,
										 ProjectNamePath,
										 ContentPath,
										 ProcessVersion,
										 IterationCount,
										 Active,
                                         CreatedBy,
                                         CreatedDate
                                         
                           )

                           SELECT 
                                         TVNumber,
										 2245,
										 [Edc].[GetContentPathForDocuments](TVNumber,TVType),                                                    
                                         [Edc].[GetProcessVersion](IssueNumber),  
                                         0,
										 0,                                        
                                         CreatedBy,
                                         CreatedDate
                                         
                           FROM @tvHistoryTableType                     
					
END TRY
BEGIN CATCH      
   EXECUTE [dbo].[LogError]
END CATCH
END

