﻿
-- =============================================
-- Author:           <Arathy>
-- Create date:		 <07/05/2018>
-- Description:      <Retrives >
-- exec [Edc].[GetMaxOfDateCompleted]
CREATE PROCEDURE [Edc].[GetMaxOfDateCompleted] 
  
AS
BEGIN TRY

	SELECT MAX(DateCompleted)  AS MaxDateCompleted 
	FROM   [Edc].[OT_TV_Wide_Body_Data_Center]
	
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH