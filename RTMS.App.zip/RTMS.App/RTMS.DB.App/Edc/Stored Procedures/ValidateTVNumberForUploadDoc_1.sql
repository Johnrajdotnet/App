﻿-- =============================================
-- Author:           <Blessy Babu>
-- Create date: <20/03/2017>
-- Description:      <Gets List oF TV details which doesn't have Signed Documents>
-- =============================================
-- exec [Edc].[ValidateTVNumberForUploadDoc] '132840'

CREATE PROCEDURE [Edc].[ValidateTVNumberForUploadDoc]
@fileName  VARCHAR(50)
AS
BEGIN

       SET NOCOUNT ON;
       BEGIN TRY
              BEGIN

			   SELECT 
			          TVNumber     AS TvNumber,
			          TVType       AS TvType,
					  IssueNumber  AS IssueNumber

			   FROM [Edc].[OT_TV_Wide_Body_Data_Center] 

			   WHERE CAST(TVNumber AS NVARCHAR(50))= @fileName 
			     AND DateCompleted IS NOT NULL 
			      OR DateCompleted=''						 
              END    
              
       END TRY

       BEGIN CATCH
       EXECUTE [dbo].[LogError]
       END CATCH
END

