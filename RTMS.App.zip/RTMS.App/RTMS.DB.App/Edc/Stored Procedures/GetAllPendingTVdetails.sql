﻿
	-- =============================================
	-- Author:           <Mira Kumari>
	-- Create date:		 <11/09/2018>
	-- Description:      <Get All Pending TV Details>
	-- exec [Edc].[GetAllPendingTVdetails] 31,'8A2B88DD-6889-4169-A21D-3423038F8165','28,30,60,62,92,94'
	-- =============================================
	CREATE PROCEDURE [Edc].[GetAllPendingTVdetails]
		@roleId BIGINT,
		@roleUserId UNIQUEIDENTIFIER, 
		@pgmId NVARCHAR(MAX)
	AS
	BEGIN

		IF(@roleId<>1)
			BEGIN


				SELECT 	  
						   TOP 100 edc.TVNumber , edc.DateIn,edc.EngineMark
				FROM  
						   [Admin].[Syn_ST_User_Role_Module] rm 
				INNER JOIN [Admin].[Syn_ST_Users] u						    ON u.Id=rm.UserId
				INNER JOIN [Edc].[ST_TV_Owner_Details] od			    ON od.OracleId=u.UserId
				INNER JOIN [Edc].[OT_TV_Wide_Body_Activity_Center] ad	ON (ad.Engineer1=od.Id OR ad.Engineer2=od.Id)
				INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] edc		ON edc.Id=ad.TVDataCenterId
				WHERE 
						    edc.DateCompleted is null 								    
							AND u.Active=1 AND od.Active=1		
							AND rm.Id=@roleUserId
							AND ad.HeadupSubmittedBy is null
							AND ad.HeadupSubmittedDate is  null
				ORDER BY edc.DateIn desc					   			     
			END
		ELSE
			BEGIN
				SELECT    
						   TOP 100 edc.TVNumber , edc.DateIn,edc.EngineMark
				FROM  
						   [Edc].[OT_TV_Wide_Body_Activity_Center] ad
				INNER JOIN [Edc].[OT_TV_Wide_Body_Data_Center] edc ON edc.Id=ad.TVDataCenterId
				WHERE 
						    edc.DateCompleted is null 
							AND ad.HeadupSubmittedBy is null
							AND ad.HeadupSubmittedDate is null	
				ORDER BY edc.DateIn desc				
			END
	END
