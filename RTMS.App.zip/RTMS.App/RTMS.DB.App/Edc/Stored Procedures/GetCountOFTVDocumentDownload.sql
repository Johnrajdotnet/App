﻿
-- =============================================
-- Author:           arathy
-- Create date:      03/27/2018
-- Description:      Test the Syncupdate status
-- [Edc].[GetCountOFTVDocumentDownload]
-- =============================================
CREATE PROCEDURE [Edc].[GetCountOFTVDocumentDownload]
       
AS
BEGIN TRY

       DECLARE @edcTVDownload TABLE
		(
			Id INT IDENTITY(1, 1)PRIMARY KEY,
			ActionName nvarchar(max),
			DownloadYesterday INT,
			TotalCount int,
			TotalDownload int
			
		)

        DECLARE @count INT,@totalCountOfRecords INT,@completedDownload int
        DECLARE @list nvarchar(max)   
        BEGIN       

---------------------------Count of tvs downloaded today machine 1--------------------------
		SET  @count = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE Active=1 and MachineIndex=1 and ModifiedDate >CONVERT(nvarchar(10),GETDATE(),112))
		SET  @totalCountOfRecords = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=1 )
		SET  @completedDownload = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=1  and active=1)
		      
		INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload)
		SELECT  'Machine1',@count,@totalCountOfRecords,@completedDownload
              
-------------------------Count of tvs downloaded today machine 2----------------------
       SET  @count = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE Active=1 and machineIndex=2 and ModifiedDate > CONVERT(nvarchar(10),GETDATE(),112))
		SET  @totalCountOfRecords = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=2 )
		SET  @completedDownload = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=2  and active=1)
		      
		INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload)
		SELECT  'Machine2',@count,@totalCountOfRecords,@completedDownload
--------------------------Count of tvs downloaded today machine 3----------------- 
                                                                                                                                                        
       SET  @count = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE Active=1 and machineIndex=3 and ModifiedDate > CONVERT(nvarchar(10),GETDATE(),112))
		SET  @totalCountOfRecords = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=3)
		SET  @completedDownload = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=3  and active=1)
		      
		INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload)
		SELECT  'Machine3',@count,@totalCountOfRecords,@completedDownload

----------------------------Count of tvs downloaded today machine 4----------------- 
         SET  @count = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE Active=1 and machineIndex=4 and ModifiedDate > CONVERT(nvarchar(10),GETDATE(),112))
		SET  @totalCountOfRecords = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=4)
		SET  @completedDownload = (SELECT COUNT(1) FROM [Edc].[OT_TV_Wide_Body_Documents_Details] WHERE machineIndex=4  and active=1)
		      
		INSERT INTO @edcTVDownload (ActionName,DownloadYesterday,TotalCount,TotalDownload)
		SELECT  'Machine4',@count,@totalCountOfRecords,@completedDownload

----------------------------------------------------------------------------------------------
                                                                             
        SELECT Id as Id, ActionName as MachineName,  DownloadYesterday as DownloadYesterday,TotalCount as TotalCountOfRecords,TotalDownload AS CompletedDownload FROM @edcTVDownload

       END

END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

