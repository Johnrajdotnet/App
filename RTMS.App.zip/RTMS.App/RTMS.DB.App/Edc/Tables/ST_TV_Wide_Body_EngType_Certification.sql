﻿CREATE TABLE [Edc].[ST_TV_Wide_Body_EngType_Certification]
(
	[Id]							BIGINT				IDENTITY (1, 1) NOT NULL,
	[EngineType]                    NVARCHAR(250)       NOT NULL,
	[EngineSeries]                  NVARCHAR(250)       NULL,
	[Enginemark]                    NVARCHAR(250)       NOT NULL,
	[TvCertification]               NVARCHAR(MAX)       NULL,
	[CertificationBasis]            NVARCHAR(MAX)       NULL,
	[Active]                        BIT                 NULL,
	[CreatedDate]					DATETIME			NOT NULL,
	[ModifiedDate]					DATETIME			NULL,
	CONSTRAINT [PK_ST_TV_Wide_Body_EngType_Certification] PRIMARY KEY CLUSTERED ([Id] ASC),
    
)
