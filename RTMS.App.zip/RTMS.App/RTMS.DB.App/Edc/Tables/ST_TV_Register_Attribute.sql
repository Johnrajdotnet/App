﻿CREATE TABLE [Edc].[ST_TV_Register_Attribute] (
    [Id]               BIGINT         IDENTITY (1, 1) NOT NULL,
    [AttributeGroupId] INT            NULL,
    [AttributeName]    NVARCHAR (100) NULL,
    [AttributeValue]   NVARCHAR (100) NOT NULL,
    [Active]           BIT			  NOT NULL,
    [CreateDate]       DATETIME       NULL,
    [ModifiedDate]     DATETIME       NULL,
    CONSTRAINT [PK_ST_TV_Register_Attribute] PRIMARY KEY CLUSTERED ([Id] ASC)
);

