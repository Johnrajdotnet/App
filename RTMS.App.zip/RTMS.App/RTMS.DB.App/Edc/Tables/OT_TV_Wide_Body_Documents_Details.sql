﻿CREATE TABLE [Edc].[OT_TV_Wide_Body_Documents_Details]
(
	[Id]                      INT  IDENTITY(1,1)   NOT NULL, 
    [TVNumber]                BIGINT               NOT NULL, 
    [FileName]                NCHAR(250)           NULL, 
    [ProjectNamePath]         NCHAR(1000)          NOT NULL, 
    [ContentPath]             NCHAR(250)           NOT NULL, 
    [ProcessVersion]          NCHAR(20)            NOT NULL, 
	[ActualFileCount]         INT                  NULL,
	[ExpectedFileCount]       INT                  NULL,
	[IterationCount]          INT                  NULL,
	[DownloadAllSuccess]      BIT                  NULL,
	[MachineIndex]			  INT                  NULL,
    [Active]                  BIT                  NOT NULL, 
    [CreatedBy]               UNIQUEIDENTIFIER     NOT NULL, 
    [CreatedDate]             DATETIME             NOT NULL, 
    [ModifiedBy]              UNIQUEIDENTIFIER     NULL, 
    [ModifiedDate]            DATETIME             NULL,

CONSTRAINT [PK_TV.OT_TV_Wide_Body_Documents_File_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
CONSTRAINT [FK_OT_TV_WBody_WFlow_Documents_File_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
CONSTRAINT [FK_OT_TV_WBody_WFlow_Documents_File_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
)
