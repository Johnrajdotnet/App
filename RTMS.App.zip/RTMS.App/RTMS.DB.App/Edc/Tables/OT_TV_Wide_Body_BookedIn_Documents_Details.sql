﻿
CREATE TABLE [Edc].[OT_TV_Wide_Body_BookedIn_Documents_Details](
	[Id]                       INT      IDENTITY(1,1) NOT NULL,
	[TVNumber]                 BIGINT                 NOT NULL,
	[FileName]                 NVARCHAR(250)              NULL,
	[ProjectNamePath]          NVARCHAR(1000)             NULL,
	[ContentPath]              NVARCHAR(250)              NULL,
	[ProcessVersion]           NVARCHAR(20)               NULL,
	[ActualFileCount]          INT                        NULL,
	[ExpectedFileCount]        INT                        NULL,
	[IterationCount]           INT                        NULL,
	[DownloadAllSuccess]       BIT                        NULL,
	[Active]                   BIT                    NOT NULL,
	[MachineIndex]             INT                        NULL,
	[CreatedBy]                UNIQUEIDENTIFIER       NOT NULL,
	[CreatedDate]              DATETIME               NOT NULL,
	[ModifiedBy]               UNIQUEIDENTIFIER           NULL,
	[ModifiedDate]             DATETIME                   NULL,
 CONSTRAINT [PK_TV.OT_TV_Wide_Body_BookedIn_Documents_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
 CONSTRAINT [FK_OT_TV_Wide_Body_BookedIn_Documents_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
 CONSTRAINT [FK_OT_TV_Wide_Body_BookedIn_Documents_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
 )

