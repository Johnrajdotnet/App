﻿CREATE TABLE [Edc].[ST_TV_Owner_Details]
(
	[Id]               INT            IDENTITY (1, 1) NOT NULL,	
	[OracleId]		   BIGINT         NULL,
    [OwnerName]		   NVARCHAR (100) NOT NULL,
	[Location]		   NVARCHAR (100) NULL,
    [Active]           BIT			  NOT NULL,
    [CreateDate]       DATETIME       DEFAULT (getdate()) NOT NULL,
    [ModifiedDate]     DATETIME       NULL,
    CONSTRAINT [PK_ST_TV_Owner_Details] PRIMARY KEY CLUSTERED ([Id] ASC)
)
