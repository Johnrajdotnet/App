﻿CREATE TABLE [Edc].[OT_TV_Regional_Body_Log_Center]
(
	[Id]							BIGINT				IDENTITY (1, 1) NOT NULL ,
	[TVDataCenterActivityId]		BIGINT				NOT NULL,
	[FieldName]						NVARCHAR(250)		NOT NULL,
	[FieldValue]					NVARCHAR(250)		NOT NULL,
	[FieldBy]						UNIQUEIDENTIFIER	NOT NULL,
	[FieldDate]						DATETIME	NOT NULL,
	[CreatedBy]						UNIQUEIDENTIFIER	NOT NULL,
	[CreatedDate]					DATETIME			NOT NULL CONSTRAINT [DF__OT_TV_Regional_Body_Log_Center_CreateDate]  DEFAULT (GETDATE()),
	[ModifiedBy]					UNIQUEIDENTIFIER	NULL,
	[ModifiedDate]					DATETIME			NULL,
	CONSTRAINT [PK_TV.OT_TV_Regional_Body_Log_Center] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_TV_Regional_Body_Log_Center_OT_TV_Data_Center_Extender_Details] FOREIGN KEY ([TVDataCenterActivityId]) REFERENCES [Edc].[OT_TV_Regional_Body_Activity_Center] ([Id]),
	CONSTRAINT [FK_OT_TV_Regional_Body_Log_Center_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
    CONSTRAINT [FK_OT_TV_Regional_Body_Log_Center_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
)
