﻿CREATE TABLE [Edc].[ST_TV_Wide_Body_Manual_Ref]
(
	[Id]							BIGINT				IDENTITY (1, 1) NOT NULL,
	[EngineType]                    NVARCHAR(250)       NULL,
	[EngineSeries]                  NVARCHAR(250)       NOT NULL,
	[ManualTitle]                   NVARCHAR(MAX)       NULL,
	[Publication]                   NVARCHAR(MAX)       NULL,
	[PublicationReference]          NVARCHAR(MAX)       NULL,
	[Active]                        BIT                 NULL,
	[CreatedDate]					DATETIME			NOT NULL,
	[ModifiedDate]					DATETIME			NULL,
	CONSTRAINT [PK_ST_TV_Wide_Body_Manual_Ref] PRIMARY KEY CLUSTERED ([Id] ASC),
    
)
