﻿CREATE TABLE [dbo].[ST_TV_CheckList_Details]
(
	[Id]  INT IDENTITY(1,1) NOT NULL, 
	[CheckListGroupId] [int] NULL,
	[CheckListGroupDescription] [nvarchar](max) NULL,
	[Category] [nvarchar](200) NULL,
	[SubCategory] [nvarchar](200) NULL,
	[CheckpointNumber] [varchar](100) NOT NULL,
	[CheckpointDescription] [nvarchar](max) NULL,
	[DefectOpportunityNumber] [nvarchar](max) NULL,
	[DefectDescription] [nvarchar](max) NULL,
	[SequenceNumber] [int] NULL,
	[Active] [int] NULL,
    CONSTRAINT [PK_ST_TV_CheckList_Details] PRIMARY KEY ([Id]) 
)
