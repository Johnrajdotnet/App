﻿CREATE TABLE [Edc].[OT_TV_Wide_Body_RedTop_Center]
(
	[Id]							BIGINT				IDENTITY (1, 1) NOT NULL,
	RedTopReference					NVARCHAR(250)		NOT NULL,
	EngineType						NVARCHAR(250)		NULL,
	[Type]							NVARCHAR(250)		NULL,
	[Title]							NVARCHAR(250)		NULL,
	[DateRaised]					DATETIME			NULL,
	[DateClosed]					DATETIME			NULL,			
	[Mks]							NVARCHAR(250)		NULL,
	[Remark] [nvarchar](500) NULL,
	[FileName] [nchar](100) NULL,
	[CreatedBy]						UNIQUEIDENTIFIER	NOT NULL,
	[CreatedDate]					DATETIME			NOT NULL CONSTRAINT [DF__OT_TV_Wide_Body_RedTop_Center_CreateDate]  DEFAULT (GETDATE()),
	[ModifiedBy]					UNIQUEIDENTIFIER	NULL,
	[ModifiedDate]					DATETIME			NULL,
	[Active] [bit] NULL CONSTRAINT [DF_OT_TV_Wide_Body_RedTop_Center_Active]  DEFAULT ((1)),
	CONSTRAINT [PK_TV.OT_TV_Wide_Body_RedTop_Center] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [IX_OT_TV_Wide_Body_RedTop_Center] UNIQUE (RedTopReference ASC) WITH (IGNORE_DUP_KEY = ON),
	CONSTRAINT [FK_OT_TV_Wide_Body_RedTop_Center_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
    CONSTRAINT [FK_OT_TV_Wide_Body_RedTop_Center_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy]) REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
)
