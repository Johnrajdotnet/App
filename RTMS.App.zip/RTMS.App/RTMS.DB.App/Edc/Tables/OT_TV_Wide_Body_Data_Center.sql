﻿
CREATE TABLE [Edc].[OT_TV_Wide_Body_Data_Center](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TVNumber] [bigint] NOT NULL,
	IssueNumber	INT NOT NULL,
	[TVNumberExtension] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[Certification] [nvarchar](max) NULL,
	[Classification] [nvarchar](max) NULL,
	[TVType] [nvarchar](max) NULL,
	[Team] [nvarchar](max) NULL,
	[TeamLeader] [nvarchar](max) NULL,
	[Complexity] [nvarchar](max) NULL,
	[RRPromisedDate] [datetime] NULL,
	[StreamerCategory] [nvarchar](max) NULL,
	[ServiceLevelCategory] [nvarchar](max) NULL,
	[AircraftNumber] [nvarchar](max) NULL,
	[Applicant] [nvarchar](max) NULL,
	[ApplicantsReference] [nvarchar](max) NULL,
	[ATA] [nvarchar](max) NULL,
	[BriefProblem] [nvarchar](max) NULL,
	[ClockStopDate] [datetime] NULL,
	[CompetentAuthorActual] [nvarchar](max) NULL,
	[CompetentAuthorFaultCode] [nvarchar](max) NULL,
	[CompetentAuthorGap] [nvarchar](max) NULL,
	[CompetentAuthorIn] [datetime] NULL,
	[CompetentAuthorOut] [datetime] NULL,
	[CompetentAuthorTarget] [nvarchar](max) NULL,
	[CSN] [nvarchar](max) NULL,
	[CSR] [nvarchar](max) NULL,
	[CustomerRequiredDate] [datetime] NULL,
	[DateCompleted] [datetime] NULL,
	[DateIn] [datetime] NULL,
	[DateInfoRequested] [datetime] NULL,
	[DateInfoSupplied] [datetime] NULL,
	[Disposition] [nvarchar](max) NULL,
	[EmpLevel] [nvarchar](max) NULL,
	[EngineMark] [nvarchar](max) NULL,
	[EnginePosition] [nvarchar](max) NULL,
	[ESN] [nvarchar](max) NULL,
	[ESNPlanned] [nvarchar](max) NULL,
	[FinalPSEOrPREOrCVEActual] [nvarchar](max) NULL,
	[FinalPSEOrPREOrCVEFaultCode] [nvarchar](max) NULL,
	[FinalPSEOrPREOrCVEGap] [nvarchar](max) NULL,
	[FinalPSEOrPREOrCVEIn] [datetime] NULL,
	[FinalPSEOrPREOrCVEOut] [datetime] NULL,
	[FinalPSEOrPREOrCVETarget] [nvarchar](max) NULL,
	[FRSNumber] [nvarchar](max) NULL,
	[HeadsupDate] [datetime] NULL,
	[HeadsupDecision] [nvarchar](max) NULL,
	[HeadsupDecisionActual] [nvarchar](max) NULL,
	[HeadsupDecisionFaultCode] [nvarchar](max) NULL,
	[HeadsupDecisionGap] [nvarchar](max) NULL,
	[HeadsupDecisionTarget] [nvarchar](max) NULL,
	[HeadsWupNonDeliveryFaultCode] [nvarchar](max) NULL,
	[HSN] [nvarchar](max) NULL,
	[HSR] [nvarchar](max) NULL,
	[InductionDate] [datetime] NULL,
	[InfoRequestedDetails] [nvarchar](max) NULL,
	[InitialPSEOrPREOrCVEActual] [nvarchar](max) NULL,
	[InitialPSEOrPREOrCVEFaultCode] [nvarchar](max) NULL,
	[InitialPSEOrPREOrCVEGap] [nvarchar](max) NULL,
	[InitialPSEOrPREOrCVEIn] [datetime] NULL,
	[InitialPSEOrPREOrCVEOut] [datetime] NULL,
	[InitialPSEOrPREOrCVETarget] [nvarchar](max) NULL,
	[KittingDate] [datetime] NULL,
	[LifingAndIntegrityIn] [nvarchar](max) NULL,
	[LifingAndIntegrityOut] [nvarchar](max) NULL,
	[MainOverhaulBase] [nvarchar](max) NULL,
	[ModuleNumber] [nvarchar](max) NULL,
	[NSP] [nvarchar](max) NULL,
	[Operator] [nvarchar](max) NULL,
	[OrganisationsOutsideRRIn] [nvarchar](max) NULL,
	[OrganisationsOutsideRROut] [nvarchar](max) NULL,
	[OriginalHeadsupDecision] [nvarchar](max) NULL,
	[OriginalPromisedDate] [datetime] NULL,
	[PartDescription] [nvarchar](max) NULL,
	[PartNumber] [nvarchar](max) NULL,
	[PartSerialNumber] [nvarchar](max) NULL,
	[PlannedReBuild] [nvarchar](max) NULL,
	[Problem] [nvarchar](max) NULL,
	[QualityScore] [nvarchar](max) NULL,
	[RCIComments] [nvarchar](max) NULL,
	[RCIDecision] [nvarchar](max) NULL,
	[RCIPriority] [nvarchar](max) NULL,
	[ReasonForRequest] [nvarchar](max) NULL,
	[Remarks] [nvarchar](max) NULL,
	[Repeater] [nvarchar](max) NULL,
	[ReworkIterations] [nvarchar](max) NULL,
	[RMROrRPRNumber] [nvarchar](max) NULL,
	[RREngineeringActual] [nvarchar](max) NULL,
	[RREngineeringFaultCode] [nvarchar](max) NULL,
	[RREngineeringGap] [nvarchar](max) NULL,
	[RREngineeringIn] [datetime] NULL,
	[RREngineeringOut] [datetime] NULL,
	[RREngineeringTarget] [nvarchar](max) NULL,
	[RRPubNumber] [nvarchar](max) NULL,
	[Satellite] [nvarchar](max) NULL,
	[Stock] [nvarchar](max) NULL,
	[TimeTvClosed] [nvarchar](max) NULL,
	[TimeTvRaised] [nvarchar](max) NULL,
	[TVRequestActual] [nvarchar](max) NULL,
	[TVRequestFaultCode] [nvarchar](max) NULL,
	[TVRequestGap] [nvarchar](max) NULL,
	[TVRequestTarget] [nvarchar](max) NULL,
	[TVTurnTimeActual] [nvarchar](max) NULL,
	[TVTurnTimeGap] [nvarchar](max) NULL,
	[TVTurnTimeTarget] [nvarchar](max) NULL,
	[PartQuantity] [nvarchar](max) NULL,
	[PreviousEngineNumber] [nvarchar](max) NULL,
	[PlannedEngineNumber] [nvarchar](max) NULL,
	[IsCollected] [bit] NOT NULL CONSTRAINT [DF_OT_TV_Wide_Body_Data_Center_IsCollected]  DEFAULT ((0)),
	[IsUploaded] [bit] NOT NULL CONSTRAINT [DF_OT_TV_Wide_Body_Data_Center_IsUploaded]  DEFAULT ((0)),
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[CreatedDate] [datetime] NOT NULL CONSTRAINT [DF__OT_TV_Wide_Body_Data_Center__4D94879B]  DEFAULT (getdate()),
	[ModifiedBy] [uniqueidentifier] NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_TV.OT_TV_Wide_Body_Data_Center] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_OT_TV_Wide_Body_Data_Center] UNIQUE NONCLUSTERED 
(
	[TVNumber] ASC ,[IssueNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [Edc].[OT_TV_Wide_Body_Data_Center]  WITH CHECK ADD  CONSTRAINT [FK_OT_TV_Wide_Body_Data_Center_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])
REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
GO

ALTER TABLE [Edc].[OT_TV_Wide_Body_Data_Center] CHECK CONSTRAINT [FK_OT_TV_Wide_Body_Data_Center_LT_ST_User_Role_Module1]
GO

ALTER TABLE [Edc].[OT_TV_Wide_Body_Data_Center]  WITH CHECK ADD  CONSTRAINT [FK_OT_TV_Wide_Body_Data_Center_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])
REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId])
GO

ALTER TABLE [Edc].[OT_TV_Wide_Body_Data_Center] CHECK CONSTRAINT [FK_OT_TV_Wide_Body_Data_Center_LT_ST_User_Role_Module2]
GO


