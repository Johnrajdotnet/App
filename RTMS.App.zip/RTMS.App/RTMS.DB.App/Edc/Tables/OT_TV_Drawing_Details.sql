﻿CREATE TABLE [Edc].[OT_TV_Drawing_Details]
(
    [Id]					  BIGINT           IDENTITY (1, 1) NOT NULL,
    [FileName]				  NVARCHAR (250) NULL,
    [PartNumber]			  NVARCHAR (250) NULL,
    [PartDescription]         NVARCHAR (250) NULL,
	[IssueNumber]             NVARCHAR (250) NULL,
	[IssueDate]				  DATETIME       NOT NULL,				  
    [Revision]				  NVARCHAR (250) NULL,
    [Series]                  NVARCHAR (250) NULL,
	[FilePath]				  NVARCHAR (1500) NULL,
	[CpiritLink]			  NVARCHAR (1500) NULL,
	 Active					  BIT 		DEFAULT (1) NOT NULL,
    [CreatedBy]				  UNIQUEIDENTIFIER NOT NULL,
    [CreatedDate]			  DATETIME         CONSTRAINT [DF_Concession.OT_TV_Drawing_Details_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]			  UNIQUEIDENTIFIER NULL,
    [ModifiedDate]			  DATETIME         NULL,
    CONSTRAINT [PK_TV.OT_TV_Drawing_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
    
)
