﻿CREATE TABLE [Log].[Service_Sync_Failure_Log] (
    [Id]            INT           IDENTITY (1, 1) NOT NULL,
    [UserId]        INT           NULL,
    [ServiceType]   VARCHAR (20)  NULL,
    [StartDateTime] DATETIME      NULL,
    [Error]         VARCHAR (255) NULL,
    [CreatedDate]   DATETIME      CONSTRAINT [DF_ServiceSyncFailureLog_CreatedDate] DEFAULT (getdate()) NULL,
    [ModifiedDate]  DATETIME      NULL,
    CONSTRAINT [PK_ServiceSyncFailureLog] PRIMARY KEY CLUSTERED ([Id] ASC)
);

