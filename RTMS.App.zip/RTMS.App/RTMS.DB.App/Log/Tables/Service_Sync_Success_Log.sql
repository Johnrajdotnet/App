﻿CREATE TABLE [Log].[Service_Sync_Success_Log] (
    [Id]            INT          IDENTITY (1, 1) NOT NULL,
    [UserId]        INT          NULL,
    [ServiceType]   VARCHAR (20) NULL,
    [StartDateTime] DATETIME     NULL,
    [EndDateTime]   DATETIME     NULL,
    [CreatedDate]   DATETIME     CONSTRAINT [DF_ServiceSyncSuccessLog_CreatedDate] DEFAULT (getdate()) NULL,
    [ModifiedDate]  DATETIME     NULL,
    CONSTRAINT [PK_ServiceSyncSuccessLog] PRIMARY KEY CLUSTERED ([Id] ASC)
);

