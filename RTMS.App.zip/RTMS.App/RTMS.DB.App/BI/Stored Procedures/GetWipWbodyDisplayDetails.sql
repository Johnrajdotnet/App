﻿-- =============================================
-- Author:           arathy
-- Create date:      03/27/2018
-- Description:      Test the Syncupdate status
-- [Edc].[Bi].[GetWipWbodyDisplayDetails]
-- =============================================
--exec [Bi].[GetWipWbodyDisplayDetails]
CREATE PROCEDURE [Bi].[GetWipWbodyDisplayDetails]
AS
--DECLARE @tvnumber BIGINT
--DECLARE @dateIn  DATETIME;
--DECLARE @requiredDate  DATETIME;
--DECLARE @totalAge  NVARCHAR(250);
DECLARE @teamLeader NVARCHAR(200);
DECLARE @teamLeader1 NVARCHAR(200);
declare @seriesKey NVARCHAR(20)=null
declare @tvType nvarchar(20)=null
BEGIN TRY
 SET NOCOUNT ON;


 BEGIN
	SET @teamLeader='LEE,VINCENT|KATUMBA,FRANK|LOWER,ANDREW|GREEN,TREVOR|THORNE, MARK|STOLWORTHY,MARK|WHYTE, JAMES'
	SET @teamLeader1='ROPER,STEVE'
				SELECT            t.TVNumber             AS TVNumber ,								 
                                  wi.StatusCategory      AS [StatusCategory],
								  wi.StatusDescription   AS [StatusDescription],
								  wi.Location            AS Location,
								  convert(date,t.DateIn) AS DateIn,
                                  wi.StatusTitle         AS StatusTitle,
                                  convert(date,t.CustomerRequiredDate) AS CustRequiredDate,
                                  t.InfoRequestedDetails AS InfoRequestedDetails,
                                  [dbo].[GetTotalAgeInDays](t.DateIn) AS TotalAge,
                                  convert(date,t.HeadsupDate)  AS HeadsupDate,  
								  wi.StatusCategory      AS [Status] ,  
								  'NON-RPN' as RPN_NONRPN,
								 [dbo].[GetEngineSeriesByMark] (t.enginemark) as EngineSeries,   
       				CASE 
						WHEN (StatusTitle='H' OR StatusTitle='N')
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 		

						WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 

						WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate							  
						THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
						END
						as MileStoneStatus,
					CASE								  
						WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN 'CRT' ELSE 'NONCRT' 
					END 
					AS Category, 				
                    [dbo].[GetOwnerNameById] (ac.Engineer1)  AS OwnerName,
                    [dbo].[GetOwnerNameById] (ac.CAEngineer) AS CAEngineerName,
					t.Applicant as Applicant,
					t.PartDescription as PartDescription,
					t.ESN as ESN,
					t.Team as Team,
					t.TeamLeader as TeamLeader,
					--t.HeadsupDate as HeadsupDate,
					convert(date,t.OriginalPromisedDate) as OriginalPromisedDate,
					convert(date,t.RRPromisedDate) as RRPromisedDate,
					t.TVType as Type,

					CASE 
						WHEN ( CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) THEN convert(date,t.CustomerRequiredDate) else convert(date,t.RRPromisedDate)
						END
						AS RequiredDate

        FROM          [Edc].[OT_TV_Wide_Body_Data_Center] t
        INNER JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
        INNER JOIN	[Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
        WHERE         t.DateCompleted  is  null
				AND t.TVType = isnull(@tvType, t.TVType)
				AND	UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader,'|'))      
                AND t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 

UNION 
	
		SELECT     t.TVNumber as TVNumber ,								 
                                  wi.StatusCategory      AS [StatusCategory],
								  wi.StatusDescription   AS [StatusDescription],
								  wi.Location            AS Location,
                                  convert(date,t.DateIn) AS DateIn,
                                  wi.StatusTitle         AS StatusTitle,
                                  convert(date,t.CustomerRequiredDate) AS CustRequiredDate,
                                  t.InfoRequestedDetails AS InfoRequestedDetails,
                                  [dbo].[GetTotalAgeInDays](t.DateIn) AS TotalAge,
                                  convert(date,t.HeadsupDate)  AS HeadsupDate,  
								  wi.StatusCategory      AS [Status] ,    
								  'RPN' as RPN_NONRPN,   
								   [dbo].[GetEngineSeriesByMark] (t.enginemark) as EngineSeries,                   
       							  CASE 
										WHEN (StatusTitle='H' OR StatusTitle='N')
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.HeadsupDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
										WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 		

										WHEN (StatusTitle='D' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0) --NON CRT RRPromisedDate
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 

										WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) --CRT CustomerRequiredDate
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.CustomerRequiredDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
										WHEN (StatusTitle='A' AND CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))<=0)--NON CRT RRPromisedDate								  
										THEN [dbo].[CheckTVMetOrMissed](t.DateIn,t.TVType,t.RRPromisedDate,t.InfoRequestedDetails,t.Team,wi.StatusSeqCode,wi.StatusTitle) 
								  
					                 END
						             AS MileStoneStatus,
									 CASE								  
										WHEN CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,'') )>0 THEN 'CRT' ELSE 'NONCRT'
									 END 
					                 AS Category, 				
                                  [dbo].[GetOwnerNameById] (ac.Engineer1)  AS OwnerName,
                                  [dbo].[GetOwnerNameById] (ac.CAEngineer) AS CAEngineerName,
								  t.Applicant as Applicant,
								  t.PartDescription as PartDescription,
								  t.ESN as ESN,
								  t.Team as Team,
								  t.TeamLeader as TeamLeader,
								  --t.HeadsupDate as HeadsupDate,
								  convert(date,t.OriginalPromisedDate) as OriginalPromisedDate,
								  convert(date,t.RRPromisedDate) as RRPromisedDate,
								  t.TVType as Type,
								CASE 
									WHEN ( CHARINDEX('CRT', ISNULL(t.InfoRequestedDetails,''))>0) THEN convert(date,t.CustomerRequiredDate) else convert(date,t.RRPromisedDate)
									END
									AS RequiredDate

              FROM          [Edc].[OT_TV_Wide_Body_Data_Center] t
              INNER JOIN    [Edc].[OT_TV_Wide_Body_Activity_Center] ac ON t.Id  = ac.TVDataCenterId 
              INNER JOIN	[Report].[ST_Edc_Wip_Status_Details] wi ON wi.Id=ac.[Status]
              WHERE         t.DateCompleted  is  null 
						AND t.TVType = isnull(@tvType, t.TVType)
						AND UPPER(RTRIM(LTRIM(t.TeamLeader))) IN (select UPPER(RTRIM(LTRIM(Item))) from [dbo].[StringToTableValue] (@teamLeader1,'|'))      
                        AND t.EngineMark LIKE '%'+Isnull(@seriesKey,t.EngineMark)+'%' 
					    AND (Team='RE-RPN-REACT' OR Team='SE-RPN-REACT')



						
 END
			                                                        
END TRY
BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH

