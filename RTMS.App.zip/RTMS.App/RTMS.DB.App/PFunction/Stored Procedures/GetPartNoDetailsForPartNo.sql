﻿
-- =============================================
-- Author:		Arathy
-- Create date: 05/08/2018
-- Description:	get partfunction details
-- exec [PFunction].[GetPartNoDetailsForPartNo] 'FK123'
-- =============================================
CREATE PROCEDURE [PFunction].[GetPartNoDetailsForPartNo]
@partNumber NVARCHAR(50)

AS

BEGIN TRY
	
	SET NOCOUNT ON;
    
			  
              BEGIN

                    SELECT		Id as Id,
								PartNumber AS PartNumber,
								PartDescription AS PartDescription,
								PartFunction AS PartFunction,
								AssemblyDetails AS AssemblyDetails

					FROM		[PFunction].ST_WBody_Part_Number_Details 
					WHERE		PartNumber=@partNumber
					
--get ddl values--

					SELECT		
								  ATA AS AtaDetails,
								 FigureItemNumber AS FigItemNumber,
								 PartFeature AS PartFeatureDetail

					FROM		[PFunction].OT_WBody_Part_Feature_Details pf 
					INNER  JOIN	[PFunction].[ST_WBody_Part_Number_Details] pt ON pt.id=pf.PartnumberId
					WHERE		pt.PartNumber=@partNumber
				
			  END    
    
END TRY

BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH





