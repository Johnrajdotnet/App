﻿
-- =============================================
-- Author:		Arathy
-- Create date: 05/08/2018
-- Description:	get partfunction details
-- exec [PFunction].[GetPartFunctionDetails] 'f',NULL,NULL,NULL,null,NULL
-- =============================================
CREATE PROCEDURE [PFunction].[GetPartFunctionDetails]
@partNumber NVARCHAR(50),
@ata NVARCHAR(50),
@figItemNo NVARCHAR(50),
@partDescription NVARCHAR(50),
@previousTv NVARCHAR(500),
@moduleNo INT
AS

BEGIN TRY
	
	SET NOCOUNT ON;
    
			  
              BEGIN

                    SELECT		PartNumber AS PartNumber,
								PartDescription AS PartDescription,
								ATA AS ATA,
								FigureItemNumber AS FigItemNo,
								ModularType AS ModularNonModular,
								ModuleNumber AS ModuleNo,
								PartFeature AS PartFeature,
								PartFunction AS PartFunction,
								AssemblyDetails AS AssemblyDetails,
								PreviousTV AS PreviousTv

					FROM		[PFunction].[OT_WBody_Part_Feature_Details] pf
					INNER  JOIN	[PFunction].[ST_WBody_Part_Number_Details] pt on pt.id=pf.PartnumberId
					
					WHERE		
								pt.PartNumber like '%'+ISNULL(@partNumber,pt.PartNumber)+'%'
					AND			pf.ATA like '%'+ISNULL(@ata,pf.ATA)+'%' 
					AND			pf.FigureItemNumber like '%'+ ISNULL(@figItemNo,pf.FigureItemNumber)+'%'
					AND			pt.PartDescription like '%'+ISNULL(@partDescription,pt.PartDescription)+'%' 
					AND			ISNULL(@moduleNo ,pf.ModuleNumber)=pf.ModuleNumber
					AND         pf.PreviousTV like '%'+ ISNULL(@previousTv,pf.PreviousTV)+'%'
				
			  END    
    
END TRY

BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH





