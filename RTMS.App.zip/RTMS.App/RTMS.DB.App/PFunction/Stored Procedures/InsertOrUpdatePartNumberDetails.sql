﻿
-- =============================================
-- Author:		Mira
-- Create date: 11/07/2019
-- Description:	Inser Part Number Details
-- exec [PFunction].[InsertOrUpdatePartNumberDetails] 
-- =============================================
CREATE PROCEDURE [PFunction].[InsertOrUpdatePartNumberDetails]
@PartNumber NVARCHAR(10),
@PartDescription nvarchar(1000),
@PartFunction  nvarchar(1000),
@AssemblyDetails NVARCHAR(25),
@userId uniqueidentifier

AS

BEGIN TRY
	
	SET NOCOUNT ON;

			  IF  (EXISTS  (SELECT PartNumber FROM [PFunction].[ST_WBody_Part_Number_Details] where PartNumber=@PartNumber))
			  BEGIN

					   UPDATE  [PFunction].[ST_WBody_Part_Number_Details]
					   SET     PartDescription=@PartDescription, PartFunction=@PartFunction, AssemblyDetails=@AssemblyDetails, 
						      ModifiedBy=@userId,  ModfiedDate=GETDATE()
					   where   ltrim(rtrim(PartNumber))=ltrim(rtrim(@PartNumber)) 
				END
				ELSE 
				BEGIN
				
						INSERT INTO [PFunction].[ST_WBody_Part_Number_Details]
							  (
								PartNumber,
								PartDescription,
								PartFunction, 
								AssemblyDetails, 
								CreatedBy, 
								CreatedDate
							   )
						values(
								@PartNumber,
								@PartDescription,
								@PartFunction, 
								@AssemblyDetails, 
								@userId,
								GETDATE()
							   )
		       
				END
		
END TRY

BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH
