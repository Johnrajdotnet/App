﻿
-- =============================================
-- Author:		Arathy
-- Create date: 05/08/2018
-- Description:	get partfunction details
-- exec [PFunction].[InsertOrUpdatePartFeatureDetails] 'FK123'
-- =============================================
CREATE PROCEDURE [PFunction].InsertOrUpdatePartFeatureDetails
@flag NVARCHAR(50),
@partNumberId INT,
@ata NVARCHAR(50),
@figureItemNumber NVARCHAR(50),
@modularType NVARCHAR(50),
@moduleNumber INT,
@partFeature NVARCHAR(50),
@previousTV NVARCHAR(50),
@userId uniqueidentifier

AS

BEGIN TRY
	
	SET NOCOUNT ON;

			IF(@flag='ADD')
			  
              BEGIN

				INSERT INTO [PFunction].[OT_WBody_Part_Feature_Details]
			      (
					[PartNumberId],
					[PartFeature],
					[ATA],
					[FigureItemNumber],
					[ModularType],
					[ModuleNumber],
					[PreviousTV],
					[CreatedBy],
					[CreatedDate]
				   )
				SELECT
					@partNumberId,
					@partFeature,
					@ata,
					@figureItemNumber,
					@modularType,
					@moduleNumber,
					@previousTV,
					@userId,
					GETDATE()
		       
				END
				ELSE 
				BEGIN
				UPDATE [PFunction].[OT_WBody_Part_Feature_Details]
				SET		[ModularType]  = @modularType,
						[ModuleNumber]    = @moduleNumber,
						[PreviousTV]	=@previousTV,
						[ModifiedBy]    = @userId,
						[ModfiedDate]  = GETDATE()
				WHERE   [PartNumberId]=  @partNumberId
				AND		[ATA]=@ata
				AND		[PartFeature]=@partFeature
				AND		FigureItemNumber=@figureItemNumber

				END
    
END TRY

BEGIN CATCH
   EXECUTE [dbo].[LogError]
END CATCH





