﻿CREATE TABLE [PFunction].[OT_Part_Function_TV_Details]
(
	 [Id]						BIGINT		      IDENTITY (1, 1) NOT NULL,
	 [PartFunctionDetailsId]	BIGINT							  NOT NULL,
	 [PreviousTVListDetails]	NVARCHAR(MAX)					  NOT NULL,
	 [CreatedBy]				UNIQUEIDENTIFIER				  NOT NULL,
	 [CreatedDate]				DATETIME						  NOT NULL,
	 [ModifiedBy]				UNIQUEIDENTIFIER				  NULL,
	 [ModfiedDate]				DATETIME						  NULL,
	CONSTRAINT [PK_Part.OT_Part_Function_TV_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_Part_Function_TV_Details_ST_Part_Function_Details] FOREIGN KEY([PartFunctionDetailsId])REFERENCES [PFunction].[ST_Part_Function_Details] ([Id]),
	CONSTRAINT [FK_ST_OT_Part_Function_TV_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_ST_OT_Part_Function_TV_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
)
