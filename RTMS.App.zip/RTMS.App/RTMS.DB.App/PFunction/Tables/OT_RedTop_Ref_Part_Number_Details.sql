﻿CREATE TABLE [PFunction].[OT_RedTop_Part_Number_Details]
(
	 [Id]						BIGINT		      IDENTITY (1, 1) NOT NULL,
	 [WBodyRedTopCenterId]		BIGINT							  NOT NULL,
	 [Remark]					NVARCHAR(1000)					  NOT NULL,
	 [CreatedBy]				UNIQUEIDENTIFIER				  NOT NULL,
	 [CreatedDate]				DATETIME						  NOT NULL,
	 [ModifiedBy]				UNIQUEIDENTIFIER				  NULL,
	 [ModfiedDate]				DATETIME						  NULL,
	CONSTRAINT [PK_Part.OT_RedTop_Part_Number_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_RedTop_Part_Number_Details_OT_TV_Wide_Body_RedTop_Center] FOREIGN KEY([WBodyRedTopCenterId])REFERENCES [Edc].[OT_TV_Wide_Body_RedTop_Center] ([Id]),
	CONSTRAINT [FK_ST_OT_RedTop_Part_Number_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_ST_OT_RedTop_Part_Number_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
)
