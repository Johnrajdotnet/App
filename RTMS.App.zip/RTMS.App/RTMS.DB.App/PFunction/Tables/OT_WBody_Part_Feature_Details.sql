﻿CREATE TABLE [PFunction].[OT_WBody_Part_Feature_Details]
(
	 [Id]						BIGINT		      IDENTITY (1, 1) NOT NULL,
	 [PartNumberId]				BIGINT							  NOT NULL,	 
	 [PartFeature]				NVARCHAR(250)					  NOT NULL,
	 [ATA]						NVARCHAR(250)					  NOT NULL,
	 [FigureItemNumber]			NVARCHAR(25)					  NOT NULL,
	 [ModularType]				NVARCHAR(25)					  NOT NULL,
	 [ModuleNumber]				INT								      NULL,
	 [PreviousTV]				NVARCHAR(MAX)					  	  NULL,
	 [CreatedBy]				UNIQUEIDENTIFIER				  NOT NULL,
	 [CreatedDate]				DATETIME						  NOT NULL,
	 [ModifiedBy]				UNIQUEIDENTIFIER				  NULL,
	 [ModfiedDate]				DATETIME						  NULL,
	CONSTRAINT [PK_Part.OT_WBody_Part_Feature_Details] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_OT_WBody_Part_Feature_Details_ST_Part_Number_Details] FOREIGN KEY([PartNumberId])REFERENCES [PFunction].[ST_WBody_Part_Number_Details] ([Id]),
	CONSTRAINT [FK_OT_WBody_Part_Feature_Details_LT_ST_User_Role_Module1] FOREIGN KEY([CreatedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
	CONSTRAINT [FK_OT_WBody_Part_Feature_Details_LT_ST_User_Role_Module2] FOREIGN KEY([ModifiedBy])REFERENCES [LinkDB].[LT_ST_User_Role_Module] ([UserRoleModuleId]),
)
